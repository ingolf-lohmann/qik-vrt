<!-- SPDX-License-Identifier: LicenseRef-QIKVRT-OWNER-POLICY
SPDX-FileCopyrightText: Copyright (c) Ingolf Lohmann or designated legal entity. -->
LOCAL_GIT_COMMIT_CREATED = TRUE
LOCAL_GIT_TAG_CREATED = TRUE
GITHUB_PUSH_EXECUTED = FALSE
RELEASE = NO
SIGNED_COMMIT = NOT_CLAIMED
