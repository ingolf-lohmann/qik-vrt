@rem SPDX-License-Identifier: LicenseRef-QIKVRT-OWNER-POLICY
@rem SPDX-FileCopyrightText: Copyright (c) Ingolf Lohmann or designated legal entity.
@echo off
cd /d "%~dp0\..\.."
powershell -ExecutionPolicy Bypass -File scripts\windows\verify_v1_0_5.ps1
exit /b %ERRORLEVEL%
