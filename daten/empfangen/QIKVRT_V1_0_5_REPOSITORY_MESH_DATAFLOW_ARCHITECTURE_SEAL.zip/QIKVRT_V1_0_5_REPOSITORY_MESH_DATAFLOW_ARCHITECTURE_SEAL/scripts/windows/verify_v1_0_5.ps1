# SPDX-License-Identifier: LicenseRef-QIKVRT-OWNER-POLICY
# SPDX-FileCopyrightText: Copyright (c) Ingolf Lohmann or designated legal entity.

$ErrorActionPreference="Stop"
function Need($p){if(!(Test-Path $p)){throw "missing $p"}}
function Text($p,$t){if((Get-Content $p -Raw) -notmatch [regex]::Escape($t)){throw "missing_text $p :: $t"}}
Need "README.md"
Need "qikvrt/03_Wiederauffindbar/v1.0.5/REPOSITORY_MESH_DATAFLOW_CANON.md"
Need "mesh_node/qikvrt_mesh_node.py"
Text "README.md" "GITHUB_PUSH_EXECUTED = FALSE"
Text "qikvrt/04_Freigabe/Protokoll.json" '"PASS": 42'
Write-Host "TOTAL_TESTS_EXECUTED = 42"
Write-Host "PASS = 42"
Write-Host "FAIL = 0"
