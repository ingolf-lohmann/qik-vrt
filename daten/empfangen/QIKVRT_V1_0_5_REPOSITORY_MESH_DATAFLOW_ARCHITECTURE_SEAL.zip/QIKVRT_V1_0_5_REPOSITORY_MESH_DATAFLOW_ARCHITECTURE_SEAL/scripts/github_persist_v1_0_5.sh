#!/usr/bin/env sh
# SPDX-License-Identifier: LicenseRef-QIKVRT-OWNER-POLICY
# SPDX-FileCopyrightText: Copyright (c) Ingolf Lohmann or designated legal entity.

set -eu
REMOTE="${1:-}"
BRANCH="${2:-main}"
[ -n "$REMOTE" ] || { echo "USAGE: sh scripts/github_persist_v1_0_5.sh https://github.com/OWNER/REPO.git [branch]"; exit 2; }
sh scripts/verify_v1_0_5.sh
git init
git checkout -B "$BRANCH"
git add .
git commit -m "v1.0.5: repository mesh dataflow architecture"
git tag -a v1.0.5 -m "QIK-VRT v1.0.5 Repository Mesh"
git remote get-url origin >/dev/null 2>&1 && git remote set-url origin "$REMOTE" || git remote add origin "$REMOTE"
git push -u origin "$BRANCH"
git push origin v1.0.5
