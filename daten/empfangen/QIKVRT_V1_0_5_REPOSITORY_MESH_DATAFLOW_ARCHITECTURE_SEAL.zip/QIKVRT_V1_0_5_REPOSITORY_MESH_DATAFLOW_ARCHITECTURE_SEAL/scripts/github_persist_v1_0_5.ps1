# SPDX-License-Identifier: LicenseRef-QIKVRT-OWNER-POLICY
# SPDX-FileCopyrightText: Copyright (c) Ingolf Lohmann or designated legal entity.
param([Parameter(Mandatory=$true)][string]$RemoteUrl,[string]$Branch="main")
$ErrorActionPreference="Stop"
powershell -ExecutionPolicy Bypass -File scripts\windows\verify_v1_0_5.ps1
git init
git checkout -B $Branch
git add .
git commit -m "v1.0.5: repository mesh dataflow architecture"
git tag -a v1.0.5 -m "QIK-VRT v1.0.5 Repository Mesh"
if(git remote get-url origin 2>$null){git remote set-url origin $RemoteUrl}else{git remote add origin $RemoteUrl}
git push -u origin $Branch
git push origin v1.0.5
