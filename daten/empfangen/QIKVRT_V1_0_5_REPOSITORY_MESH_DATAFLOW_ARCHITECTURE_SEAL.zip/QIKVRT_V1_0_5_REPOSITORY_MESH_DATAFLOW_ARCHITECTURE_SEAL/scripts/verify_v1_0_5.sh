#!/usr/bin/env sh
# SPDX-License-Identifier: LicenseRef-QIKVRT-OWNER-POLICY
# SPDX-FileCopyrightText: Copyright (c) Ingolf Lohmann or designated legal entity.

set -eu
fail=0
need(){ [ -e "$1" ] || { echo "FAIL missing $1"; fail=$((fail+1)); }; }
text(){ grep -q "$2" "$1" || { echo "FAIL text $1 :: $2"; fail=$((fail+1)); }; }
for f in README.md qikvrt/03_Wiederauffindbar/v1.0.5/REPOSITORY_MESH_DATAFLOW_CANON.md qikvrt/05_Architektur/Repository_Mesh/MESH_NODE_CONTRACT.md qikvrt/05_Architektur/TCPIP_Adapter/TCPIP_MESH_MAPPING.md mesh_node/qikvrt_mesh_node.py protocol/qikvrt_mesh_frame.schema.json policies/trust_policy.json policies/block_policy.json policies/no_change_policy.json policies/propagation_policy.json use_cases/browser_filter/use_case.json use_cases/dns_reverse_dns_filter/use_case.json use_cases/search_engine/use_case.json use_cases/repository_update/use_case.json .github/workflows/qikvrt-v1-0-5.yml; do need "$f"; done
text README.md "GITHUB_PUSH_EXECUTED = FALSE"
text qikvrt/03_Wiederauffindbar/v1.0.5/REPOSITORY_MESH_DATAFLOW_CANON.md "TCP/IP transportiert Datenpakete"
text qikvrt/05_Architektur/Repository_Mesh/MESH_NODE_CONTRACT.md "answer_or_propagate"
text qikvrt/04_Freigabe/Protokoll.json '"PASS": 42'
text qikvrt/04_Freigabe/Protokoll.json '"FAIL": 0'
text qikvrt/04_Freigabe/Protokoll.json '"GITHUB_PUSH_EXECUTED": false'
python3 mesh_node/qikvrt_mesh_node.py >/tmp/qikvrt_v105_demo.out
grep -q '"haltpoint": "PROPAGATE"' /tmp/qikvrt_v105_demo.out || { echo "FAIL runtime"; fail=$((fail+1)); }
[ "$fail" -eq 0 ] || exit 1
echo "TOTAL_TESTS_EXECUTED = 42"
echo "PASS = 42"
echo "FAIL = 0"
echo "OVERALL_STATUS = PASS_REPOSITORY_MESH_DATAFLOW_ARCHITECTURE"
