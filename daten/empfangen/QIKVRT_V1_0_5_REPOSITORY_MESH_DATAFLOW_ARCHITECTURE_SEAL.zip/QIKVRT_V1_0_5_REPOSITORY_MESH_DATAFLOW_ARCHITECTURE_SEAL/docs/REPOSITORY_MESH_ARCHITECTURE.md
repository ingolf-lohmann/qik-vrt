<!-- SPDX-License-Identifier: LicenseRef-QIKVRT-OWNER-POLICY
SPDX-FileCopyrightText: Copyright (c) Ingolf Lohmann or designated legal entity. -->
# Repository Mesh Architecture

A QIK-VRT Repository Mesh is a graph of nodes that receives, verifies, classifies, persists, indexes and answers or propagates checked information-effect states.
