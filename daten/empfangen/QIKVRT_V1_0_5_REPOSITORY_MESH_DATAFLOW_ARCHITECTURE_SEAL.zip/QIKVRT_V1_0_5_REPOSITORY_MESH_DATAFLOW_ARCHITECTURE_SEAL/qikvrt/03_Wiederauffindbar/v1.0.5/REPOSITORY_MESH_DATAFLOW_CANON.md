<!-- SPDX-License-Identifier: LicenseRef-QIKVRT-OWNER-POLICY
SPDX-FileCopyrightText: Copyright (c) Ingolf Lohmann or designated legal entity. -->
# Repository Mesh Dataflow Canon

TCP/IP transportiert Datenpakete.
QIK-VRT Repository Mesh transportiert geprüfte Wirkzustände.

NO_PROPAGATION_WITHOUT_GATE_PASS = TRUE
