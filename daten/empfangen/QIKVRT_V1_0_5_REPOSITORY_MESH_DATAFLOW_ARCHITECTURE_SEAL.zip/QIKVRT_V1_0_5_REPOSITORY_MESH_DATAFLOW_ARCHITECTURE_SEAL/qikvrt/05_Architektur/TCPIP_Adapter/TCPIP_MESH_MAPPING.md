<!-- SPDX-License-Identifier: LicenseRef-QIKVRT-OWNER-POLICY
SPDX-FileCopyrightText: Copyright (c) Ingolf Lohmann or designated legal entity. -->
# TCP/IP to QIK-VRT Mesh Mapping

IP address -> mesh_node_id
Port -> use_case_endpoint
Packet header -> qikvrt_mesh_header
Payload -> information_effect_payload
Checksum -> sha256 + trust gate
ACK -> PASS / ANSWER / UPDATE
NACK -> BLOCK / AUDIT_REQUIRED
TTL -> max propagation depth
