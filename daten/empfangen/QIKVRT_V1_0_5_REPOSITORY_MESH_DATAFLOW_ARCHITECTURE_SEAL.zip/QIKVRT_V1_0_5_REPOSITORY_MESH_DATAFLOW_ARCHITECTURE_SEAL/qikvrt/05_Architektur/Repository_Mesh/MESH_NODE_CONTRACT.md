<!-- SPDX-License-Identifier: LicenseRef-QIKVRT-OWNER-POLICY
SPDX-FileCopyrightText: Copyright (c) Ingolf Lohmann or designated legal entity. -->
# Mesh Node Contract

Required steps:
receive
verify
classify
persist
index
answer_or_propagate

If verify fails: BLOCK.
If hash equals persisted hash: NO_CHANGE.
If all gates pass: ANSWER_OR_PROPAGATE.
