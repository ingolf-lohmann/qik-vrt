<!-- SPDX-License-Identifier: LicenseRef-QIKVRT-OWNER-POLICY
SPDX-FileCopyrightText: Copyright (c) Ingolf Lohmann or designated legal entity. -->
# Mesh Source Record

SOURCE = USER_UPLOADED_REPOSITORY_MESH_DATAFLOW_DIAGRAM
AUTHOR = Ingolf Lohmann
VERSION = v1.0.5

Pipeline: Empfang -> Prüfung -> Kategorisierung -> Persistierung -> Indexierung -> Antwort / Propagation.
