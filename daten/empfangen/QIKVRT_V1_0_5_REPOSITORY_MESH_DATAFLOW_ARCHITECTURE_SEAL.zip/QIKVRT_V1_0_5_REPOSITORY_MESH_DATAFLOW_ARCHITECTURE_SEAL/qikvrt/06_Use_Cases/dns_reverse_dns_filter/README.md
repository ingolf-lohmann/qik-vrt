<!-- SPDX-License-Identifier: LicenseRef-QIKVRT-OWNER-POLICY
SPDX-FileCopyrightText: Copyright (c) Ingolf Lohmann or designated legal entity. -->
# Use Case dns_reverse_dns_filter

{
  "version": "v1.0.5",
  "use_case": "dns_reverse_dns_filter",
  "steps": [
    "domain_or_source",
    "classification",
    "trust_check",
    "forward_or_block"
  ]
}
