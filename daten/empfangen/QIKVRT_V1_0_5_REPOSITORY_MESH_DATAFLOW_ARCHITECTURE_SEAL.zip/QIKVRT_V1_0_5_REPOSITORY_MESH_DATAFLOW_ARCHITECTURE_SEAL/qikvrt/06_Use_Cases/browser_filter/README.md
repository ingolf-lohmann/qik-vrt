<!-- SPDX-License-Identifier: LicenseRef-QIKVRT-OWNER-POLICY
SPDX-FileCopyrightText: Copyright (c) Ingolf Lohmann or designated legal entity. -->
# Use Case browser_filter

{
  "version": "v1.0.5",
  "use_case": "browser_filter",
  "steps": [
    "request",
    "local_check",
    "mesh_lookup",
    "answer_or_block"
  ]
}
