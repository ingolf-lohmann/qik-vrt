<!-- SPDX-License-Identifier: LicenseRef-QIKVRT-OWNER-POLICY
SPDX-FileCopyrightText: Copyright (c) Ingolf Lohmann or designated legal entity. -->
# Use Case search_engine

{
  "version": "v1.0.5",
  "use_case": "search_engine",
  "steps": [
    "crawler_item",
    "categorize",
    "index",
    "search_effect"
  ]
}
