# SPDX-License-Identifier: LicenseRef-QIKVRT-OWNER-POLICY
import hashlib, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
def h(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
def run(frame):
    frame.setdefault("gates", {})
    frame["gates"]["receive"] = "PASS"
    frame["gates"]["verify"] = "PASS" if all(k in frame for k in ["frame_id","version","use_case","source","payload"]) else "BLOCK"
    frame["gates"]["classify"] = "PASS" if frame.get("use_case") in ["browser_filter","dns_reverse_dns_filter","search_engine","repository_update"] else "BLOCK"
    frame["hash"] = "sha256:" + h({"source":frame.get("source"),"payload":frame.get("payload")})
    out = ROOT / "qikvrt" / "09_Runtime" / "mesh_node" / "persisted_frames"
    out.mkdir(parents=True, exist_ok=True)
    (out / (frame.get("frame_id","unknown") + ".json")).write_text(json.dumps(frame, indent=2), encoding="utf-8")
    frame["gates"]["persist"] = "PASS"
    frame["gates"]["index"] = "PASS"
    frame["haltpoint"] = "BLOCK" if "BLOCK" in frame["gates"].values() else ("PROPAGATE" if frame.get("use_case") == "repository_update" else "ANSWER")
    frame["gates"]["answer_or_propagate"] = "PASS"
    return frame
if __name__ == "__main__":
    frame = {"frame_id":"demo","version":"v1.0.5","use_case":"repository_update","source":{"kind":"demo"},"payload":{"event":"update_hint"}}
    result = run(frame)
    print(json.dumps(result, indent=2))
    sys.exit(1 if result["haltpoint"] == "BLOCK" else 0)
