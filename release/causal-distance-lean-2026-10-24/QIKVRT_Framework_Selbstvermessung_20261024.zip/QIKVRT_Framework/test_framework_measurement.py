import copy,json,unittest
from pathlib import Path
from framework_measurement import catalog_graph,reading_plan,static_graph,ROOT

class FrameworkMeasurementTests(unittest.TestCase):
    def setUp(self):
        self.catalog=json.loads((ROOT/'framework_catalog.json').read_text())
        self.profile={'schema':'QIKVRT_PERSONAL_READING_PROFILE_V1','person_id':'person:ingolf-lohmann',
            'display_name':'Ingolf Lohmann','interests':['Zeit und Retrokausalität'],
            'consumer':'HUMAN','rights_scope':'READ_ONLY_CATALOG_NAVIGATION'}
    def test_declared_reading_order_preserved(self):
        p=reading_plan(self.profile,self.catalog)
        self.assertEqual([s['record_id']for s in p['routes'][0]['steps']],
                         [21888130,21711193,22216916,21947141,21731492])
        self.assertTrue(p['read_only']);self.assertFalse(p['effect_ack_done'])
    def test_person_bound_without_code_fork(self):
        a=reading_plan(self.profile,self.catalog)
        b=reading_plan(dict(self.profile,person_id='person:example',display_name='Example'),self.catalog)
        self.assertNotEqual(a['profile_ref'],b['profile_ref'])
        self.assertEqual(a['routes'],b['routes']);self.assertFalse(b['identity_authentication_claimed'])
    def test_human_and_artificial_keep_same_source_order(self):
        a=reading_plan(self.profile,self.catalog)
        b=reading_plan(dict(self.profile,consumer='ARTIFICIAL'),self.catalog)
        self.assertEqual(a['routes'],b['routes']);self.assertNotEqual(a['profile_ref'],b['profile_ref'])
    def test_unknown_interest_and_extra_authority_rejected(self):
        for change in [{'interests':['unknown']},{'rights_scope':'EXECUTE'},{'execute':True}]:
            with self.assertRaises(ValueError):reading_plan(dict(self.profile,**change),self.catalog)
    def test_no_input_mutation(self):
        before=copy.deepcopy(self.catalog);reading_plan(self.profile,self.catalog)
        self.assertEqual(before,self.catalog)
    def test_graph_scopes_and_missing_source_boundary(self):
        a=catalog_graph(self.catalog);b,missing=static_graph(ROOT/'framework_sources/src','8273ef8127edccf4b357fdacdd17a1e6b0f3f87f')
        self.assertNotEqual(a.scope,b.scope)
        self.assertTrue(any(x['import_name']=='src.qikvrt_siemens_reference_integration' for x in missing))

if __name__=='__main__':unittest.main()
