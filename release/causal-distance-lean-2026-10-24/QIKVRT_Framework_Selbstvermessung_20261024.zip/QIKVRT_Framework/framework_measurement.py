# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
"""Read-only typed self-measurement and person-bound catalog navigation.

Reuses qikvrt_causal_distance; does not replace Terminal, Transputer, the
personal assistant, or its authorization. Static imports and thematic routes
are different relation classes and are never declared observed effect edges.
"""
import ast
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'metric_core'),str(ROOT.parent/'causal_distance_work/candidate/src'),
              str(ROOT.parent/'causal_distance_work/upstream/src')]
from qikvrt_causal_distance import DependencyGraph,Edge
from qikvrt_effect_ack import canonical_json,sha256_identifier


def encode(v):return canonical_json(v).encode()


def build_graph(vertices,relations,subject,scope):
    subject_raw=encode(subject);subject_ref=sha256_identifier(subject_raw)
    evidence={subject_ref:subject_raw};edges=[]
    grouped={}
    for a,b,item in relations:grouped.setdefault((a,b),[]).append(item)
    for (a,b),items in sorted(grouped.items()):
        raw=encode({'source':a,'target':b,'weight':1,'subject_ref':subject_ref,
                    'resolution':'one-declared-relation-v1','scope':scope,'bindings':items})
        ref=sha256_identifier(raw);evidence[ref]=raw;edges.append(Edge(a,b,1,ref))
    graph=DependencyGraph(vertices,edges,evidence,subject_ref=subject_ref,
                resolution='one-declared-relation-v1',scope=scope)
    return graph


def summarize(graph):
    from math import inf
    values=[graph.directed(a,b)for a in graph.vertices for b in graph.vertices if a!=b]
    finite=[x for x in values if x!=inf]
    pending=set(graph.vertices);components=[]
    while pending:
        first=min(pending);part={v for v in pending if graph.metric(first,v)!=inf}
        pending-=part;components.append(sorted(part))
    return {'graph_ref':graph.graph_ref,'relation_class':graph.scope,
        'vertices':len(graph.vertices),'edges':len(graph.edges),
        'directed_reachable_ordered_pairs_excluding_self':len(finite),
        'directed_unreachable_ordered_pairs_excluding_self':len(values)-len(finite),
        'largest_finite_directed_distance':max(finite,default=0),
        'weak_components':components,'observed_effect_causality_inferred':False}


def catalog_graph(catalog):
    works={str(w['record_id']):w for w in catalog['works']}
    relations=[]
    for route in catalog['reading_routes']:
        for a,b in zip(route['records'],route['records'][1:]):
            if str(a)not in works or str(b)not in works:raise ValueError('UNRESOLVED_ROUTE_RECORD')
            relations.append((str(a),str(b),{'kind':'CURATED_READING_RECOMMENDATION',
                'route':route['name'],'catalog_version':catalog['catalog_version']}))
    subject={'catalog_schema':catalog['schema'],'catalog_version':catalog['catalog_version'],
             'catalog_ref':sha256_identifier(encode(catalog)),'verified_at_utc':catalog['verified_at_utc']}
    return build_graph(works,relations,subject,'CURATED_READING_RECOMMENDATION_ONLY')


def static_graph(source_root,source_commit):
    files=sorted(source_root.glob('*.py'));modules={p.stem:p for p in files}
    relations=[];external=[]
    for p in files:
        raw=p.read_bytes()
        for node in ast.walk(ast.parse(raw,filename=p.name)):
            if isinstance(node,ast.Import):imports=[x.name for x in node.names]
            elif isinstance(node,ast.ImportFrom):
                imports=([node.module] if node.module else [x.name for x in node.names])
            else:continue
            for name in imports:
                provider=name.split('.')[-1]
                binding={'consumer_file':p.name,'consumer_sha256':sha256_identifier(raw),
                    'line':node.lineno,'kind':'STATIC_AST_IMPORT','import_name':name}
                if provider in modules and provider!=p.stem:
                    relations.append((provider,p.stem,binding))
                elif provider.startswith('qikvrt_'):
                    external.append(binding)
    subject={'repository':'ingolf-lohmann/qik-vrt','commit':source_commit,
             'selection':'all 10 Python files in src at the pinned commit',
             'runtime_execution_inferred':False}
    return build_graph(modules,relations,subject,'STATIC_AST_IMPORT_DEPENDENCY_ONLY'),external


def reading_plan(profile,catalog):
    required={'schema','person_id','display_name','interests','consumer','rights_scope'}
    if set(profile)!=required or profile['schema']!='QIKVRT_PERSONAL_READING_PROFILE_V1':
        raise ValueError('CLOSED_PROFILE_SCHEMA')
    if profile['rights_scope']!='READ_ONLY_CATALOG_NAVIGATION':raise ValueError('NO_ACTION_AUTHORITY')
    if profile['consumer']not in ('HUMAN','ARTIFICIAL'):raise ValueError('UNKNOWN_CONSUMER')
    if not isinstance(profile['person_id'],str)or not profile['person_id'].strip():raise ValueError('PERSON_BINDING_REQUIRED')
    if not isinstance(profile['display_name'],str)or not profile['display_name'].strip():raise ValueError('DISPLAY_NAME_REQUIRED')
    interests=profile['interests']
    if not isinstance(interests,list)or not interests or len(set(interests))!=len(interests):
        raise ValueError('UNIQUE_INTERESTS_REQUIRED')
    routes={r['name']:r for r in catalog['reading_routes']}
    if any(x not in routes for x in interests):raise ValueError('UNKNOWN_INTEREST')
    works={w['record_id']:w for w in catalog['works']}
    graph=catalog_graph(catalog);plans=[]
    for interest in interests:
        selected=routes[interest];ids=list(selected['records'])
        prefix=[]if ids[0]==catalog['entry_point_record_id']else[catalog['entry_point_record_id']]
        steps=[]
        for index,record in enumerate(prefix+ids):
            work=works[record]
            steps.append({'order':index+1,'record_id':record,'title':work['title'],
                'doi':work['doi'],'record_url':work['record_url'],
                'catalog_status':work['status'],'scope_boundary':work['boundary'],
                'role':'EDITORIAL_ENTRY_PREFIX'if record in prefix else 'DECLARED_ROUTE_STEP'})
        plans.append({'interest':interest,'purpose':selected['purpose'],'steps':steps,
            'route_first_to_last':graph.query(str(ids[0]),str(ids[-1])),
            'shortest_graph_path_does_not_replace_declared_reading_order':True})
    return {'schema':'QIKVRT_PERSONAL_READING_PLAN_V1','profile_ref':sha256_identifier(encode(profile)),
        'person_id':profile['person_id'],'consumer':profile['consumer'],
        'catalog_ref':sha256_identifier(encode(catalog)),'routes':plans,
        'read_only':True,'effect_ack_done':False,'personal_twin_productive_acceptance':False,
        'identity_authentication_claimed':False,'general_learning_effectiveness_proved':False}


def main():
    catalog=json.loads((ROOT/'framework_catalog.json').read_text())
    graph=catalog_graph(catalog);static,external=static_graph(ROOT/'framework_sources/src',
                         '8273ef8127edccf4b357fdacdd17a1e6b0f3f87f')
    profile={'schema':'QIKVRT_PERSONAL_READING_PROFILE_V1','person_id':'person:ingolf-lohmann',
        'display_name':'Ingolf Lohmann','interests':[r['name']for r in catalog['reading_routes']],
        'consumer':'HUMAN','rights_scope':'READ_ONLY_CATALOG_NAVIGATION'}
    out=ROOT/'framework';out.mkdir(exist_ok=True)
    measurement={'schema':'QIKVRT_TYPED_FRAMEWORK_MEASUREMENT_V1',
        'catalog':summarize(graph),'static_imports':summarize(static),
        'qikvrt_imports_outside_selection':external,'catalog_is_historical_snapshot':True,
        'catalog_verified_at':catalog['verified_at_utc'],
        'live_mesh_measured':False,'universal_personal_digital_twin_proved':False}
    for name,value in [('MEASUREMENT.json',measurement),('PROFILE_INGOLF_LOHMANN.json',profile),
                       ('READING_PLAN_HUMAN.json',reading_plan(profile,catalog)),
                       ('READING_PLAN_ARTIFICIAL.json',reading_plan(dict(profile,consumer='ARTIFICIAL'),catalog))]:
        (out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    lines=['# QIKVRT: Lesepfade nach Interesse','',
        'Gemessen wird der ausdrücklich benannte Katalogstand vom 11.10.2026. Thematische Empfehlungen und statische Importe sind getrennte Relationstypen; sie sind keine beobachteten produktiven Wirkungsketten.','',
        'Die gleiche Profilstruktur kann für eine andere Person verwendet werden. Das überträgt weder Datenrechte noch Identität, Autorisierung oder eine produktiv bestätigte Digital-Twin-Instanz.','']
    plan=reading_plan(profile,catalog)
    for route in plan['routes']:
        lines+=['## '+route['interest'],'',route['purpose'],'']
        for s in route['steps']:lines.append(str(s['order'])+'. '+s['title']+' — '+s['record_url'])
        lines+=['','Gerichteter struktureller Abstand innerhalb des deklarierten Lesegrafen: '+str(route['route_first_to_last']['distance'])+' Empfehlungsschritte vom ursprünglichen Routenanfang zum Routenende. Ein redaktionell vorangestellter Round-Trip-Einstieg ist gesondert markiert.','']
    (out/'LESEPFAD_NACH_INTERESSE.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(measurement,ensure_ascii=False))


if __name__=='__main__':main()
