# QIKVRT Mutable State Integrity Reference

Version: 2.13.4

Deutsch: Setup-/Akzeptanz-/GUID-/Zielkonfigurationsdateien werden vor Deploy persistiert, sind aber bewusst nicht in SHA256SUMS.txt enthalten, weil sie zur Laufzeit erzeugt oder aktualisiert werden.

> **QIK-VRT CORRECTION: OPEN_NOT_INDEPENDENTLY_REVALIDATED; historical wording is retained in the owner changeset only.**

Role: node

Status: REFERENCE PASS REQUIRED
