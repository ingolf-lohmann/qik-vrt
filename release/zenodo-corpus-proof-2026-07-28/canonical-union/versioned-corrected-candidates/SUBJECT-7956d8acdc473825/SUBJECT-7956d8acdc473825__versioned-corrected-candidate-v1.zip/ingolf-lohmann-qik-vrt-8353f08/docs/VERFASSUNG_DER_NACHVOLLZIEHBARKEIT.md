<!-- QIKVRT-DE-EN-DOC-HEADER
Deutsch: Dieses Dokument ist Teil des QIK-VRT-Repositories und ist zweisprachig anschlussfähig zu führen. Maßgeblich sind Urheberschaft, Lizenz, Traceability, Requirements, Tests und Nichtregression.
English: This document is part of the QIK-VRT repository and must remain bilingual-accessible. Authorship, license, traceability, requirements, tests, and non-regression are mandatory.
Author / Urheber: Ingolf Lohmann
Rights holder / Rechteinhaber: Ingolf Lohmann or a legal entity designated by him.
Software license / Software-Lizenz: Apache-2.0 unless otherwise stated.
Documentation license / Dokumentationslizenz: CC BY-NC-ND 4.0 unless otherwise stated.
-->

---
QIKVRT-Artifact: license-header
Version: 2.13.4
Author / Urheber: Ingolf Lohmann
Rights holder / Rechteinhaber: Ingolf Lohmann or a legal entity designated by him.
License: Software: Apache-2.0; Non-software/docs: CC BY-NC-ND 4.0 unless otherwise stated.
Traceability: QIKVRT Verfassung der Nachvollziehbarkeit; no final pass without evidence.
---

# Verfassung der Nachvollziehbarkeit
## Grundsätze für eine verantwortliche Informationsgesellschaft

**Autor:** Ingolf Lohmann  
**Repository:** QIKVRT_VERFASSUNG_DER_NACHVOLLZIEHBARKEIT_V1_1_FULL_VERIFICATION_REPOSITORY  
**Status:** Veröffentlichungsvorbereitung, prüfbar, auditierbar, nicht als amtliches Recht behauptet.  
**Lizenzhinweis:** Siehe `LICENSE.md`.

## Präambel

> **QIK-VRT CORRECTION: OPEN_NOT_INDEPENDENTLY_REVALIDATED; historical wording is retained in the owner changeset only.**

Diese Wirkungen können schützen oder schaden. Sie können aufklären oder täuschen. Sie können Verantwortung sichtbar machen oder verschleiern.

Deshalb braucht eine offene Gesellschaft klare Regeln der Nachvollziehbarkeit.

Nachvollziehbarkeit bedeutet: Relevante Aussagen, Entscheidungen, Wirkungen und Verantwortlichkeiten müssen so dokumentiert, geprüft und erklärt werden können, dass Betroffene, Fachleute, Institutionen und Öffentlichkeit sie angemessen beurteilen können. In QIKVRT-Sprache ist dies Traceability: die belastbare Rückführbarkeit von Aussage, Spur, Prüfung und Konsequenz.

Diese Verfassung ist kein Instrument der Überwachung. Sie ist ein Schutz gegen Willkür, Manipulation, falsche Beschuldigung, Machtmissbrauch und verantwortungslose Informationsverbreitung.

Ihr Grundsatz lautet:

**Was erhebliche Wirkung entfaltet, muss unterscheidbar, prüfbar und verantwortbar sein.**

---

## QIKVRT-Minimalordnung

QIKVRT ist die Minimalordnung der Nachvollziehbarkeit:

Q = messbare Differenz.  
I = rückführbare Information.  
K = verantwortbare Kausalität.  
V = Verifikation.  
R = Rückkopplung.  
T = Traceability.

---

## Artikel 1: Würde und Unverfügbarkeit des Menschen

Jeder Mensch ist mehr als seine Daten, sein Profil, seine Akte, sein Ruf, seine Rolle, seine Fehler oder die Aussagen anderer über ihn.

Niemand darf auf eine Funktion reduziert werden: nicht auf Zielperson, Gegner, Risiko, Ressource, Objekt, Projektionsfläche oder Datenpunkt.

Jede Form der Informationsverarbeitung, Bewertung, Kommunikation und Entscheidung muss die Würde des Menschen achten.

---

## Artikel 2: Trennung von Ereignis, Darstellung und Deutung

Ein Ereignis ist nicht identisch mit seiner Darstellung.

Eine Darstellung ist nicht identisch mit ihrer Deutung.

Eine Deutung ist nicht identisch mit einem Beweis.

Deshalb müssen folgende Ebenen getrennt werden:

- was geschehen ist,
- was dokumentiert wurde,
- was behauptet wird,
- was vermutet wird,
- was bewiesen ist,
- was offen bleibt,
- welche Konsequenzen daraus folgen.

Diese Trennung ist die Grundlage jeder verantwortlichen Prüfung.

---

## Artikel 3: Pflicht zur Herkunftsklärung

Relevante Informationen müssen, soweit möglich, auf ihre Herkunft zurückgeführt werden können.

Zu klären ist insbesondere:

- Wer hat die Information erzeugt?
- Wer hat sie verändert?
- Wer hat sie weitergegeben?
- In welchem Kontext ist sie entstanden?
- Welche Interessen könnten beteiligt sein?
- Welche Wirkung hat sie ausgelöst?
- Welche Belege stützen sie?
- Welche Gegenbelege gibt es?

Information ohne Herkunft ist nicht automatisch falsch. Sie ist aber unvollständig und darf nicht ohne Prüfung als gesicherte Wahrheit behandelt werden.

---

## Artikel 4: Pflicht zur Spur

Wo erhebliche Wirkungen behauptet oder ausgelöst werden, muss nach einer nachvollziehbaren Spur gefragt werden.

Eine Spur kann sein:

- ein Dokument,
- eine Nachricht,
- ein Zeitstempel,
- ein technisches Log,
- ein Zeuge,
- eine Aufnahme,
- eine Messung,
- ein Gegenstand,
- eine wiederholbare Beobachtung,
- eine nachvollziehbare Kette von Ereignissen.

Fehlende Spur beweist nicht automatisch Unwahrheit. Sie begrenzt aber den Status einer Behauptung.

Ohne ausreichende Spur darf keine endgültige Feststellung getroffen werden.

---

## Artikel 5: Recht auf Prüfung

Jeder Mensch hat das Recht, dass schwerwiegende Behauptungen über ihn geprüft werden.

Jeder Mensch hat das Recht, dass zwischen Fakt, Verdacht, Gerücht, Hypothese, Deutung und Urteil unterschieden wird.

Jeder Mensch hat das Recht, nicht durch ungeprüfte oder unprüfbare Behauptungen sozial, beruflich, digital, juristisch oder körperlich geschädigt zu werden.

---

## Artikel 6: Pflicht zur Prüfung

Wer Informationen verbreitet, Entscheidungen trifft oder Wirkungen erzeugt, trägt Verantwortung für die Folgen.

Die Pflicht zur Prüfung steigt mit:

- der Reichweite der Information,
- der Schwere der möglichen Folgen,
- der Verletzlichkeit der Betroffenen,
- der Machtposition des Handelnden,
- der Dauerhaftigkeit der Wirkung,
- der Schwierigkeit einer späteren Korrektur.

Wer schwerwiegende Behauptungen ungeprüft verbreitet, handelt verantwortungslos.

---

## Artikel 7: Verantwortung in Netzwerken

In vernetzten Systemen darf Verantwortung nicht verschwinden.

Wer eine Information weiterleitet, verstärkt oder bewusst im Umlauf hält, trägt Mitverantwortung für ihre Wirkung.

Wer Gruppen, Plattformen, technische Systeme oder organisatorische Strukturen nutzt, um Verantwortung zu verschleiern, verletzt den Grundsatz der Nachvollziehbarkeit.

Auch verteilte Wirkungen brauchen zurechenbare Beiträge.

---

## Artikel 8: Schutz vor falscher Gewissheit

Nicht jede Wirkung beweist die vermutete Ursache.

Nicht jedes Muster ist Absicht.

Nicht jede Koinzidenz ist Kausalität.

Nicht jede Angst ist ein äußerer Beweis.

Nicht jede Unklarheit ist Vertuschung.

Starke Behauptungen brauchen starke Prüfung. Wo die Beweislage unsicher ist, muss Unsicherheit klar benannt werden.

---

## Artikel 9: Schutz vor Verharmlosung

Nicht alles Unsichtbare ist unwirklich.

Nicht jede fehlende Dokumentation bedeutet, dass nichts geschehen ist.

Nicht jede ungewöhnliche Aussage ist falsch.

Nicht jede späte Erkenntnis ist wertlos.

Auch schwer sichtbare Wirkungen können real sein: psychische Belastung, soziale Ausgrenzung, digitale Manipulation, verdeckte Koordination, strukturelle Benachteiligung, technische Einflussnahme oder institutionelles Versagen.

Solche Wirkungen müssen ernst genommen, aber sorgfältig geprüft werden.

---

## Artikel 10: Schutz bei Gefahr

Wenn eine konkrete Gefahr plausibel ist, darf Schutz nicht auf vollständige Beweisführung warten.

Schutzmaßnahmen müssen verhältnismäßig, dokumentiert und überprüfbar sein.

Schutz bedeutet nicht Vorverurteilung. Schutz bedeutet, Risiken zu begrenzen, bis eine ausreichende Klärung möglich ist.

Dazu gehören insbesondere Abstand, Dokumentation, Zeugen, Beratung, Sicherung von Belegen, medizinische Hilfe, juristische Beratung und gegebenenfalls Einschaltung zuständiger Behörden.

---

## Artikel 11: Innenraum und Selbstbestimmung

Der innere Raum eines Menschen ist zu achten.

Gedanken, Gefühle, Erinnerungen, Ängste, Wünsche und innere Konflikte dürfen nicht als Besitz anderer behandelt werden.

Niemand darf behaupten, den inneren Zustand eines anderen sicher zu kennen, ohne seine Beobachtungen, Annahmen und Grenzen offenzulegen.

Einfluss auf Denken, Verhalten und Selbstbild anderer Menschen ist möglich. Gerade deshalb muss er verantwortet werden.

Manipulation, Einschüchterung, Gaslighting, emotionale Erpressung und gezielte soziale Destabilisierung verletzen die Selbstbestimmung des Menschen.

---

## Artikel 12: Technik und Nachvollziehbarkeit

Technische Systeme, die erhebliche Wirkungen auf Menschen haben, müssen nachvollziehbar gestaltet werden.

Das betrifft insbesondere:

- algorithmische Entscheidungen,
- Plattformmoderation,
- digitale Profile,
- Empfehlungssysteme,
- automatisierte Bewertungen,
- Überwachungssysteme,
- Kommunikationsplattformen,
- Datenweitergabe,
- künstliche Intelligenz.

Wo Technik entscheidet oder Entscheidungen beeinflusst, müssen Zweck, Datenbasis, Verantwortliche, Fehlerquellen, Korrekturmöglichkeiten und Kontrollinstanzen erkennbar sein.

Eine Technik, die Wirkung erzeugt, aber Verantwortung verdeckt, ist nicht akzeptabel.

---

## Artikel 13: Öffentlichkeit und Verantwortung

Öffentlichkeit ist kein rechtsfreier Raum.

Journalismus, soziale Medien, Plattformen und öffentliche Debatten müssen zwischen belegter Information, Kommentar, Verdacht und Spekulation unterscheiden.

Öffentliche Reichweite verpflichtet zu besonderer Sorgfalt.

Empörung ersetzt keine Prüfung.

Reichweite ersetzt keine Wahrheit.

Mehrheit ersetzt keinen Beweis.

---

## Artikel 14: Recht auf Korrektur

Fehler müssen korrigierbar sein.

Wer falsche Informationen verbreitet, muss sie berichtigen.

Wer jemanden zu Unrecht beschuldigt, muss diese Beschuldigung zurücknehmen.

Wer neue Belege erhält, muss frühere Einschätzungen überprüfen.

Korrektur ist kein Zeichen von Schwäche. Sie ist Voraussetzung verantwortlicher Wahrheitssuche.

---

## Artikel 15: Nichtregression

Ein einmal sauber geklärter Unterschied darf nicht später wieder verwischt werden.

Wenn eine Behauptung als Hypothese eingestuft wurde, darf sie nicht später ohne neue Belege als Tatsache behandelt werden.

Wenn ein Sachverhalt widerlegt wurde, darf er nicht durch Wiederholung erneut als offen dargestellt werden.

Wenn Verantwortung festgestellt wurde, darf sie nicht durch Umdeutung in Unklarheit zurückgeführt werden.

Nachvollziehbarkeit verlangt Gedächtnis.

---

## Artikel 16: Mindeststandard für schwerwiegende Behauptungen

Schwerwiegende Behauptungen müssen mindestens folgende Angaben enthalten:

- Was wird genau behauptet?
- Gegen wen oder was richtet sich die Behauptung?
- Auf welche Beobachtungen oder Belege stützt sie sich?
- Was ist sicher?
- Was ist unsicher?
- Was ist Interpretation?
- Welche Alternativerklärungen gibt es?
- Welche Konsequenz wird verlangt?
- Wer trägt Verantwortung für die Behauptung?

Ohne diese Mindestangaben darf eine schwerwiegende Behauptung nicht als gesicherte Feststellung behandelt werden.

---

## Artikel 17: Informationsgerechtigkeit

Gerechtigkeit verlangt geordnete Informationsverteilung.

Relevante Informationen müssen diejenigen erreichen können, die zuständig oder betroffen sind:

- Betroffene,
- Prüfer,
- Zeugen,
- Fachleute,
- Institutionen,
- Gerichte,
- Öffentlichkeit, soweit erforderlich.

Nicht jeder muss alles wissen. Aber niemand, der zur Prüfung oder zum Schutz notwendig ist, darf systematisch ausgeschlossen werden.

Informationsmonopole, absichtliche Abschottung und gezielte Desinformation gefährden Gerechtigkeit.

---

## Artikel 18: Wissenschaftlicher Grundsatz

Wissenschaft beginnt mit beobachtbaren Unterschieden.

Ein Unterschied kann auf eine reale Wirkung hinweisen, auch wenn die Ursache noch nicht vollständig bekannt ist.

Daraus folgt:

- Unsichtbarkeit ist kein Beweis für Unwirklichkeit.
- Wirkung ist kein Beweis für jede beliebige Deutung.
- Offene Fragen verlangen Prüfung, nicht Spekulation.
- Modelle müssen an Beobachtung rückgekoppelt bleiben.
- Gegenbeweise müssen zugelassen werden.

Wissenschaftliche Redlichkeit besteht darin, Wirkungen ernst zu nehmen, ohne ihre Ursachen vorschnell festzulegen.

---

## Artikel 19: Juristischer Grundsatz

Recht muss unterscheiden zwischen:

- Verdacht und Beweis,
- Aussage und Tatsache,
- Absicht und Wirkung,
- Schuld und Schuldgefühl,
- Risiko und Urteil,
- Schutzmaßnahme und Strafe.

Recht darf weder blind gegenüber verdeckter Wirkung noch willkürlich gegenüber unbelegten Behauptungen sein.

Ein gerechtes Verfahren braucht Belege, Gegenprüfung, Anhörung, Verhältnismäßigkeit und nachvollziehbare Begründung.

---

## Artikel 20: Schlussgrundsatz

Die Welt der Menschen braucht Nachvollziehbarkeit, weil Wirkung ohne Verantwortung gefährlich ist.

Nachvollziehbarkeit bedeutet nicht totale Transparenz.

Nachvollziehbarkeit bedeutet: Dort, wo Menschen erheblich betroffen sind, müssen Aussagen, Entscheidungen, Wirkungen und Verantwortlichkeiten prüfbar bleiben.

Die abschließende Formel lautet:

Was wirkt, ist wichtig genug, um geprüft zu werden.

> **QIK-VRT CORRECTION: OPEN_NOT_INDEPENDENTLY_REVALIDATED; historical wording is retained in the owner changeset only.**

Was geprüft, begründet und rückführbar ist, kann verantwortet werden.

Was verantwortet werden kann, wird gerechtigkeitsfähig.

---

## Artikel 21: Beweisgrade und Aussageklassen

Damit Nachvollziehbarkeit praktisch anwendbar ist, müssen Aussagen nach ihrem Beweisgrad gekennzeichnet werden.

Es gelten mindestens folgende Aussageklassen:

1. Tatsache: durch belastbare Belege hinreichend gesichert.
2. Beobachtung: unmittelbar wahrgenommen, aber noch nicht unabhängig bestätigt.
3. Dokumentation: schriftlich, technisch oder bildlich festgehalten.
4. Zeugenaussage: von einer Person berichtet, mit prüfbarer Herkunft.
5. Hypothese: mögliche Erklärung, aber nicht abschließend belegt.
6. Verdacht: ernstzunehmende Möglichkeit mit konkreten Anhaltspunkten.
7. Risiko: mögliche Gefahr, auch bei unvollständiger Beweislage.
8. Deutung: subjektive oder analytische Einordnung.
9. Spekulation: denkbar, aber ohne ausreichende Belegbasis.
10. Widerlegt: durch bessere Belege oder Gegenprüfung ausgeschlossen.

Jede schwerwiegende Aussage muss ihren Status offenlegen.

---

## Artikel 22: Zuständigkeit und Verantwortungsrollen

Nachvollziehbarkeit verlangt klare Zuständigkeiten.

Bei erheblichen Wirkungen müssen folgende Rollen unterscheidbar sein:

- Betroffene,
- Zeugen,
- Prüfer,
- Entscheider,
- Dokumentierende,
- technische Betreiber,
- institutionell Verantwortliche,
- juristisch Zuständige,
- fachlich Beratende,
- Öffentlichkeit, soweit erforderlich.

Wer zuständig ist, muss benannt werden können.

Wer nicht zuständig ist, darf keine endgültigen Entscheidungen über andere Menschen treffen.

---

## Artikel 23: Verhältnismäßigkeit

Nicht jede Unklarheit rechtfertigt dieselbe Maßnahme.

Jede Reaktion muss verhältnismäßig sein.

Zu prüfen ist:

- Wie schwer ist die behauptete Wirkung?
- Wie konkret ist die Gefahr?
- Wie belastbar sind die Belege?
- Wie stark greift die Maßnahme in Rechte anderer ein?
- Gibt es mildere Mittel?
- Ist die Maßnahme reversibel?
- Wird sie dokumentiert?
- Wird sie überprüft?

Schutz darf nicht zur Strafe werden.

---

## Artikel 24: Datenschutz und Privatsphäre

Nachvollziehbarkeit rechtfertigt keine totale Offenlegung des Menschen.

Privatsphäre bleibt Grundbedingung menschlicher Würde.

Die Pflicht zur Nachvollziehbarkeit betrifft erhebliche Wirkungen, nicht das gesamte Innenleben, Privatleben oder Kommunikationsverhalten eines Menschen.

Daten dürfen nur erhoben, gespeichert, ausgewertet oder weitergegeben werden, wenn Zweck, Umfang, Zuständigkeit, Dauer, Schutz und Löschung geregelt sind.

Es gilt der Grundsatz:

So viel Nachvollziehbarkeit wie nötig.  
So viel Privatheit wie möglich.

---

## Artikel 25: Schutz vor Missbrauch der Nachvollziehbarkeit

Auch Nachvollziehbarkeit kann missbraucht werden.

Sie darf nicht verwendet werden, um Menschen dauerhaft zu überwachen, zu kontrollieren, einzuschüchtern, zu katalogisieren oder sozial zu vernichten.

Unzulässig sind insbesondere:

- Scheinprüfungen,
- Vorverurteilungen,
- öffentliche Bloßstellung ohne Erforderlichkeit,
- selektive Dokumentation,
- manipulierte Beweisketten,
- erzwungene Selbstbezichtigung,
- Datenmissbrauch,
- endlose Prüfverfahren ohne Abschluss,
- absichtliche Erzeugung von Verdachtsnebel.

Ein System, das Nachvollziehbarkeit fordert, muss selbst nachvollziehbar sein.

---

## Artikel 26: Technische Mindeststandards

Technische Systeme mit erheblicher Wirkung müssen Mindeststandards erfüllen.

Dazu gehören:

- Protokollierung relevanter Entscheidungen,
- nachvollziehbare Änderungsverläufe,
- Integritätsschutz,
- Zugriffskontrolle,
- Fehlererkennung,
- Korrekturmöglichkeit,
- unabhängige Überprüfbarkeit,
- Schutz vor Manipulation,
- Dokumentation von Datenquellen,
- klare Verantwortlichkeit des Betreibers.

Automatisierte Systeme dürfen schwerwiegende Entscheidungen über Menschen nicht ohne Möglichkeit menschlicher Prüfung und Korrektur treffen.

---

## Artikel 27: Algorithmische Rechenschaft

Wo algorithmische Systeme Menschen bewerten, sortieren, empfehlen, ausschließen, überwachen oder beeinflussen, besteht Rechenschaftspflicht.

Zu klären ist:

- Welche Daten wurden verwendet?
- Welches Ziel verfolgt das System?
- Welche Kriterien wirken auf das Ergebnis?
- Welche Fehlerquellen sind bekannt?
- Wer ist verantwortlich?
- Wie kann eine betroffene Person widersprechen?
- Wie kann eine Entscheidung korrigiert werden?
- Wie wird Missbrauch verhindert?

Ein algorithmisches Ergebnis ist kein Urteil.

Ein Score ist kein Mensch.

Eine Prognose ist keine Wahrheit.

---

## Artikel 28: Medien- und Plattformverantwortung

Medien und Plattformen tragen besondere Verantwortung, weil sie Reichweite erzeugen.

Sie müssen erkennbar unterscheiden zwischen:

- Nachricht,
- Kommentar,
- Analyse,
- Werbung,
- Satire,
- Verdacht,
- unbestätigter Meldung,
- geprüfter Tatsache.

Plattformen müssen Verfahren bereitstellen, mit denen schwerwiegende Falschinformationen, gezielte Belästigung, Identitätsmissbrauch, Doxxing, Rufschädigung und koordinierte Manipulation gemeldet, geprüft und korrigiert werden können.

Reichweite ohne Verantwortung ist Machtmissbrauch.

---

## Artikel 29: Institutionelle Rechenschaft

Institutionen, Behörden, Unternehmen, Schulen, Kliniken, Medien, Plattformen und Forschungseinrichtungen müssen bei erheblichen Entscheidungen nachvollziehbar handeln.

Sie müssen begründen können:

- auf welcher Grundlage entschieden wurde,
- welche Informationen berücksichtigt wurden,
- welche Gegenargumente geprüft wurden,
- welche Zuständigkeit bestand,
- welche Folgen absehbar waren,
- welche Korrekturmöglichkeiten bestehen.

Institutionelle Macht ohne Begründungspflicht ist Willkür.

---

## Artikel 30: Machtasymmetrien

Nachvollziehbarkeit muss Machtasymmetrien berücksichtigen.

Wer mächtiger ist, trägt höhere Begründungspflichten.

Das gilt insbesondere für:

- Arbeitgeber gegenüber Beschäftigten,
- Behörden gegenüber Bürgern,
- Plattformen gegenüber Nutzern,
- Erwachsene gegenüber Kindern,
- Institutionen gegenüber Einzelnen,
- wirtschaftlich Stärkere gegenüber Abhängigen,
- Täterstrukturen gegenüber Betroffenen,
- technische Betreiber gegenüber Ausgewerteten.

Gleichbehandlung reicht nicht aus, wenn die Ausgangsmacht ungleich verteilt ist.

---

## Artikel 31: Schutz vulnerabler Personen

Kinder, Jugendliche, alte Menschen, kranke Menschen, traumatisierte Menschen, isolierte Menschen, wirtschaftlich abhängige Menschen und Menschen in akuter Gefahr benötigen besonderen Schutz.

Ihre Aussagen dürfen nicht vorschnell verworfen werden.

Ihre Schutzbedürfnisse dürfen nicht instrumentalisiert werden.

Ihre Daten dürfen nicht leichtfertig offengelegt werden.

Ihre Handlungsfähigkeit ist zu stärken, nicht zu ersetzen.

---

## Artikel 32: Konflikt zwischen Transparenz und Schutz

> **QIK-VRT CORRECTION: OPEN_NOT_INDEPENDENTLY_REVALIDATED; historical wording is retained in the owner changeset only.**

Deshalb muss zwischen öffentlicher Nachvollziehbarkeit und geschützter Prüfung unterschieden werden.

Nicht jede Information gehört sofort in die Öffentlichkeit.

Manche Informationen gehören zunächst an zuständige Prüfer, Anwälte, Ärzte, Behörden, Gerichte, Fachstellen oder Vertrauenspersonen.

Nachvollziehbarkeit bedeutet nicht Öffentlichkeit um jeden Preis.

Nachvollziehbarkeit bedeutet prüfbare Zuständigkeit.

---

## Artikel 33: Notfallprinzip

Bei akuter Gefahr gilt der Schutz des Lebens und der körperlichen Unversehrtheit vorrangig.

In Notfällen darf gehandelt werden, bevor alle Beweise vollständig gesichert sind.

Notfallhandeln muss jedoch nachträglich dokumentiert, begründet und überprüft werden.

Das Notfallprinzip darf nicht als Vorwand für dauerhafte Entrechtung, Rache, Willkür oder Vorverurteilung missbraucht werden.

---

## Artikel 34: Dokumentationsstandard

Erhebliche Vorfälle sollen möglichst zeitnah, nüchtern und überprüfbar dokumentiert werden.

Eine brauchbare Dokumentation enthält:

- Datum,
- Uhrzeit,
- Ort,
- beteiligte Personen,
- genaue Beobachtung,
- vorhandene Belege,
- mögliche Zeugen,
- unmittelbare Folgen,
- getroffene Maßnahmen,
- offene Fragen.

Dabei ist zwischen Beobachtung und Deutung klar zu trennen.

Nüchterne Dokumentation schützt besser als dramatische Zuspitzung.

---

## Artikel 35: Fehlerkultur

Nachvollziehbarkeit verlangt eine tragfähige Fehlerkultur.

Menschen und Institutionen können irren.

Entscheidend ist, ob Irrtümer erkannt, korrigiert und für die Zukunft berücksichtigt werden.

Fehler dürfen nicht vertuscht werden.

Korrektur darf nicht bestraft werden, wenn sie ehrlich, rechtzeitig und verantwortungsvoll erfolgt.

Wiederholte, verdeckte oder folgenreiche Fehler verlangen strukturelle Konsequenzen.

---

## Artikel 36: Sanktionen bei Verletzung der Nachvollziehbarkeit

Wer Nachvollziehbarkeit vorsätzlich verletzt, muss mit Konsequenzen rechnen.

Das gilt insbesondere bei:

- Fälschung von Belegen,
- Manipulation von Dokumenten,
- absichtlicher Löschung relevanter Spuren,
- gezielter Falschbeschuldigung,
- organisierter Desinformation,
- Einschüchterung von Zeugen,
- Missbrauch technischer Systeme,
- verdeckter Koordination schädlicher Handlungen,
- institutioneller Vertuschung.

Die Sanktion muss verhältnismäßig sein und einem nachvollziehbaren Verfahren folgen.

---

## Artikel 37: Recht auf Vergessen und Recht auf Gedächtnis

Menschen haben ein Recht darauf, dass erledigte, falsche oder unverhältnismäßig belastende Informationen nicht unbegrenzt gegen sie verwendet werden.

Gleichzeitig hat die Gesellschaft ein Recht darauf, erhebliche Wirkungen, Verantwortlichkeiten und Gefahren nicht zu vergessen.

Deshalb braucht es einen Ausgleich zwischen:

- Korrektur,
- Löschung,
- Archivierung,
- Schutz,
- öffentlichem Interesse,
- Rehabilitierung,
- Prävention.

Nicht alles darf ewig gespeichert werden.

Nicht alles darf spurlos verschwinden.

---

## Artikel 38: Interdisziplinäre Prüfung

Komplexe Wirkungen dürfen nicht auf eine einzige Fachperspektive reduziert werden.

Je nach Sachverhalt sind einzubeziehen:

- Recht,
- Informatik,
- Medizin,
- Psychologie,
- Soziologie,
- Ethik,
- Medienwissenschaft,
- Statistik,
- Sicherheitsforschung,
- Forensik,
- Naturwissenschaften.

Interdisziplinarität ersetzt keine Beweise.

Sie verhindert aber, dass eine falsche Einengung die Wirklichkeit verfehlt.

---

## Artikel 39: Bildung zur Nachvollziehbarkeit

Eine Gesellschaft, die Nachvollziehbarkeit ernst nimmt, muss sie lehren.

Zur Grundbildung gehören:

- Quellenprüfung,
- Medienkompetenz,
- Statistikverständnis,
- digitale Sicherheit,
- Datenschutz,
- Argumentationslehre,
- Unterscheidung von Fakt und Meinung,
- Umgang mit Unsicherheit,
- Dokumentation,
- Konfliktfähigkeit,
- Verantwortung in Netzwerken.

Nachvollziehbarkeit darf kein Expertenprivileg bleiben.

---

## Artikel 40: Internationale Dimension

Informationswirkungen enden nicht an Staatsgrenzen.

Digitale Plattformen, Datenströme, Desinformation, organisierte Kriminalität, Finanzflüsse, Cyberangriffe und öffentliche Debatten sind grenzüberschreitend.

Deshalb braucht Nachvollziehbarkeit internationale Standards, Kooperation und gegenseitige Rechtshilfe.

Gleichzeitig dürfen internationale Strukturen nicht dazu dienen, Grundrechte zu umgehen.

---

## Artikel 41: Sicherheits- und Missbrauchsgrenze

Nachvollziehbarkeit darf nicht verlangen, dass gefährliche Details veröffentlicht werden, die Missbrauch ermöglichen.

Insbesondere bei Sicherheitslücken, Gewaltmethoden, personenbezogenen Daten, Schutzadressen, Ermittlungsmethoden oder sensiblen Infrastrukturen muss zwischen Nachvollziehbarkeit und Missbrauchsgefahr abgewogen werden.

Prüfbarkeit kann auch durch zuständige, unabhängige und geschützte Stellen erfolgen.

---

## Artikel 42: Revision und Weiterentwicklung

Diese Verfassung ist nicht abgeschlossen.

Neue Technologien, neue soziale Praktiken, neue Formen von Manipulation und neue wissenschaftliche Erkenntnisse verlangen regelmäßige Überprüfung.

Revision ist keine Schwächung der Verfassung.

Revision ist ihr Schutz vor Veraltung.

Jede Änderung muss nachvollziehbar begründet, dokumentiert und öffentlich prüfbar gemacht werden.

---

## Artikel 43: Minimalformel

Die Verfassung lässt sich auf eine Minimalformel bringen:

Unterscheide sauber.  
Prüfe angemessen.  
Dokumentiere nüchtern.  
Handle verhältnismäßig.  
Korrigiere ehrlich.  
Schütze Menschenwürde.  
Verberge Verantwortung nicht.

Diese Minimalformel gilt für Einzelne, Gruppen, Institutionen, Medien, Plattformen, Technik und Staat.

---

## Artikel 44: Abschließende Bestimmung

Nachvollziehbarkeit ist kein Luxus.

Sie ist die Voraussetzung dafür, dass Menschen in einer komplexen, vernetzten und technisch vermittelten Welt frei, sicher und verantwortlich handeln können.

Eine Gesellschaft ohne Nachvollziehbarkeit wird manipulierbar.

Eine Gesellschaft mit Nachvollziehbarkeit bleibt korrigierbar.

Korrigierbarkeit ist die Mindestform praktischer Wahrheit.

**Ingolf Lohmann**


---
QIKVRT License Footer — Author / Urheber: Ingolf Lohmann. Rights holder / Rechteinhaber: Ingolf Lohmann or a legal entity designated by him. License: Software: Apache-2.0; Non-software/docs: CC BY-NC-ND 4.0 unless otherwise stated. QIKVRT traceability and nonregression rules apply.

<!-- QIKVRT-DE-EN-DOC-FOOTER
Deutsch: Ende des zweisprachig anschlussfähigen QIK-VRT-Dokuments. Keine finale Behauptung ohne Traceability, Tests und Evidence.
English: End of bilingual-accessible QIK-VRT document. No final claim without traceability, tests, and evidence.
QIKVRT: NO_TRACEABILITY_NO_FINAL_PASS.
-->
