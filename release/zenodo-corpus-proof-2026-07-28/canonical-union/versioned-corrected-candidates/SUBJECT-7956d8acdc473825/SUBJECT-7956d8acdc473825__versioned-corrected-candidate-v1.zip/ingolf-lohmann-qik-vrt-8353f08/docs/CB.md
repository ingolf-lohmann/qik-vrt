<!-- QIKVRT Document Header / Dokumentkopf
DE: Windows Admin- und Chocolatey-Bootstrap-Gate.
EN: Windows admin and Chocolatey bootstrap gate.
Author / Urheber: Ingolf Lohmann
Rights holder / Rechteinhaber: Ingolf Lohmann or a legal entity designated by him.
License: CC BY-NC-ND 4.0 unless otherwise stated.
-->
# DE: Windows Admin- und Chocolatey-Bootstrap

Vor weiterer Windows-Aktivitaet erzwingt `QIKVRT.cmd` Administratorrechte. Nach persistierter Urheber-/Lizenzakzeptanz und persistierter Repository-GUID wird Chocolatey installiert oder verwendet. Weitere Windows-Abhaengigkeiten, insbesondere Zig fuer den C-Build, werden ueber Chocolatey aufgeloest.

# EN: Windows Admin and Chocolatey Bootstrap

> **QIK-VRT CORRECTION: OPEN_NOT_INDEPENDENTLY_REVALIDATED; historical wording is retained in the owner changeset only.**

<!-- QIKVRT Document Footer / Dokumentfuß
DE: Keine GitHub-Remote-Mutation ohne Token und expliziten Deploy-Lauf.
EN: No GitHub remote mutation without token and explicit deploy run.
-->
