@echo off
setlocal EnableExtensions
title QIK-VRT V8.33 PUBLISH ZENODO RECORD

set "ROOT=%~dp0"
set "PS1=%ROOT%scripts\QIKVRT_ZENODO_DRAFT_V8_33.ps1"

echo ============================================================
echo QIK-VRT V8.33 PUBLISH ZENODO RECORD
echo ACHTUNG: oeffentliche Zenodo-Veroeffentlichung / DOI
echo ============================================================
echo.
echo Token-Scopes:
echo - deposit:write
echo - deposit:actions
echo.

if not exist "%PS1%" (
  echo BLOCK: Aktivierungsskript fehlt:
  echo %PS1%
  pause
  exit /b 20
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%" -Publish
set "RC=%ERRORLEVEL%"

echo.
echo QIK-VRT Zenodo-Publish-Aktivierung beendet mit Code %RC%.
echo Erfolgsdatei: zenodo_release_record.json
echo Blockdateien: zenodo_permission_block.json / zenodo_media_type_block.json / zenodo_error_block.json
echo.
pause
exit /b %RC%
