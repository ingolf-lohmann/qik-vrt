# QIK-VRT V8.33 Repository and Anticipatory Zenodo Fix

## Zweck

V8.33 führt die V8.32-Fehlerbehandlung fort und ergänzt den 415-Fix:

```text
403/401 -> zenodo_permission_block.json
415     -> zenodo_media_type_block.json
success -> zenodo_release_record.json
```

## Start

Draft:

```text
START_HERE_QIKVRT_V8_33_CREATE_ZENODO_DRAFT.bat
```

Publish:

```text
PUBLISH_QIKVRT_V8_33_ZENODO_RECORD.bat
```

## Payload

```text
QIKVRT_V8_26_ZENODO_DEPOSIT_READY_CUMULATIVE_RECORD_PACKAGE.zip
SHA256 = a905fd65e85d4c8905dcb91f67162a45d243abaaf9ce439d7a1847d4399a6294
```

## Wichtig

Diese Version persistiert den Fix zusätzlich in:

```text
repository/
anticipatory/
```
