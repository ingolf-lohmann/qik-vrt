@echo off
setlocal EnableExtensions
title QIK-VRT V8.33 CREATE ZENODO DRAFT

set "ROOT=%~dp0"
set "PS1=%ROOT%scripts\QIKVRT_ZENODO_DRAFT_V8_33.ps1"

echo ============================================================
echo QIK-VRT V8.33 CREATE ZENODO DRAFT
echo Repository + Anticipatory + Explicit JSON Content-Type Fix
echo ============================================================
echo.
echo Reparatur:
echo - JSON POST/PUT/PUBLISH mit -ContentType application/json
echo - 415 wird als zenodo_media_type_block.json persistiert
echo - 401/403 wird als zenodo_permission_block.json persistiert
echo - repository/ und anticipatory/ Schichten sind im Paket enthalten
echo.
echo Token-Scopes:
echo - Draft: deposit:write
echo - Publish: deposit:write + deposit:actions
echo.

if not exist "%PS1%" (
  echo BLOCK: Aktivierungsskript fehlt:
  echo %PS1%
  echo ZIP vollstaendig entpacken und nicht aus der Windows-ZIP-Vorschau starten.
  pause
  exit /b 20
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
set "RC=%ERRORLEVEL%"

echo.
echo QIK-VRT Zenodo-Draft-Aktivierung beendet mit Code %RC%.
echo Erfolgsdatei: zenodo_release_record.json
echo Blockdateien: zenodo_permission_block.json / zenodo_media_type_block.json / zenodo_error_block.json
echo.
pause
exit /b %RC%
