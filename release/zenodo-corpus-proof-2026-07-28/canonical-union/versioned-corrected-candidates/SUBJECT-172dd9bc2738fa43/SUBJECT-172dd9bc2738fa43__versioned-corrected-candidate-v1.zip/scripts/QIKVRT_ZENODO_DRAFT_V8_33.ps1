param(
  [switch]$Publish,
  [ValidateSet("production","sandbox")]
  [string]$Environment = "production"
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

function Write-JsonFile([string]$Path, [object]$Obj) {
  $Obj | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $Path -Encoding UTF8
}

function Fail([string]$Message, [int]$Code = 1) {
  Write-Host ""
  Write-Host "BLOCK: $Message" -ForegroundColor Red
  Write-Host ""
  exit $Code
}

function Pass([string]$Message) { Write-Host "[QIKVRT][PASS] $Message" -ForegroundColor Green }
function Info([string]$Message) { Write-Host "[QIKVRT] $Message" }

function Get-Sha256([string]$Path) {
  return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Read-TokenPlain {
  Write-Host ""
  Write-Host "Zenodo token wird lokal abgefragt. Nicht in ChatGPT kopieren." -ForegroundColor Yellow
  $secure = Read-Host "Zenodo token eingeben (Eingabe verborgen)" -AsSecureString
  $cred = New-Object System.Management.Automation.PSCredential("zenodo", $secure)
  return $cred.GetNetworkCredential().Password
}

function Get-ErrorResponseBody($Exception) {
  try {
    if ($Exception.Response -and $Exception.Response.GetResponseStream()) {
      $reader = New-Object System.IO.StreamReader($Exception.Response.GetResponseStream())
      return $reader.ReadToEnd()
    }
  } catch {}
  return ""
}

function Get-StatusCode($Exception) {
  try {
    if ($Exception.Response -and $Exception.Response.StatusCode) {
      return [int]$Exception.Response.StatusCode
    }
  } catch {}
  return -1
}

function Write-PermissionBlock(
  [string]$Path, [string]$Phase, [int]$StatusCode, [string]$ResponseBody,
  [string]$ApiBase, [bool]$Publish
) {
  $block = [ordered]@{
    RECORD_TYPE = "QIKVRT_ZENODO_PERMISSION_BLOCK"
    RESULT = "BLOCK"
    ERROR_CLASS = "ZENODO_TOKEN_SCOPE_INSUFFICIENT_OR_WRONG_ENVIRONMENT"
    SEVERITY = "BLOCK"
    PHASE = $Phase
    HTTP_STATUS = $StatusCode
    RESPONSE_BODY = $ResponseBody
    API_BASE = $ApiBase
    PUBLISH_REQUESTED = $Publish
    REQUIRED_SCOPES = $(if ($Publish) { @("deposit:write", "deposit:actions") } else { @("deposit:write") })
    OWNER_FIX = @(
      "Create a new Zenodo Personal Access Token locally",
      "For draft enable deposit:write",
      "For publish enable deposit:write and deposit:actions",
      "Use production token with https://zenodo.org/api",
      "Use sandbox token only with https://sandbox.zenodo.org/api"
    )
    EXTERNAL_EFFECT = "NOT_CREATED_OR_NOT_COMPLETED"
    DOI = $null
    RECORD_URL = $null
    GENERATED_AT_LOCAL = (Get-Date).ToString("o")
  }
  Write-JsonFile -Path $Path -Obj $block
}

function Write-MediaTypeBlock(
  [string]$Path, [string]$Phase, [int]$StatusCode, [string]$ResponseBody,
  [string]$ApiBase, [bool]$Publish
) {
  $block = [ordered]@{
    RECORD_TYPE = "QIKVRT_ZENODO_MEDIA_TYPE_BLOCK"
    RESULT = "BLOCK"
    ERROR_CLASS = "ZENODO_JSON_CONTENT_TYPE_MISSING_OR_INVALID"
    SEVERITY = "BLOCK"
    PHASE = $Phase
    HTTP_STATUS = $StatusCode
    RESPONSE_BODY = $ResponseBody
    API_BASE = $ApiBase
    PUBLISH_REQUESTED = $Publish
    REQUIRED_CONTENT_TYPE = "application/json for JSON POST/PUT/PUBLISH requests"
    IMPLEMENTED_FIX = "Invoke-RestMethod uses -ContentType 'application/json' explicitly for JSON requests"
    EXTERNAL_EFFECT = "NOT_CREATED_OR_NOT_COMPLETED"
    DOI = $null
    RECORD_URL = $null
    GENERATED_AT_LOCAL = (Get-Date).ToString("o")
  }
  Write-JsonFile -Path $Path -Obj $block
}

function Invoke-ZenodoJson(
  [string]$Phase,
  [string]$Method,
  [string]$Uri,
  [hashtable]$Headers,
  [string]$Body,
  [string]$PermissionBlock,
  [string]$MediaTypeBlock,
  [string]$ApiBase,
  [bool]$Publish
) {
  try {
    return Invoke-RestMethod -Method $Method -Uri $Uri -Headers $Headers -ContentType "application/json" -Body $Body
  } catch {
    $status = Get-StatusCode $_.Exception
    $body = Get-ErrorResponseBody $_.Exception
    if ($status -eq 401 -or $status -eq 403) {
      Write-PermissionBlock -Path $PermissionBlock -Phase $Phase -StatusCode $status -ResponseBody $body -ApiBase $ApiBase -Publish $Publish
      Fail "Zenodo Permission/Auth Block in Phase $Phase. zenodo_permission_block.json wurde geschrieben." 43
    }
    if ($status -eq 415) {
      Write-MediaTypeBlock -Path $MediaTypeBlock -Phase $Phase -StatusCode $status -ResponseBody $body -ApiBase $ApiBase -Publish $Publish
      Fail "Zenodo 415 Unsupported Media Type in Phase $Phase. zenodo_media_type_block.json wurde geschrieben." 45
    }
    throw
  }
}

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent $ScriptDir
Set-Location -LiteralPath $Root

$ApiBase = $(if ($Environment -eq "sandbox") { "https://sandbox.zenodo.org/api" } else { "https://zenodo.org/api" })
$Payload = Join-Path $Root "payload\QIKVRT_V8_26_ZENODO_DEPOSIT_READY_CUMULATIVE_RECORD_PACKAGE.zip"
if (!(Test-Path -LiteralPath $Payload)) {
  $candidate = Get-ChildItem -LiteralPath (Join-Path $Root "payload") -Filter "*.zip" -File | Select-Object -First 1
  if ($candidate) { $Payload = $candidate.FullName }
}
$PayloadSidecar = "$Payload.sha256"
$Metadata = Join-Path $Root "metadata\zenodo_metadata_v8_33.json"
$PreflightEvidence = Join-Path $Root "activation_preflight_v8_33.json"
$ZenodoEvidence = Join-Path $Root "zenodo_release_record.json"
$PermissionBlock = Join-Path $Root "zenodo_permission_block.json"
$MediaTypeBlock = Join-Path $Root "zenodo_media_type_block.json"
$ErrorBlock = Join-Path $Root "zenodo_error_block.json"

Info "QIK-VRT V8.33 Repository + Anticipatory Zenodo 415 Content-Type Fix startet."
Info "Root: $Root"
Info "API: $ApiBase"
Write-Host ""
Write-Host "HTTP-Fix aktiv:" -ForegroundColor Cyan
Write-Host "  JSON POST/PUT/PUBLISH: -ContentType application/json"
Write-Host "  File Upload: application/octet-stream / text/plain"
Write-Host ""
Write-Host "Token-Scopes:" -ForegroundColor Cyan
Write-Host "  Draft:   deposit:write"
Write-Host "  Publish: deposit:write + deposit:actions"
Write-Host ""

$preflight = [ordered]@{
  activation_standard = "V8.33_REPOSITORY_AND_ANTICIPATORY_EXPLICIT_JSON_CONTENTTYPE_FIX"
  root = $Root
  api_base = $ApiBase
  environment = $Environment
  publish_requested = [bool]$Publish
  required_scopes = $(if ($Publish) { @("deposit:write", "deposit:actions") } else { @("deposit:write") })
  required_content_type_for_json = "application/json"
  repository_layer = "PERSISTED"
  anticipatory_layer = "PERSISTED"
  payload = $Payload
  sidecar = $PayloadSidecar
  metadata = $Metadata
  payload_exists = (Test-Path -LiteralPath $Payload)
  sidecar_exists = (Test-Path -LiteralPath $PayloadSidecar)
  metadata_exists = (Test-Path -LiteralPath $Metadata)
  payload_sha256 = ""
  sidecar_contains_payload_sha256 = $false
  result = "PENDING"
  created_at = (Get-Date).ToString("o")
}

if (!(Test-Path -LiteralPath $Payload)) {
  $preflight.result = "BLOCK_MISSING_PAYLOAD"
  Write-JsonFile -Path $PreflightEvidence -Obj $preflight
  Fail "Payload fehlt. ZIP vollstaendig entpacken: $Payload" 21
}
if (!(Test-Path -LiteralPath $PayloadSidecar)) {
  $preflight.result = "BLOCK_MISSING_SIDECAR"
  Write-JsonFile -Path $PreflightEvidence -Obj $preflight
  Fail "Sidecar fehlt. Erwartet: $PayloadSidecar" 22
}
if (!(Test-Path -LiteralPath $Metadata)) {
  $preflight.result = "BLOCK_MISSING_METADATA"
  Write-JsonFile -Path $PreflightEvidence -Obj $preflight
  Fail "Metadata fehlt. Erwartet: $Metadata" 23
}

$payloadHash = Get-Sha256 $Payload
$preflight.payload_sha256 = $payloadHash
$sideText = Get-Content -LiteralPath $PayloadSidecar -Raw
if ($sideText -notmatch $payloadHash) {
  $preflight.result = "BLOCK_SIDECAR_MISMATCH"
  Write-JsonFile -Path $PreflightEvidence -Obj $preflight
  Fail "Sidecar passt nicht zum Payload. payload=$payloadHash" 24
}
$preflight.sidecar_contains_payload_sha256 = $true
$preflight.result = "PASS_PREFLIGHT_THEN_CONTINUE_TO_ZENODO"
Write-JsonFile -Path $PreflightEvidence -Obj $preflight

Pass "Preflight OK"
Pass "Payload SHA256 = $payloadHash"

if ($Publish) {
  Write-Host ""
  Write-Host "WARNUNG: Publish erzeugt einen oeffentlichen Zenodo-Record." -ForegroundColor Yellow
  $confirm = Read-Host "Zum Publizieren exakt PUBLISH eingeben"
  if ($confirm -ne "PUBLISH") {
    Fail "Publish nicht bestaetigt. Keine externe Wirkung." 31
  }
} else {
  Info "Draft-Modus: Zenodo-Draft wird erzeugt, nicht veroeffentlicht."
}

$token = Read-TokenPlain
if ([string]::IsNullOrWhiteSpace($token)) {
  Fail "Leerer Zenodo token. Keine externe Wirkung." 32
}

$headersAuth = @{
  "Authorization" = "Bearer $token"
  "Accept" = "application/json"
}
$headersUpload = @{ "Authorization" = "Bearer $token" }

try {
  Info "Erzeuge Zenodo Draft-Deposition..."
  $dep = Invoke-ZenodoJson -Phase "CREATE_DEPOSITION_POST" -Method "Post" -Uri "$ApiBase/deposit/depositions" -Headers $headersAuth -Body "{}" -PermissionBlock $PermissionBlock -MediaTypeBlock $MediaTypeBlock -ApiBase $ApiBase -Publish ([bool]$Publish)

  $depositionId = "$($dep.id)"
  $bucket = "$($dep.links.bucket)"
  if ([string]::IsNullOrWhiteSpace($depositionId)) { Fail "Zenodo gab keine deposition id zurueck." 46 }
  if ([string]::IsNullOrWhiteSpace($bucket)) { Fail "Zenodo gab keine bucket URL zurueck." 47 }
  Pass "DEPOSITION_ID = $depositionId"

  $metadataObj = Get-Content -LiteralPath $Metadata -Encoding UTF8 -Raw | ConvertFrom-Json
  $metadataBody = @{ metadata = $metadataObj.metadata } | ConvertTo-Json -Depth 100
  $depUrl = "$ApiBase/deposit/depositions/$depositionId"

  Info "Schreibe Metadaten..."
  Invoke-ZenodoJson -Phase "UPDATE_METADATA_PUT" -Method "Put" -Uri $depUrl -Headers $headersAuth -Body $metadataBody -PermissionBlock $PermissionBlock -MediaTypeBlock $MediaTypeBlock -ApiBase $ApiBase -Publish ([bool]$Publish) | Out-Null
  Pass "Metadata updated"

  Info "Upload Payload..."
  try {
    $uploadUrl = "$bucket/$([uri]::EscapeDataString((Split-Path $Payload -Leaf)))"
    Invoke-RestMethod -Method Put -Uri $uploadUrl -Headers $headersUpload -InFile $Payload -ContentType "application/octet-stream" | Out-Null
  } catch {
    $status = Get-StatusCode $_.Exception
    $body = Get-ErrorResponseBody $_.Exception
    if ($status -eq 401 -or $status -eq 403) {
      Write-PermissionBlock -Path $PermissionBlock -Phase "UPLOAD_PAYLOAD_PUT" -StatusCode $status -ResponseBody $body -ApiBase $ApiBase -Publish ([bool]$Publish)
      Fail "Zenodo Permission/Auth Block beim Payload-Upload. zenodo_permission_block.json wurde geschrieben." 48
    }
    if ($status -eq 415) {
      Write-MediaTypeBlock -Path $MediaTypeBlock -Phase "UPLOAD_PAYLOAD_PUT" -StatusCode $status -ResponseBody $body -ApiBase $ApiBase -Publish ([bool]$Publish)
      Fail "Zenodo 415 beim Payload-Upload. zenodo_media_type_block.json wurde geschrieben." 49
    }
    throw
  }
  Pass "Payload uploaded"

  $sidecarHash = Get-Sha256 $PayloadSidecar
  Info "Upload Sidecar..."
  try {
    $uploadUrl2 = "$bucket/$([uri]::EscapeDataString((Split-Path $PayloadSidecar -Leaf)))"
    Invoke-RestMethod -Method Put -Uri $uploadUrl2 -Headers $headersUpload -InFile $PayloadSidecar -ContentType "text/plain" | Out-Null
  } catch {
    $status = Get-StatusCode $_.Exception
    $body = Get-ErrorResponseBody $_.Exception
    if ($status -eq 401 -or $status -eq 403) {
      Write-PermissionBlock -Path $PermissionBlock -Phase "UPLOAD_SIDECAR_PUT" -StatusCode $status -ResponseBody $body -ApiBase $ApiBase -Publish ([bool]$Publish)
      Fail "Zenodo Permission/Auth Block beim Sidecar-Upload. zenodo_permission_block.json wurde geschrieben." 50
    }
    if ($status -eq 415) {
      Write-MediaTypeBlock -Path $MediaTypeBlock -Phase "UPLOAD_SIDECAR_PUT" -StatusCode $status -ResponseBody $body -ApiBase $ApiBase -Publish ([bool]$Publish)
      Fail "Zenodo 415 beim Sidecar-Upload. zenodo_media_type_block.json wurde geschrieben." 51
    }
    throw
  }
  Pass "Sidecar uploaded"

  $dep = Invoke-RestMethod -Method Get -Uri $depUrl -Headers $headersAuth
  $recordUrl = "$($dep.links.html)"
  $doi = ""
  $state = "$($dep.state)"
  $published = $false

  if ($Publish) {
    Info "Publiziere Zenodo Record..."
    $pub = Invoke-ZenodoJson -Phase "PUBLISH_ACTION_POST" -Method "Post" -Uri "$depUrl/actions/publish" -Headers $headersAuth -Body "{}" -PermissionBlock $PermissionBlock -MediaTypeBlock $MediaTypeBlock -ApiBase $ApiBase -Publish ([bool]$Publish)
    $recordUrl = "$($pub.links.html)"
    $doi = "$($pub.doi)"
    $state = "$($pub.state)"
    $published = $true
    Pass "Published"
  } else {
    Pass "Draft created, not published"
  }

  $evidence = [ordered]@{
    REAL_ZENODO_DEPOSIT = $(if ($published) {"PASS_PUBLISHED"} else {"PASS_DRAFT_CREATED_NOT_PUBLISHED"})
    RECORD_URL = $recordUrl
    DOI = $doi
    DEPOSITION_ID = $depositionId
    ASSET_LIST = @(
      [ordered]@{ name = (Split-Path $Payload -Leaf); size = (Get-Item -LiteralPath $Payload).Length; sha256 = $payloadHash },
      [ordered]@{ name = (Split-Path $PayloadSidecar -Leaf); size = (Get-Item -LiteralPath $PayloadSidecar).Length; sha256 = $sidecarHash }
    )
    ASSET_SIZES = [ordered]@{
      (Split-Path $Payload -Leaf) = (Get-Item -LiteralPath $Payload).Length
      (Split-Path $PayloadSidecar -Leaf) = (Get-Item -LiteralPath $PayloadSidecar).Length
    }
    ASSET_HASHES = [ordered]@{
      (Split-Path $Payload -Leaf) = $payloadHash
      (Split-Path $PayloadSidecar -Leaf) = $sidecarHash
    }
    STATE = $state
    PUBLISHED = $published
    API_BASE = $ApiBase
    GENERATED_AT_LOCAL = (Get-Date).ToString("o")
    ACTIVATION_STANDARD = "V8.33_REPOSITORY_AND_ANTICIPATORY_EXPLICIT_JSON_CONTENTTYPE_FIX"
  }

  Write-JsonFile -Path $ZenodoEvidence -Obj $evidence
  Pass "ZENODO_EVIDENCE_WRITTEN = zenodo_release_record.json"
  Write-Host "RECORD_URL=$recordUrl"
  Write-Host "DOI=$doi"
  Write-Host "DEPOSITION_ID=$depositionId"
  Write-Host "PUBLISHED=$published"
  exit 0
}
catch {
  if (!(Test-Path -LiteralPath $PermissionBlock) -and !(Test-Path -LiteralPath $MediaTypeBlock)) {
    $status = Get-StatusCode $_.Exception
    $body = Get-ErrorResponseBody $_.Exception
    $err = [ordered]@{
      RECORD_TYPE = "QIKVRT_ZENODO_ERROR_BLOCK"
      RESULT = "BLOCK"
      ERROR_CLASS = "ZENODO_UNCLASSIFIED_API_OR_SCRIPT_ERROR"
      HTTP_STATUS = $status
      RESPONSE_BODY = $body
      ERROR_MESSAGE = "$($_.Exception.Message)"
      API_BASE = $ApiBase
      EXTERNAL_EFFECT = "UNKNOWN_OR_NOT_COMPLETED"
      DOI = $null
      RECORD_URL = $null
      GENERATED_AT_LOCAL = (Get-Date).ToString("o")
    }
    Write-JsonFile -Path $ErrorBlock -Obj $err
    Fail "Zenodo/API Fehler. zenodo_error_block.json wurde geschrieben." 60
  }
  exit 61
}
finally {
  Remove-Variable token -ErrorAction SilentlyContinue
}
