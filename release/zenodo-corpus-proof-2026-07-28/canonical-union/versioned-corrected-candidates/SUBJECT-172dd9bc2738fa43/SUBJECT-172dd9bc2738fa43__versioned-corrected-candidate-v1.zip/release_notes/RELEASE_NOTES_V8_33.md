# Release Notes V8.33

V8.33 continues V8.32 and persists the Zenodo 415 Content-Type fix in repository and anticipatory layers.

## Fixed

```text
ZENODO_JSON_CONTENT_TYPE_MISSING_OR_INVALID
```

## Outputs

```text
zenodo_release_record.json
zenodo_permission_block.json
zenodo_media_type_block.json
zenodo_error_block.json
```
