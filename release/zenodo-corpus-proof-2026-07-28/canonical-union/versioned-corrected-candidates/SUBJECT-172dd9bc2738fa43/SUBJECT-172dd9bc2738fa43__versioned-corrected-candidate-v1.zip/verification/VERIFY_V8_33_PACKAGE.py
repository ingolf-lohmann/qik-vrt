#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, sys

root = Path(__file__).resolve().parents[1]
required = [
    "START_HERE_QIKVRT_V8_33_CREATE_ZENODO_DRAFT.bat",
    "PUBLISH_QIKVRT_V8_33_ZENODO_RECORD.bat",
    "scripts/QIKVRT_ZENODO_DRAFT_V8_33.ps1",
    "repository/REPOSITORY_STATE_V8_33.json",
    "anticipatory/ANTICIPATORY_GATE_V8_33.json",
    "metadata/zenodo_metadata_v8_33.json",
    "policy/QIKVRT_V8_33_REPOSITORY_AND_ANTICIPATORY_POLICY.json",
    "audit/V8_33_AUDIT_REPORT.json",
    "README_V8_33_START_HERE.md",
    "MANIFEST_V8_33.json",
    "SHA256SUMS.txt"
]
missing = [p for p in required if not (root/p).exists()]
if missing:
    print("FAIL missing", missing)
    sys.exit(1)

script = (root/"scripts/QIKVRT_ZENODO_DRAFT_V8_33.ps1").read_text(encoding="utf-8")
needed = [
    '-ContentType "application/json"',
    "zenodo_media_type_block.json",
    "ZENODO_JSON_CONTENT_TYPE_MISSING_OR_INVALID",
    "CREATE_DEPOSITION_POST",
    "UPDATE_METADATA_PUT",
    "PUBLISH_ACTION_POST",
    "application/octet-stream",
    "text/plain"
]
missing_fragments = [x for x in needed if x not in script]
if missing_fragments:
    print("FAIL script missing fragments", missing_fragments)
    sys.exit(2)

def sha256(p):
    h = hashlib.sha256()
    with open(p,"rb") as f:
        for chunk in iter(lambda:f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

bad=[]; miss=[]
for line in (root/"SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
    if not line.strip(): continue
    parts=line.split(maxsplit=1)
    if len(parts)!=2:
        bad.append("malformed:"+line); continue
    expected, rel = parts[0], parts[1].strip()
    p=root/rel
    if not p.exists(): miss.append(rel)
    elif sha256(p)!=expected: bad.append(rel)
if bad or miss:
    print("FAIL sha bad=", bad, "missing=", miss)
    sys.exit(3)

audit=json.loads((root/"audit/V8_33_AUDIT_REPORT.json").read_text(encoding="utf-8"))
if audit.get("overall_result")!="PASS":
    print("FAIL audit not PASS")
    sys.exit(4)
print("PASS V8.33 repository and anticipatory Zenodo 415 content-type fix")
