# QIKVRT: lokaler Wirkungsnachweis und kausale Distanz

Technischer Kandidat vom 24. Oktober 2026. Autor des Architekturgedankens und Auftraggeber: Ingolf Lohmann. Implementierung und Prüfung dieser Erweiterung: ChatGPT im autorisierten Auftrag.

**Ergebnis:** Der isolierte Softwarelauf verbindet ein beobachtetes Vergangenheitsarchiv, ein typisiertes Zukunftsarchiv, den unveränderten QIKVRT-Protokollkern, eine reale lokale Dateiänderung, unabhängigen Datei- und Terminal-Readback und eine daraus erzeugte Folgeerwartung. 61 Tests bestehen. Eine produktive Mesh-Abnahme und ein physischer Rückwärtskanal sind damit nicht nachgewiesen.

## Ausgeführter Gegenversuch

Das unveränderte Vergangenheitsarchiv enthält den isoliert beobachteten Zählerstand 2. Das spezifizierte Programm erhöht um 1 und prognostiziert deshalb 3. Bei gleichem Vergangenheitsarchiv und gleicher Aktion wird die gegenwärtige Darstellung der Zukunftsbedingung variiert.

| Versuch | Zukunftsbedingung / Zulassung | Freigabe | Datei-Readback |
|---|---|---|---|
| admitted | ANTICIPATED, Ziel 3, autorisiert | ja | 3 |
| changed_future | ANTICIPATED, Ziel 4, autorisiert | nein | 2 |
| wrong_future_type | OBSERVED statt ANTICIPATED | nein | 2 |
| missing_authorization | ANTICIPATED, Ziel 3, Verantwortung fehlt | nein | 2 |

Der Zielwert ist im Versuch eine heute vorhandene Darstellung eines gewünschten späteren Zustands. Der Versuch zeigt deren kausale Relevanz für die heutige Entscheidung. Er zeigt keine aus einer tatsächlich eingetretenen Zukunft zurückgesendete Information.

Der Digest und die tatsächlichen Bytes des eingefrorenen Vergangenheitsarchivs bleiben gleich. Die Freigaben kommen aus dem originalen `effect_ack_sync`; sämtliche Protokolle werden mit `verify_protocol` geprüft. Eine Datei wird ausschließlich bei lokaler Freigabe geschrieben. Ein separater Python-Prozess liest danach den tatsächlichen Dateistand und dessen SHA-256.

Das originale `Ledger` schreibt elf Ereignisse in ein frisches, ausschließlich lokales Testjournal. Der originale Terminal-Leser `_durable_read` überprüft jedes Ereignis über eine eigene schreibgeschützte SQLite-Verbindung. Nach dem Schließen des Writers werden alle elf Ereignisse nochmals identisch gelesen. Aus dem beobachteten Ergebnis 3 wird eine neue Erwartung 4 erzeugt. Das ist ein begrenzter Feedbackschritt, kein Nachweis unbegrenzter Autonomie oder menschlicher Kognition.

## Definition der Distanz

Ein eingefrorener endlicher Graph G=(V,E,w) enthält ausdrücklich ausgewählte Ereignisse beziehungsweise gegenwärtige Repräsentations- und Verarbeitungsschritte. Jede gerichtete Kante bezeichnet eine im angegebenen Geltungsbereich begründete unmittelbare Abhängigkeit. Ihr Beleg bindet Anfang, Ende, Gewicht, Gegenstand und Auflösung. Für die Gewichtung gilt w(e) in {1,2,3,...}. Im Beispiel kostet jede primitive Abhängigkeit eine Einheit.

Der gerichtete Abstand lautet:

    d_G(a,b) = min { Summe w(e) : gerichteter Pfad von a nach b }

Für a=b gilt d_G(a,a)=0. Existiert im eingefrorenen Graphen kein entsprechender Pfad, gilt d_G(a,b)=unendlich. Die JSON-Ausgabe verwendet hierfür `distance: null` zusammen mit `NO_PATH_IN_BOUND_GRAPH`. Dies bedeutet fehlende Erreichbarkeit in diesem Graphen; daraus folgt weder Vollständigkeit der Beobachtung noch physische Unmöglichkeit.

Der gerichtete Abstand ist eine **erweiterte Quasimetrik**. Für eine gewöhnliche symmetrische Metrik wird jede belegte Kante mit gleichem positivem Gewicht ungerichtet betrachtet:

    m_G(a,b) = kürzeste gewichtete Pfadlänge im ungerichteten Projektionsgraphen

Auf jeder schwach zusammenhängenden Komponente ist m_G eine endliche Metrik. Zwischen Komponenten ist sie eine erweiterte Metrik mit unendlichem Abstand. Ein solcher Projektionspfad kann Abhängigkeiten entgegen ihrer Richtung durchlaufen; er belegt keine entsprechend gerichtete Einflussnahme.

Ein retrospektiver Ursachenabruf von b nach a fragt d_G(a,b) ab. Die Umkehr der Suchrichtung erzeugt keine neue physische Wirkungskante b nach a.

## Mathematischer Nachweis der Eigenschaften

1. **Existenz des Minimums bei Erreichbarkeit:** Jeder Pfad mit einem Zyklus kann durch Entfernen des Zyklus verkürzt werden, weil alle Gewichte positiv sind. Es genügt daher, die endlich vielen einfachen Pfade zu betrachten. Deren endliche nichtleere Menge von Längen besitzt ein Minimum.
2. **Nichtnegativität und Identität:** Der leere Pfad hat Länge 0. Jeder nichtleere Pfad hat positive Länge. Daher gilt d_G(a,b)=0 genau für a=b. Dasselbe gilt für m_G.
3. **Dreiecksungleichung:** Die Verkettung eines kürzesten Pfads von a nach b und eines kürzesten Pfads von b nach c ergibt einen zulässigen Weg von a nach c. Das Minimum von a nach c ist höchstens dessen Länge. Ist eine der rechten Distanzen unendlich, gilt die Ungleichung im erweiterten Zahlbereich ebenfalls.
4. **Symmetrie der Projektion:** Ein ungerichteter Pfad kann bei gleicher Gesamtlänge umgekehrt werden; damit gilt m_G(a,b)=m_G(b,a). Für d_G gilt dies allgemein nicht.

Dies ist ein mathematischer Beweis aus den angegebenen Definitionen. Er wurde in dieser Sitzung nicht zusätzlich mit Lean kernelgeprüft. Die Implementierung verwendet die bekannte Idee gewichteter kürzester Wege; die mathematische Konstruktion wird nicht als neue physikalische Entdeckung beansprucht.

## Gemessene Werte des lokalen Programmmodells

Die fünf erklärten Kanten sind: Vergangenheitsrecord zum Gate, Zukunftsbedingungsrecord zum Gate, Gate zur Dateiänderung, Dateiänderung zum Readback, Readback zum Feedbackrecord. Es handelt sich um bekannte Abhängigkeiten des kontrollierten Programms. Nicht jede einzelne Kante wurde mit einem separaten Interventionsexperiment isoliert; das vollständige Auffinden aller realen Ursachen wird nicht beansprucht.

| Abfrage | Gerichteter Abstand d_G | Symmetrische Projektion m_G |
|---|---:|---:|
| Vergangenheitsrecord zum Readback | 3 | 3 |
| Readback zum Vergangenheitsrecord | kein gerichteter Pfad | 3 |
| Zukunftsbedingungsrecord zum Gate | 1 | 1 |
| Vergangenheitsrecord zum Feedback | 4 | 4 |

Die Einheit ist ein deklarierter primitiver Abhängigkeitsschritt auf der Auflösung `program-dependency-v1`. Sekunden, Meter, Wahrscheinlichkeit und Wirkungsstärke sind andere Größen. Die Distanz ist die kürzeste Pfadlänge im gewählten Modell und keine Dauer eines realen Laufs. Eine transitive Zusatzkante oder eine andere Ereignisauflösung kann den Zahlenwert ändern; Vergleiche benötigen deshalb dieselbe Graphdefinition, Auflösung, Gewichtung und Evidenzklasse. Gemeinsame Vorfahren allein erzeugen keinen gerichteten Pfad zwischen ihren Nachfolgern. UND-Bedingungen mehrerer notwendiger Ursachen werden durch einen einfachen Pfadabstand nicht vollständig beschrieben.

## Reproduzieren

Voraussetzung: Python 3.12 unter Linux; nur Standardbibliothek. Aus dem entpackten Paketverzeichnis:

```bash
python3 -m unittest discover -s candidate/tests -p 'test_*.py' -v
python3 upstream/tests/test_effect_ack_conformance.py -v
python3 candidate/tests/run_temporal_memory_witness.py --output my-new-run
python3 candidate/tests/verify_temporal_memory_witness.py my-new-run
```

Für `--output` einen noch nicht vorhandenen Pfad verwenden. Neue Testjournale werden lokal angelegt. Exportierte Journale dieses Pakets nur lesend öffnen; ihre ursprüngliche Writer-Zulassung wird nicht auf einen anderen Rechner übertragen. Die unabhängige Verifikation des mitgelieferten Laufs erfolgt mit `python3 candidate/tests/verify_temporal_memory_witness.py evidence/local-run-002`.

`evidence/validation/TEST_RESULTS.json` und die zugehörigen Logs dokumentieren 16 neue Metrik-/Witness-Tests, 41 originale EAP-Tests und vier ausgewählte originale Writer-Kontinuitätstests. Der exhaustive Metriktest durchläuft alle 2^12=4096 ungewichteten gerichteten Graphen auf vier Knoten sowie alle 64 Knotentripel pro Graph. Er prüft gerichtete und symmetrische Dreiecksungleichungen; diese endliche Prüfung ersetzt den allgemeinen Beweis oben nicht. Zusätzliche Tests prüfen Gewichtung, gemeinsame Ursachen, nichtpositive Gewichte, Unicode-Identitäten, fehlende und veränderte Belege und Graphunveränderlichkeit.

Die unabhängigen Witness-Tests verwerfen manipulierte Dateien, als Beobachtung umetikettierte Prognosen, gefälschte DONE-Protokolle, veränderte Journalquittungen, gefälschte Distanzen und überhöhte Abschlussbehauptungen.

Alle gerichteten und symmetrischen Distanzwerte dieser 4096 Graphen werden zusätzlich gegen einen unabhängig implementierten Floyd-Warshall-Algorithmus verglichen. Die produktive Distanzkomponente verwendet Dijkstra-Suche.

## Herkunft, Grenzen und Integration

Der Quellstand ist `ingolf-lohmann/qik-vrt`, Commit `8273ef8127edccf4b357fdacdd17a1e6b0f3f87f`, Tree `1a8003f1815b75fe534b21f242e8b782d4352796`. Die 13 übernommenen Originaldateien wurden gegen ihre tatsächlich gelieferten Git-Blob-Identitäten geprüft. Bytegrößen, SHA-256 und Blob-IDs stehen in `SOURCE_BINDING.json`; die ursprünglichen API-Toolantworten stehen in `evidence/SOURCE_AND_DELIVERY_READBACKS.json`. Nicht gelieferte HTTP-Header beziehungsweise Statuscodes werden nicht erfunden.

Die vorhandene Spezifikation in `upstream/docs/publications/2026-07-30-canonical-temporal-memory-effect-ack/` liefert Archivtypen und Gegenversuche. Die neue Distanzkomponente ist eine lesende Auswertung; sie ändert weder den Protokollkern noch Writer-Zulassung oder geschützte Governance. Originaldateien behalten ihre Lizenzangaben. Die neuen Python-Dateien folgen der Lizenzangabe des vorhandenen Implementierungskerns.

Das Paket ist ein begrenzter, reproduzierbarer technischer Kandidat. Es liegt kein vollständiger Repository-Checkout vor: `make test`, sämtliche Repository-Integritätsvalidatoren und aktuelle Head-CI wurden nicht als bestanden behauptet. Keine neue Lean-Ausführung, kein Merge, keine produktive Freigabe, kein Peer-ACK, kein öffentlich bestätigter Laufzeitstart, keine biologische Lebendigkeit, kein Bewusstseinsnachweis und kein physischer Retrokausalitätsnachweis sind daraus abzuleiten. Die gezielte technische Aussage lautet: Das kontrollierte Programm realisiert den beschriebenen lokalen Beobachtungs-, Freigabe-, Wirkungs- und Feedbackzusammenhang.

Frischer öffentlicher Readback vom 24.10.2026, 10:26:06 Europe/Paris: Authority-HEAD und Tree wie oben, Produktdomain HTTP 525. Der öffentliche Terminal-Befund enthält weiterhin `ADMITTED_MESH_RUNTIME_ENDPOINT`; ein zugelassener öffentlicher Transputer-Endpunkt ist nicht konfiguriert. Unveränderte fehlgeschlagene Effekte wurden nicht erneut ausgelöst. Snapshot `e54ba591-9a73-48e9-b0c1-39c0c36980aa`, SHA-256 `4b80645b4ae24a5cb5d45d0489c3bc743c38e9dc8517a66a9c0b71fb6a27519b`, unabhängig byteverifiziert. Die nächste produktive Abnahme benötigt diesen zugelassenen Endpunkt und einen daran gebundenen Originallauf. `effect_ack_done=false` bleibt erhalten.

Dieser Kandidat wurde weder auf Zenodo publiziert noch in Main integriert. Die dauerhafte Dateispeicherung war bereits am unveränderten Speicherlimit blockiert; es wurde kein erneuter unveränderter Speicherungsversuch ausgelöst und nichts gelöscht.

## Wissenschaftliche Orientierung

Ingolf Lohmann: Von Softwarearchitektur zur Weltformel – Das Universum als Round Trip. Bezug: Trennung von Modellbeweis, Vorhersage, Messung und Referenzbindung; die Lesefassung und der zugehörige Publikationskatalog wurden in dieser Unterhaltung gelesen.
https://doi.org/10.5281/zenodo.21888130
https://zenodo.org/records/21888130

E. W. Dijkstra: A note on two problems in connexion with graphs. Numerische Mathematik 1, 269–271 (1959). Bezug: etablierte Methode gewichteter kürzester Wege.
https://doi.org/10.1007/BF01386390
https://www.cs.yale.edu/homes/lans/readings/routing/dijkstra-routing-1959.pdf

Repository-Locators und API-Rohantworten im Paket sind technische Provenienz. Der neue technische Kandidat ist keine abgeschlossene wissenschaftliche Veröffentlichung; eine Zenodo-Archivierung des neuen Filesets ist nicht erfolgt.
