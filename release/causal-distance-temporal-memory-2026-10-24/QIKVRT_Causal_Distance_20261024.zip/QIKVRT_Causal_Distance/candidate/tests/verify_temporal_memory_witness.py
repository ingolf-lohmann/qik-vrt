#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
"""Read-only verification of the local witness and exact upstream source bytes."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / 'candidate/src'), str(ROOT / 'upstream/src')]
from qikvrt_effect_ack import canonical_json, sha256_identifier, ResponsibilityProtocol
from qikvrt_effect_ack_http_terminal import _durable_read
from qikvrt_causal_distance import DependencyGraph, Edge


def require(ok, reason):
    if not ok: raise ValueError(reason)


def verify(output):
    report = json.loads((output / 'witness.json').read_bytes())
    subject = report['subject']
    require(subject['scope'] == 'ISOLATED_LOCAL_CONFORMANCE_ONLY', 'SCOPE')
    require(subject['harness_ref'] == sha256_identifier((ROOT / 'candidate/tests/run_temporal_memory_witness.py').read_bytes()), 'HARNESS_BINDING')
    require(subject['metric_source_ref'] == sha256_identifier((ROOT / 'candidate/src/qikvrt_causal_distance.py').read_bytes()), 'METRIC_BINDING')
    for item in report['source_binding']['files']:
        raw = (ROOT / 'upstream' / item['path']).read_bytes()
        actual = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        require(actual == item['git_blob'], 'UPSTREAM_GIT_BLOB_MISMATCH')
        require(hashlib.sha256(raw).hexdigest() == item['sha256'], 'UPSTREAM_SHA256_MISMATCH')
    past_raw = (output / 'observed_before.json').read_bytes()
    past = json.loads(past_raw)
    require(past['status'] == 'OBSERVED' and past['state']['counter'] == 2, 'PAST')
    require(sha256_identifier(past_raw) == report['past_ref'], 'PAST_HASH')
    require([x['name'] for x in report['cases']] ==
            ['admitted','changed_future','wrong_future_type','missing_authorization'], 'CASES')
    for case in report['cases']:
        folder = output / case['name']
        future_raw = (folder / 'anticipated.json').read_bytes()
        future = json.loads(future_raw)
        protocol = ResponsibilityProtocol.from_dict(json.loads((folder / 'protocol.json').read_bytes()))
        payload_raw = (folder / 'request_payload.json').read_bytes()
        payload = json.loads(payload_raw)
        require(protocol.input_hash == sha256_identifier(payload_raw), 'INPUT_HASH')
        require(payload['past_ref'] == report['past_ref'] and payload['future_ref'] == sha256_identifier(future_raw), 'ARCHIVE_BINDING')
        require(sha256_identifier(future_raw) == case['future_ref'], 'FUTURE_HASH')
        derived = (future['status'] == 'ANTICIPATED' and future['target_counter'] == 3
                   and case['name'] != 'missing_authorization')
        require(protocol.ordinary_release == derived == case['local_release'], 'GATE')
        state_raw = (folder / 'counter.json').read_bytes()
        require(json.loads(state_raw)['counter'] == (3 if derived else 2), 'ACTUAL_FILE_EFFECT')
        require(hashlib.sha256(state_raw).hexdigest() == case['effect_observed']['sha256'], 'FILE_READBACK_HASH')
        require(case['effect_observed']['value'] == (3 if derived else 2), 'FILE_READBACK_VALUE')
    events = json.loads((output / 'native_events.json').read_bytes())
    receipts = json.loads((output / 'terminal_readbacks.json').read_bytes())
    require(len(events) == len(receipts) == report['native_event_count'], 'EVENT_COUNT')
    for event, receipt in zip(events, receipts):
        require(event['subject'] == subject, 'NATIVE_SUBJECT')
        epoch, actual = _durable_read(str(output / 'state'), event)
        require(epoch == report['epoch'] and actual == receipt, 'NATIVE_TERMINAL_READBACK')
    require(events[-1]['kind'] == 'SUCCESSOR', 'SUCCESSOR')
    successor = events[-1]['payload']
    require(successor['observed_successor']['state']['counter'] == 3 and
            successor['next_anticipated']['target_counter'] == 4, 'FEEDBACK')
    g = report['graph']
    evidence = {k:v.encode() for k,v in g['evidence'].items()}
    graph = DependencyGraph(g['vertices'], [Edge(**e) for e in g['edges']], evidence,
        subject_ref=g['subject_ref'], resolution='program-dependency-v1', scope='CONTROLLED_LOCAL_PROGRAM_ONLY')
    require(evidence[g['subject_ref']] == canonical_json(subject).encode(), 'GRAPH_SUBJECT')
    for query in report['distance_queries']:
        require(graph.query(query['source'], query['target'],
                structural=query['measure'] == 'SYMMETRIC_STRUCTURAL_METRIC') == query, 'DISTANCE_QUERY')
    require(report['effect_ack_done'] is False and report['limits']['physical_retrocausality_proved'] is False, 'CLAIM_BOUNDARY')
    return {'read_only_verification_passed': True, 'upstream_blobs': len(report['source_binding']['files']),
            'verified_native_readbacks': len(receipts), 'cases': len(report['cases']), 'effect_ack_done': False}


if __name__ == '__main__':
    p=argparse.ArgumentParser();p.add_argument('output',type=Path)
    print(json.dumps(verify(p.parse_args().output.resolve())))
