# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
import itertools
import json
import math
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / 'candidate/src'), str(ROOT / 'upstream/src')]
from qikvrt_causal_distance import DependencyGraph, Edge
from qikvrt_effect_ack import canonical_json, sha256_identifier


def graph(vertices, pairs):
    evidence = {}
    subject = b'LOCAL_CONFORMANCE_GRAPH_ONLY'
    subject_ref = sha256_identifier(subject)
    evidence[subject_ref] = subject
    edges = []
    for a, b, w in pairs:
        receipt = canonical_json({'source': a, 'target': b, 'weight': w,
            'subject_ref': subject_ref, 'resolution': 'fixed-primitive-dependency-v1',
            'scope': 'LOCAL_MODEL_ONLY'}).encode()
        ref = sha256_identifier(receipt)
        evidence[ref] = receipt
        edges.append(Edge(a, b, w, ref))
    return DependencyGraph(vertices, edges, evidence, subject_ref=subject_ref,
        resolution='fixed-primitive-dependency-v1', scope='LOCAL_MODEL_ONLY'), evidence, edges


class DistanceTests(unittest.TestCase):
    def test_directed_and_structural_are_different(self):
        g, _, _ = graph('ABCX', [('A', 'B', 1), ('B', 'C', 1)])
        self.assertEqual(g.directed('A', 'C'), 2)
        self.assertEqual(g.directed('C', 'A'), math.inf)
        self.assertEqual(g.metric('C', 'A'), 2)
        self.assertEqual(g.query('A', 'X')['status'], 'NO_PATH_IN_BOUND_GRAPH')
        self.assertFalse(g.query('A', 'X')['physical_impossibility_inferred'])

    def test_common_cause_does_not_imply_directed_path(self):
        g, _, _ = graph('ABC', [('A', 'B', 1), ('A', 'C', 1)])
        self.assertEqual(g.directed('B', 'C'), math.inf)
        self.assertEqual(g.metric('B', 'C'), 2)

    def test_weights_use_shortest_total_cost(self):
        g, _, _ = graph('ABC', [('A', 'C', 9), ('A', 'B', 2), ('B', 'C', 3)])
        self.assertEqual(g.directed('A', 'C'), 5)
        self.assertEqual(g.query('A', 'C')['path'], ['A', 'B', 'C'])

    def test_nonpositive_fractional_and_boolean_weights_rejected(self):
        g, evidence, edges = graph('AB', [('A', 'B', 1)])
        for w in (0, -1, 0.5, True):
            with self.subTest(w=w), self.assertRaises(ValueError):
                DependencyGraph('AB', [Edge('A', 'B', w, edges[0].evidence_ref)], evidence,
                    subject_ref=g.subject_ref, resolution=g.resolution, scope=g.scope)

    def test_missing_tampered_and_misbound_evidence_rejected(self):
        g, evidence, edges = graph('AB', [('A', 'B', 1)])
        kwargs = dict(subject_ref=g.subject_ref, resolution=g.resolution, scope=g.scope)
        for changed in ({g.subject_ref: evidence[g.subject_ref]},
                        dict(evidence, **{edges[0].evidence_ref: b'tampered'})):
            with self.assertRaises(ValueError):
                DependencyGraph('AB', edges, changed, **kwargs)
        receipt = json.loads(evidence[edges[0].evidence_ref]); receipt['target'] = 'A'
        raw = canonical_json(receipt).encode(); ref = sha256_identifier(raw)
        with self.assertRaisesRegex(ValueError, 'BINDING'):
            DependencyGraph('AB', [Edge('A', 'B', 1, ref)], dict(evidence, **{ref: raw}), **kwargs)

    def test_duplicate_unknown_and_self_vertices_rejected(self):
        for vertices, pairs in [('AAB', []), ('AB', [('A','X',1)]), ('AB', [('A','A',1)]),
                                ('AB', [('A','B',1), ('A','B',1)])]:
            with self.assertRaises(ValueError): graph(vertices, pairs)
        g, _, _ = graph('AB', [])
        with self.assertRaises(ValueError): g.directed('A', 'X')

    def test_snapshot_not_changed_by_input_mutation(self):
        g, evidence, edges = graph('AB', [('A', 'B', 1)])
        before = g.graph_ref
        edges.clear(); evidence.clear()
        self.assertEqual(g.directed('A', 'B'), 1)
        self.assertEqual(g.graph_ref, before)
        with self.assertRaises(AttributeError): g.scope = 'different'

    def test_unicode_alias_and_boolean_receipt_rejected(self):
        with self.assertRaises(ValueError): graph(['e\u0301', '\u00e9'], [])
        g, evidence, edges = graph('AB', [('A', 'B', 1)])
        receipt = json.loads(evidence[edges[0].evidence_ref]); receipt['weight'] = True
        raw = canonical_json(receipt).encode(); ref = sha256_identifier(raw)
        with self.assertRaises(ValueError):
            DependencyGraph('AB', [Edge('A', 'B', 1, ref)], dict(evidence, **{ref: raw}),
                subject_ref=g.subject_ref, resolution=g.resolution, scope=g.scope)

    def test_all_4096_four_vertex_directed_graphs(self):
        vertices = tuple('ABCD')
        possible = tuple((a,b) for a in vertices for b in vertices if a != b)
        triples = tuple(itertools.product(vertices, repeat=3))
        self.graph_count = 0
        for mask in range(1 << len(possible)):
            selected = [(a,b,1) for i,(a,b) in enumerate(possible) if mask >> i & 1]
            g, _, _ = graph(vertices, selected)
            directed = {(a,b): g.directed(a,b) for a,b in itertools.product(vertices, repeat=2)}
            metric = {(a,b): g.metric(a,b) for a,b in itertools.product(vertices, repeat=2)}
            # Independent all-pairs Floyd-Warshall oracle; implementation uses Dijkstra.
            oracle_d = {(a,b): (0 if a == b else math.inf) for a,b in itertools.product(vertices, repeat=2)}
            oracle_m = dict(oracle_d)
            for a,b,w in selected:
                oracle_d[a,b] = w
                oracle_m[a,b] = oracle_m[b,a] = w
            for middle in vertices:
                for a,b in itertools.product(vertices, repeat=2):
                    oracle_d[a,b] = min(oracle_d[a,b], oracle_d[a,middle] + oracle_d[middle,b])
                    oracle_m[a,b] = min(oracle_m[a,b], oracle_m[a,middle] + oracle_m[middle,b])
            self.assertEqual(directed, oracle_d)
            self.assertEqual(metric, oracle_m)
            for a,b in itertools.product(vertices, repeat=2):
                self.assertEqual(metric[a,b], metric[b,a])
                self.assertEqual(metric[a,b] == 0, a == b)
                self.assertEqual(directed[a,b] == 0, a == b)
            for a,b,c in triples:
                self.assertLessEqual(metric[a,c], metric[a,b] + metric[b,c])
                self.assertLessEqual(directed[a,c], directed[a,b] + directed[b,c])
            self.graph_count += 1
        self.assertEqual(self.graph_count, 4096)


if __name__ == '__main__': unittest.main()
