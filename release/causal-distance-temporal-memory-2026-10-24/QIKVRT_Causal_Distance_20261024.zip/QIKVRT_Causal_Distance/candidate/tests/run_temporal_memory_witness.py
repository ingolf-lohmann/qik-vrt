#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
"""Isolated conformance witness using original EAP, Ledger and Terminal reader.

No public-runtime start, peer message, repository mutation, or production
assessment. A fresh local test ledger never inherits an exported writer.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import uuid

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / 'candidate/src'), str(ROOT / 'upstream/src')]
from qikvrt_effect_ack import (EffectAckRequest, ConnectionDecision, RiskLevel,
    canonical_json, sha256_identifier, effect_ack_sync, ordinary_release, verify_protocol)
from qikvrt_temdd_event_ledger import Ledger, SCHEMA, utc
from qikvrt_effect_ack_http_terminal import _durable_read
from qikvrt_causal_distance import DependencyGraph, Edge


def encode(value):
    return canonical_json(value).encode()


def run(output):
    if sys.flags.optimize:
        raise RuntimeError('ASSERTION_CHECKS_MUST_BE_ENABLED')
    output.mkdir(parents=True, exist_ok=False)
    source = json.loads((ROOT / 'SOURCE_BINDING.json').read_text())
    subject = {'scope': 'ISOLATED_LOCAL_CONFORMANCE_ONLY', 'run_id': uuid.uuid4().hex,
               'source_repository': source['repository'], 'source_commit': source['commit'],
               'source_tree': source['tree'],
               'harness_ref': sha256_identifier(Path(__file__).read_bytes()),
               'metric_source_ref': sha256_identifier((ROOT / 'candidate/src/qikvrt_causal_distance.py').read_bytes())}
    frozen_past = encode({'status': 'OBSERVED', 'state': {'counter': 2},
        'provenance': 'isolated-file-counter-v1', 'uncertainty': 'EXACT_INTEGER_READBACK'})
    past_hash = sha256_identifier(frozen_past)
    (output / 'observed_before.json').write_bytes(frozen_past)
    ledger = Ledger(output / 'state', subject)
    original_events, receipts = [], []

    def record(kind, name, payload):
        event = {'schema': SCHEMA, 'kind': kind, 'subject': subject,
                 'provenance': {'source': 'transputer', 'native_event_id': name},
                 'observed_at': utc(), 'message': 'Isolated temporal-memory conformance witness',
                 'payload': payload}
        receipt = ledger.append(event)
        epoch, observed = _durable_read(str(output / 'state'), event)
        assert epoch == ledger.epoch and observed == receipt
        original_events.append(event); receipts.append(receipt)
        return receipt

    record('OBSERVE', 'past', {'archive_ref': past_hash, 'archive': json.loads(frozen_past)})
    cases = []
    for name, target, future_type, admitted in [
        ('admitted', 3, 'ANTICIPATED', True),
        ('changed_future', 4, 'ANTICIPATED', False),
        ('wrong_future_type', 3, 'OBSERVED', False),
        ('missing_authorization', 3, 'ANTICIPATED', False)]:
        folder = output / name; folder.mkdir()
        state = folder / 'counter.json'; state.write_bytes(encode({'counter': 2}))
        future = encode({'status': future_type, 'target_counter': target,
            'model': 'counter-plus-one-v1', 'uncertainty': 'EXACT_WITHIN_PROGRAM_MODEL'})
        future_ref = sha256_identifier(future)
        folder.joinpath('anticipated.json').write_bytes(future)
        forecast = json.loads(frozen_past)['state']['counter'] + 1
        valid_future = future_type == 'ANTICIPATED' and forecast == target
        authorized = name != 'missing_authorization'
        refs = (past_hash, future_ref)
        request = EffectAckRequest(protocol_root_id='isolated-temporal-memory-witness',
            input_id=name, payload=encode({'past_ref': past_hash, 'future_ref': future_ref,
                                          'action': 'counter-plus-one'}),
            transport_ack=True, origin_checked=True, context_checked=True,
            semantics_reconstructed=True, effect_anticipated=valid_future,
            risk_classified=True, risk_level=RiskLevel.LOW,
            responsibility_assigned=authorized,
            responsibility_owner='ISOLATED_TEST_HARNESS' if authorized else '',
            connection_decision=ConnectionDecision.RELEASE,
            policy_allows_release=valid_future and authorized,
            evidence_refs=refs, required_evidence_refs=refs)
        result = effect_ack_sync(request, timeout_ms=1000)
        folder.joinpath('request_payload.json').write_bytes(request.payload)
        verify_protocol(result.protocol)
        release = ordinary_release(result)
        assert release == admitted
        before = state.read_bytes()
        if release:
            state.write_bytes(encode({'counter': forecast}))
        # A separate Python interpreter reads actual filesystem state; no supplied output value.
        observed = json.loads(subprocess.check_output([sys.executable, '-c',
            'import json,hashlib,sys; b=open(sys.argv[1],"rb").read(); '
            'print(json.dumps({"value":json.loads(b)["counter"],'
            '"sha256":hashlib.sha256(b).hexdigest()}))', str(state)], text=True))
        assert observed['value'] == (3 if release else 2)
        assert sha256_identifier(frozen_past) == past_hash
        assert (output / 'observed_before.json').read_bytes() == frozen_past
        protocol = result.protocol.to_dict()
        folder.joinpath('protocol.json').write_bytes(encode(protocol))
        case = {'name': name, 'future_ref': future_ref, 'forecast': forecast,
                'protocol_state': result.state.value, 'local_release': release,
                'effect_observed': observed, 'changed_file': before != state.read_bytes(),
                'past_unchanged': True, 'production_effect_ack_done': False}
        cases.append(case)
        record('CLASSIFY', name + ':gate', case)
        if release:
            record('EFFECT', name + ':effect', {'case': name, 'file_sha256': observed['sha256'],
                'cause_protocol_hash': result.protocol.protocol_hash})
        record('READBACK', name + ':readback', {'case': name, **observed})
    # Feedback uses observed effect as the next past, rather than treating prediction as observation.
    successor = {'status': 'OBSERVED', 'state': {'counter': cases[0]['effect_observed']['value']},
                 'source_case': 'admitted', 'receipt_ref': sha256_identifier(encode(cases[0]))}
    next_target = successor['state']['counter'] + 1
    assert next_target == 4
    record('SUCCESSOR', 'feedback', {'observed_successor': successor,
        'next_anticipated': {'status': 'ANTICIPATED', 'target_counter': next_target}})
    before_restart = ledger.replay(0)
    frontier = ledger.history_frontier()
    epoch = ledger.epoch
    ledger.close()
    reader = Ledger(output / 'state', subject, read_only=True)
    assert reader.replay(0) == before_restart
    reader.close()
    for event, expected in zip(original_events, receipts):
        re_epoch, actual = _durable_read(str(output / 'state'), event)
        assert re_epoch == epoch and actual == expected
    (output / 'native_events.json').write_bytes(encode(original_events))
    (output / 'terminal_readbacks.json').write_bytes(encode(receipts))
    # These are present representations and observed processing steps, not future events.
    vertices = ['past-record', 'future-condition-record', 'gate', 'file-effect', 'readback', 'feedback']
    pairs = [('past-record', 'gate'), ('future-condition-record', 'gate'),
             ('gate', 'file-effect'), ('file-effect', 'readback'), ('readback', 'feedback')]
    subject_bytes = encode(subject); subject_ref = sha256_identifier(subject_bytes)
    evidence = {subject_ref: subject_bytes}; edges = []
    for a,b in pairs:
        item = {'source': a, 'target': b, 'weight': 1, 'subject_ref': subject_ref,
                'resolution': 'program-dependency-v1', 'scope': 'CONTROLLED_LOCAL_PROGRAM_ONLY',
                'method': 'known_program_dependency_with_gate_interventions_and_readback',
                'witness_ref': sha256_identifier(encode({'cases': cases, 'events': receipts}))}
        raw = encode(item); ref = sha256_identifier(raw); evidence[ref] = raw
        edges.append(Edge(a,b,1,ref))
    graph = DependencyGraph(vertices, edges, evidence, subject_ref=subject_ref,
                resolution='program-dependency-v1', scope='CONTROLLED_LOCAL_PROGRAM_ONLY')
    queries = [graph.query('past-record','readback'), graph.query('readback','past-record'),
               graph.query('readback','past-record', structural=True),
               graph.query('future-condition-record','gate'),
               graph.query('past-record','feedback')]
    assert [q['distance'] for q in queries] == [3, None, 3, 1, 4]
    report = {'schema': 'qikvrt_temporal_memory_local_witness_v1',
        'subject': subject, 'source_binding': source, 'cases': cases,
        'past_ref': past_hash, 'epoch': epoch, 'native_event_count': len(receipts),
        'history_frontier': frontier, 'restart_readback_equal': True,
        'feedback_next_target': next_target, 'distance_queries': queries,
        'graph': {'vertices': vertices, 'edges': [e.__dict__ for e in edges],
                  'subject_ref': subject_ref, 'evidence': {k:v.decode() for k,v in evidence.items()}},
        'conformance_witness_passed': True,
        'limits': {'isolated_local_program_only': True, 'fixture_ledger_not_productive_journal': True,
            'each_graph_edge_independently_intervened': False,
            'all_causal_influences_observed': False, 'independent_external_host_witness': False,
            'physical_retrocausality_proved': False, 'biological_life_or_consciousness_proved': False,
            'main_integration': False, 'productive_mesh_acceptance': False,
            'new_lean_kernel_proof': False}, 'effect_ack_done': False}
    (output / 'witness.json').write_bytes(encode(report))
    print(json.dumps({'output': str(output), 'cases': len(cases), 'native_events': len(receipts),
                      'conformance_witness_passed': True, 'effect_ack_done': False}))


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--output', type=Path, required=True)
    run(p.parse_args().output.resolve())
