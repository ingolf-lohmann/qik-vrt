# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from run_temporal_memory_witness import run
from verify_temporal_memory_witness import verify


class WitnessVerificationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.output = Path(cls.temp.name) / 'witness'
        with contextlib.redirect_stdout(io.StringIO()): run(cls.output)

    @classmethod
    def tearDownClass(cls): cls.temp.cleanup()

    def mutate(self, relative, change):
        path = self.output / relative
        original = path.read_bytes()
        data = json.loads(original); change(data)
        try:
            path.write_text(json.dumps(data))
            with self.assertRaises(ValueError): verify(self.output)
        finally:
            path.write_bytes(original)

    def test_independent_reader_accepts_bound_run(self):
        self.assertTrue(verify(self.output)['read_only_verification_passed'])

    def test_actual_file_tampering_rejected(self):
        self.mutate('admitted/counter.json', lambda x: x.update(counter=99))

    def test_prediction_promotion_rejected(self):
        self.mutate('admitted/anticipated.json', lambda x: x.update(status='OBSERVED'))

    def test_forged_protocol_done_rejected(self):
        self.mutate('missing_authorization/protocol.json', lambda x: x.update(state='EFFECT_ACK_DONE', ordinary_release=True))

    def test_altered_native_readback_rejected(self):
        self.mutate('terminal_readbacks.json', lambda x: x[0].update(ledger_digest='0'*64))

    def test_forged_distance_rejected(self):
        self.mutate('witness.json', lambda x: x['distance_queries'][0].update(distance=0))

    def test_inflated_completion_claim_rejected(self):
        self.mutate('witness.json', lambda x: x.update(effect_ack_done=True))


if __name__ == '__main__': unittest.main()
