# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Copyright 2026 Ingolf Lohmann.
"""Finite, local process-replica benchmark, reusing exact QIKVRT codecs.

This is a measurement harness, not a production Mesh executor or new wire format.
"""
from __future__ import annotations
import concurrent.futures as futures
import csv
import hashlib
import importlib
import json
import multiprocessing as mp
import os
import pathlib
import platform
import random
import shutil
import statistics
import struct
import sys
import time
import zlib

ROOT = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from src import qikvrt_standpoint_codex as codex

SEED = (ROOT / 'canonical/QIKVRT_STANDPOINT_SIGNATURE_V1.bin').read_bytes()
PIN = '27a84a7e19e1b46f50d3a855b87da65f5fe07b806575b0d15ca0587b7cab5792'
assert len(SEED) == 400 and hashlib.sha256(SEED).hexdigest() == PIN
SHARED = 32
PAYLOAD_BYTES = 4096
PASSES = 4
REPEATS = 7
WORKERS = (1, 2, 4, 8)
_gate = _codec = _codex = _node = None

def sha(b):
    return hashlib.sha256(b).hexdigest()

def utc():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

def member(label, index):
    name = label.encode() + b':' + str(index).encode()
    stable_id = hashlib.sha256(b'QIKVRT-BENCH-LABEL-V1\0' + name).digest()
    kind = index % 4
    if kind == 0:
        payload = bytes(PAYLOAD_BYTES)
    elif kind == 1:
        text = ('QIKVRT Erkenntnis, Provenienz, Unsicherheit. ' + str(index)).encode()
        payload = (text * (PAYLOAD_BYTES // len(text) + 1))[:PAYLOAD_BYTES]
    elif kind == 2:
        payload = hashlib.shake_256(b'QIKVRT-BENCH-BYTES-V1\0' + name).digest(PAYLOAD_BYTES)
    else:
        payload = (b'equal payload, distinct logical elements\0' * 120)[:PAYLOAD_BYTES]
        payload = payload.ljust(PAYLOAD_BYTES, b'\xff')
    return stable_id, payload

def input_records(count):
    return dict([member('shared', i) for i in range(SHARED)] +
                [member('unique', i) for i in range(count)])

def independent_wire(records):
    parts = []
    for stable_id, payload in sorted(records.items()):
        length = struct.pack('>Q', len(payload))
        identity = hashlib.sha256(b'QIKVRT-ELEMENT-V1\0\0\1' + SEED + stable_id + length + payload).digest()
        parts.append(SEED + stable_id + identity + length + payload)
    body = b''.join(parts)
    return struct.pack('>8sHHQQ', b'QIKVRTSS', 1, 400, len(records), len(body)) + SEED + body

def independent_parse(wire):
    if len(wire) < 428:
        raise ValueError('truncated snapshot')
    magic, version, seed_len, count, body_len = struct.unpack_from('>8sHHQQ', wire)
    if (magic, version, seed_len, body_len) != (b'QIKVRTSS', 1, 400, len(wire)-428):
        raise ValueError('header mismatch')
    if wire[28:428] != SEED:
        raise ValueError('seed mismatch')
    cursor, previous, out = 428, None, {}
    for _ in range(count):
        if cursor + 472 > len(wire) or wire[cursor:cursor+400] != SEED:
            raise ValueError('record seed or length')
        sid = wire[cursor+400:cursor+432]
        identity = wire[cursor+432:cursor+464]
        length = struct.unpack_from('>Q', wire, cursor+464)[0]
        cursor += 472
        if length > len(wire)-cursor or (previous is not None and sid <= previous):
            raise ValueError('length or order')
        payload = wire[cursor:cursor+length]
        cursor += length
        expected = hashlib.sha256(b'QIKVRT-ELEMENT-V1\0\0\1' + SEED + sid + struct.pack('>Q', length) + payload).digest()
        if expected != identity:
            raise ValueError('identity mismatch')
        out[sid], previous = payload, sid
    if cursor != len(wire):
        raise ValueError('trailing bytes')
    return out

def merge_checked(wires):
    merged, duplicates = {}, 0
    for wire in wires:
        for sid, payload in independent_parse(wire).items():
            if sid in merged:
                if merged[sid] != payload:
                    # Keep inputs intact; no successor or overwrite on conflict.
                    raise ValueError('HOLD_CONFLICT_INPUTS_PRESERVED')
                duplicates += 1
            else:
                merged[sid] = payload
    return merged, duplicates

def init_worker(gate, nodes):
    global _gate, _codec, _codex, _node
    _gate, _node = gate, nodes.get(timeout=30)
    base = ROOT / 'replicas' / _node / 'generation2'
    manifest = json.loads((ROOT/'source_binding.json').read_text())
    for item in manifest['files']:
        if not item['path'].startswith('src/'):
            continue
        raw = (base/item['path']).read_bytes()
        git_blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        if git_blob != item['git_blob_sha1']:
            raise ValueError('replica source mismatch')
    sys.path.insert(0, str(base))
    for name in list(sys.modules):
        if name == 'src' or name.startswith('src.'):
            del sys.modules[name]
    _codec = importlib.import_module('src.qikvrt_codec')
    _codex = importlib.import_module('src.qikvrt_standpoint_codex')
    if _codex.QIKVRT_SIGNATURE != SEED:
        raise ValueError('replica seed mismatch')

def run_shard(start, stop, trial):
    _gate.wait(timeout=60)
    wall, cpu = time.perf_counter_ns(), time.process_time_ns()
    items = [member('shared', i) for i in range(SHARED)] + [member('unique', i) for i in range(start, stop)]
    elements = tuple(_codex.Element(sid, data) for sid, data in items)
    wire = _codex.serialize(elements)
    clone_start = time.perf_counter_ns()
    first_clone = bytes(bytearray(wire))
    second_clone = bytes(bytearray(first_clone))
    if first_clone != wire or second_clone != wire:
        raise ValueError('clone bytes changed')
    clone_ns = time.perf_counter_ns() - clone_start
    wire_hash = sha(wire)
    encoded = b''
    for _ in range(PASSES):
        encoded = _codec.encode(second_clone, signature=SEED, profile='fast', probe=True)
        decoded = _codec.decode(encoded, signature=SEED)
        if decoded != wire or sha(decoded) != wire_hash:
            raise ValueError('byte transport failed')
        restored = _codex.deserialize(decoded)
        if _codex.serialize(restored) != wire:
            raise ValueError('canonical roundtrip failed')
    return {'wire': wire, 'receipt': {'node_id':_node, 'pid':os.getpid(), 'trial':trial,
        'range':[start,stop], 'elements':len(elements), 'wire_bytes':len(wire),
        'wire_sha256':wire_hash, 'encoded_bytes':len(encoded),
        'wall_ns':time.perf_counter_ns()-wall, 'cpu_ns':time.process_time_ns()-cpu,
        'clone_copy_ns':clone_ns, 'source_clone_depth':2, 'data_clone_depth':2,
        'seed_sha256':PIN, 'roundtrip_passes':PASSES}}

def prepare_replicas():
    start = time.perf_counter_ns()
    sources = ('src/qikvrt_codec.py', 'src/qikvrt_standpoint_codex.py', 'src/qikvrt_effect_ack.py')
    count, total = 0, 0
    for n in WORKERS:
        for k in range(n):
            node = f'workers{n}-node{k}'
            first, second = ROOT/'replicas'/node/'generation1', ROOT/'replicas'/node/'generation2'
            for rel in sources:
                a,b = first/rel,second/rel
                a.parent.mkdir(parents=True,exist_ok=True); b.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(ROOT/rel,a);shutil.copyfile(a,b)
                if a.read_bytes()!=b.read_bytes() or a.read_bytes()!=(ROOT/rel).read_bytes():
                    raise ValueError('source clone mismatch')
                total += a.stat().st_size + b.stat().st_size
            count += 1
    return {'replicas':count,'source_depth':2,'copied_bytes':total,'wall_ns':time.perf_counter_ns()-start}

def measure(pool, n, mode, repetition):
    count = 1024 if mode == 'strong_fixed_work' else 256*n
    # Accepted input and independent expected bytes are frozen before timing.
    expected = input_records(count)
    expected_wire = independent_wire(expected)
    expected_hash = sha(expected_wire)
    out = ROOT/'readback'/f'{mode}.qikvrt'
    predecessor = sha(out.read_bytes()) if out.exists() else None
    start, parent_cpu = time.perf_counter_ns(), time.process_time_ns()
    batch = [pool.submit(run_shard, count*k//n, count*(k+1)//n,
                         f'{mode}:{repetition}:{n}') for k in range(n)]
    returned = [future.result(timeout=120) for future in batch]
    compute_ns = time.perf_counter_ns()-start
    receipts = [r['receipt'] for r in returned]
    if len({r['pid'] for r in receipts}) != n or len({r['node_id'] for r in receipts}) != n:
        raise ValueError('worker isolation missing')
    merge_start = time.perf_counter_ns()
    wires = [r['wire'] for r in returned]
    merged, duplicate_count = merge_checked(wires)
    if duplicate_count != SHARED*(n-1) or merged != expected:
        raise ValueError('consolidation not lossless')
    consolidated = codex.serialize(codex.Element(sid,payload) for sid,payload in merged.items())
    if consolidated != expected_wire or independent_parse(consolidated) != expected:
        raise ValueError('independent canonical verification failed')
    # Reobserve, compare expected predecessor, separate parent writer, fresh readback.
    current = sha(out.read_bytes()) if out.exists() else None
    if current != predecessor:
        raise ValueError('CAS predecessor changed')
    stage = out.with_suffix('.stage')
    stage.write_bytes(consolidated)
    os.replace(stage,out)
    readback = out.read_bytes()
    if readback != expected_wire or sha(readback) != expected_hash:
        raise ValueError('fresh file readback failed')
    if independent_parse(readback) != expected:
        raise ValueError('fresh readback lost records')
    consolidation_ns = time.perf_counter_ns()-merge_start
    elapsed = time.perf_counter_ns()-start
    row = {'mode':mode,'repetition':repetition,'workers':n,'unique_elements':len(expected),
           'useful_task_elements':count,'useful_payload_bytes':count*PAYLOAD_BYTES,
           'submitted_elements':count+SHARED*n,'duplicate_records_removed':duplicate_count,
           'wall_ns':elapsed,'compute_collect_ns':compute_ns,'consolidation_readback_ns':consolidation_ns,
           'child_cpu_ns':sum(r['cpu_ns'] for r in receipts),
           'parent_cpu_ns':time.process_time_ns()-parent_cpu,
           'throughput_elements_s':count/(elapsed/1e9),
           'throughput_mib_s':count*PAYLOAD_BYTES/(1024**2)/(elapsed/1e9),
           'received_snapshot_bytes':sum(len(w) for w in wires),'consolidated_snapshot_bytes':len(readback),
           'snapshot_sha256':expected_hash,'seed_sha256':PIN,'lossless':True,
           'all_stable_ids_preserved':True,'identical_payload_distinct_ids_preserved':True,
           'source_clone_depth':2,'data_clone_depth':2,'fresh_readback':True,
           'writer_pid':os.getpid(),'node_receipts':receipts,'observed_at_utc':utc()}
    with (ROOT/'trial_ledger.jsonl').open('a') as ledger:
        ledger.write(json.dumps(row,sort_keys=True)+'\n')
    return row

def negative_controls():
    sid=hashlib.sha256(b'conflict').digest()
    a=codex.serialize([codex.Element(sid,b'one')])
    b=codex.serialize([codex.Element(sid,b'two')])
    preserved=(sha(a),sha(b))
    try:
        merge_checked([a,b])
    except ValueError as e:
        if str(e)!='HOLD_CONFLICT_INPUTS_PRESERVED':raise
    else:
        raise AssertionError('conflicting overwrite accepted')
    assert preserved==(sha(a),sha(b))
    merged,dup=merge_checked([a,a]);assert merged=={sid:b'one'} and dup==1
    sid2=hashlib.sha256(b'distinct logical identity').digest()
    c=codex.serialize([codex.Element(sid2,b'one')])
    merged,dup=merge_checked([a,c]);assert len(merged)==2 and dup==0
    bad=bytearray(a);bad[-1]^=1
    try:independent_parse(bytes(bad))
    except ValueError:pass
    else:raise AssertionError('corruption accepted')
    return {'conflicts_hold_inputs_preserved':True,'exact_duplicate_only_deduplicated':True,
            'same_payload_distinct_ids_preserved':True,'corruption_rejected':True}

def main():
    (ROOT/'readback').mkdir(exist_ok=True)
    ledger=ROOT/'trial_ledger.jsonl'
    if ledger.exists():raise RuntimeError('create-only measurement; ledger already exists')
    source=json.loads((ROOT/'source_binding.json').read_text())
    for i in source['files']:
        b=(ROOT/i['path']).read_bytes()
        assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==i['git_blob_sha1']
    signature_pins={'GOLDKELCH_SIGNATURE_400_V1.bin':'e189368017baf54b2dc17ac777a059ee1ecb209baa59eb7b56c4c1023397fc41',
                    'INGOLF_LOHMANN_SIGNATURE_400_V1.bin':'891ca697515470ed2b137b0181f515498a6e5cb99b4286df7788c90cce22cf6f'}
    for name,pin in signature_pins.items():
        b=(ROOT/'signatures'/name).read_bytes();assert len(b)==400 and sha(b)==pin
        a,c=b[32::2],b[33::2];data=a[:134]+c[:134]
        version,identifier,length,crc=struct.unpack('>BBHI',data[:8])
        assert version==1 and identifier==(1 if name.startswith('INGOLF') else 0)
        assert length==260 and zlib.crc32(data[8:])==crc and zlib.decompress(data[8:],-15)==SEED
    prep=prepare_replicas()
    ctx=mp.get_context('spawn');pools={};warmups=[];rows=[]
    cpu_before=pathlib.Path('/sys/fs/cgroup/cpu.stat').read_text()
    try:
        for n in WORKERS:
            nodes=ctx.Queue()
            for k in range(n):nodes.put(f'workers{n}-node{k}')
            pools[n]=futures.ProcessPoolExecutor(max_workers=n,mp_context=ctx,
                       initializer=init_worker,initargs=(ctx.Barrier(n),nodes))
            # Cold pool start plus warm-up recorded separately from steady trials.
            for mode in ('strong_fixed_work','weak_fixed_work_per_worker'):
                row=measure(pools[n],n,mode,-1)
                warmups.append(row)
            print(json.dumps({'transition':'WARMUP_VERIFIED','workers':n}),flush=True)
        rng=random.Random(20261002)
        for repetition in range(REPEATS):
            order=[(n,mode) for n in WORKERS for mode in ('strong_fixed_work','weak_fixed_work_per_worker')]
            rng.shuffle(order)
            for n,mode in order:
                rows.append(measure(pools[n],n,mode,repetition))
            print(json.dumps({'transition':'ROUND_VERIFIED','round':repetition+1,'rows':len(rows),'lossless':True}),flush=True)
    finally:
        for pool in pools.values():pool.shutdown(wait=True,cancel_futures=True)
    groups=[]
    for mode in ('strong_fixed_work','weak_fixed_work_per_worker'):
        baseline=[r for r in rows if r['workers']==1 and r['mode']==mode]
        baseline_rate=statistics.median(r['throughput_elements_s'] for r in baseline)
        for n in WORKERS:
            r=[r for r in rows if r['workers']==n and r['mode']==mode]
            times=sorted(x['wall_ns'] for x in r)
            rate=statistics.median(x['throughput_elements_s'] for x in r)
            groups.append({'mode':mode,'workers':n,'repeats':len(r),'useful_task_elements':r[0]['useful_task_elements'],
                 'wall_median_ms':statistics.median(times)/1e6,'wall_min_ms':min(times)/1e6,'wall_max_ms':max(times)/1e6,
                 'throughput_elements_s':rate,'throughput_mib_s':statistics.median(x['throughput_mib_s'] for x in r),
                 'throughput_vs_one_worker':rate/baseline_rate,'parallel_efficiency':rate/baseline_rate/n,
                 'consolidation_median_ms':statistics.median(x['consolidation_readback_ns'] for x in r)/1e6,
                 'cpu_median_ms':statistics.median(x['child_cpu_ns']+x['parent_cpu_ns'] for x in r)/1e6,
                 'lossless_trials':sum(x['lossless'] and x['fresh_readback'] for x in r),
                 'duplicate_records_removed_per_trial':r[0]['duplicate_records_removed'],
                 'received_snapshot_bytes':r[0]['received_snapshot_bytes'],
                 'consolidated_snapshot_bytes':r[0]['consolidated_snapshot_bytes']})
    result={'schema':'qikvrt_local_clone_scaling_measurement_v1','observed_at_utc':utc(),
       'source':source,'harness_sha256':sha(pathlib.Path(__file__).read_bytes()),
       'environment':{'python':platform.python_version(),'platform':platform.platform(),
          'cpu_count':os.cpu_count(),'cpu_affinity':sorted(os.sched_getaffinity(0)),
          'cpu_max':pathlib.Path('/sys/fs/cgroup/cpu.max').read_text().strip(),
          'cpu_stat_before':cpu_before,'cpu_stat_after':pathlib.Path('/sys/fs/cgroup/cpu.stat').read_text(),
          'zlib':zlib.ZLIB_RUNTIME_VERSION,'filesystem':'tmpfs; no physical disk durability test'},
       'conditions':{'repeats':REPEATS,'payload_bytes_per_element':PAYLOAD_BYTES,'codec_roundtrips_per_shard':PASSES,
          'shared_base_elements':SHARED,'order':'interleaved deterministic shuffle','start_method':'spawn',
          'cold_start':'warmup recorded separately','cpu_work':'snapshot serialization, zlib fast encode/decode, byte checks',
          'consolidation':'independent parser and identity checks, exact duplicate removal, separate parent writer, predecessor comparison, fresh tmpfs readback'},
       'source_replication':prep,'signature_pins':signature_pins,'groups':groups,
       'rows':rows,'warmups':warmups,'negative_controls':negative_controls(),
       'claims':{'finite_byte_preservation_verified':True,'same_payload_distinct_logical_ids_preserved':True,
           'full_live_repository_clones_verified':False,'distributed_network_scaling_verified':False,
           'ai_semantic_quality_benchmarked':False,'global_optimality_proved':False,'infinite_speed_proved':False,
           'authority_activation':False,'effect_ack_done':False}}
    (ROOT/'measurement.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    with (ROOT/'summary.csv').open('w',newline='') as out:
        writer=csv.DictWriter(out,fieldnames=list(groups[0]));writer.writeheader();writer.writerows(groups)
    print(json.dumps({'transition':'MEASUREMENT_COMPLETE','groups':groups,'lossless_trials':len(rows),'negative_controls':result['negative_controls']}),flush=True)

if __name__=='__main__':
    main()
