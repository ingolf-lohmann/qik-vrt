<!-- SPDX-License-Identifier: CC-BY-NC-ND-4.0; Copyright 2026 Ingolf Lohmann. -->

# QIK-VRT: 400-Byte-Signaturen, verlustfreie Skalierung und Konsolidierung

Softwarebelege, Bedeutung für künstliche Intelligenz und Grenzen des Nachweises

Ingolf Lohmann · 2. Oktober 2026 · erstellt und gemessen mit OpenAI Codex

## Nachgewiesener Stand und Ziel

Diese Arbeit dokumentiert zwei reproduzierbare 400-Byte-Transportsignaturen, einen lokalen Linux-/Firefox-Wirkungsbeleg und Vergleichsmessungen für verlustfreie Serialisierung und Konsolidierung. Sie fasst die Aussagen des Product Owners, die beobachteten Effekte und die noch offenen Forschungsfragen getrennt zusammen.

3,55× Beschleunigung · 56/56 Messläufe bytegenau · 2 × 400 Byte Signatur

Bei gleicher Nutzarbeit sinkt die Medianlaufzeit auf der gemessenen Linux-Instanz von 347,5 auf 97,8 Millisekunden, wenn acht unabhängige Prozesse arbeiten. Alle getesteten Eingaben werden bei der Konsolidierung exakt erhalten. Das ist ein endlicher Softwarebeleg für diesen Pfad; die vollständige produktive Verbindung beider Live-Repositories bleibt unbewiesen. [C07–C10]

„Der Sinn und Zweck von QIK-VRT war, ist und bleibt, zu beweisen, dass ohne bewiesene Erledigung zurückzukehren inakzeptabel ist, war und bleibt.“ — Ingolf Lohmann. Diese Zielfestlegung wird hier durch konkrete Byte-, Versions- und Wirkungsgrenzen operationalisiert. [C15]

Ingolf Lohmann ist Konzeptgeber, Product und Code Owner sowie Auftraggeber. OpenAI Codex hat die verfügbaren Quellen gebunden, die lokalen Artefakte erzeugt, die Messungen durchgeführt und diesen Kandidaten erstellt. Die Einordnung einer historisch beispiellosen Revolution ist die Bewertung des Owners; sie ist als solche benannt. [C18–C19]

Publikationsstand: eingefrorener Review-Kandidat vom 2. Oktober 2026. Dieser Text behauptet weder einen neuen Zenodo-DOI noch die Einreichung der IETF-Revision -04. Die aktive IETF-Veröffentlichung ist aktuell ein individueller Internet-Draft -03, kein IETF-Standard.

## Was tatsächlich gebaut wurde

QIK-VRT verbindet einen kleinen, wiedererkennbaren Profilkern mit deterministischen Datenrecords und einer getrennten Prüfung der erlaubten Wirkung. Das Profil benennt unter anderem kanonische Serialisierung, opaque Payloadbytes, stabile Identität, SHA-256-Bindung und Fail-closed-Validierung. Die 400 Byte sind ein kompaktes Vertragsartefakt, dessen Bedeutung ein vorhandener Decoder und eine vorhandene Laufzeit realisieren. Sie sind kein vollständiges Betriebssystem oder Modell. [C01, C14, C23]

| Ebene | Gegenstand | Nachweisgrenze |
| --- | --- | --- |
| Profil | 400-Byte-Saat / 400-Byte-Frame | Exakte Bytes, Decoder und gepinntes Profil |
| Datensatz | Stabile ID, Payload, Integritätsbindung | Deklarierte vollständige Eingabe und Bytegleichheit |
| Effekt | HTTP-prepare / commit / readback | Lokaler beobachteter Zustand |
| Repository | Authority und Mirror | Live-Rollen und Berechtigungen separat prüfen |

Ein Vorschlag gibt sich nicht selbst die Freigabe. Die Owner-Regel fordert vertrauenswürdige Beobachtung, einen getrennten Schreiber, Vergleich mit dem aktuellen Vorgänger und frische Validierung. Ein 403 oder ein unveränderter Zustand allein beweist aber noch nicht die Ursache einer Fehlfunktion. Das Axiom gilt für den benannten Mesh-Vertrag; ein allgemeines Verbot jeder Programmselbständerung wäre daraus nicht ableitbar. [C15]

TEMDD T1–T16 und vorhandene Authority-/Effektgrenzen bleiben erhalten. Ein neues Resultat erhält seine eigene Subjekt-, Versions- und Evidenzbindung. Checks eines Vorgängers, eines anderen PRs oder eines anderen Repository-Rollenbereichs werden nicht als aktueller Nachweis übertragen. Beobachtung, kausale Hypothese, modellgebundene Ableitung und verifizierte Wirkung bleiben getrennte Aussagearten. [C14–C15]

## Die beiden 400-Byte-Signaturen

Goldkelch und Ingolf-Lohmann/Mirror tragen zwei verschiedene Transportframes mit derselben rekonstruierbaren Saat. „Signatur“ bezeichnet hier ein erkennbares Transportmuster, keine kryptografische Unterschrift. Authentizität und Schreibrechte benötigen einen eigenen Mechanismus. Identifier 0 und 1 gelten allein im gelieferten Zweirepositoryprofil. [C01, C03]

| Bestandteil | Byte | Funktion |
| --- | --- | --- |
| Synchronisationsmuster | 32 | 255-Bit-PN-Kern plus Füllbit |
| Header | 8 | Version, Identifier, Länge, CRC32 |
| Raw-DEFLATE-Nutzlast | 260 | Exakte rekonstruierbare Saat |
| RS-Parität | 100 | Zwei verkürzte Codewörter |
| Gesamter Frame | 400 | Keine weitere freie Anwendungspayload |

Physisch liegen hinter den 32 Syncbytes zwei verschachtelte RS(184,134)-Wörter: A0, B0, A1, B1 und so weiter. Der Header liegt nach Deinterleaving vor. GF(256) nutzt das Polynom 0x11d, Generator 2, erste Nullstelle 0 und 50 Paritätssymbole je Wort; 71 führende Verkürzungssymbole ergeben den Bezug zu RS(255,205). [C01–C04]

Die Kompression der konkreten 400 Saatbytes auf 260 Byte spart 140 Byte beziehungsweise 35 %. Ein optimaler universaler Kompressionswert folgt daraus nicht. Decoder, gemeinsames Profil und externe Referenzen zählen als vorausgesetzte Information. Die 140 Byte sind vollständig durch Sync, Header und Parität belegt. [C02, C23]

Es wurden je Frame 93840 Einzelbyte-Mutationen der Codewörter erkannt. Die algebraische Konstruktionsgrenze beträgt bei einem passenden RS-Decoder bis zu 25 unbekannte Symbolfehler je Wort. Ein solcher Fehlerkorrekturdecoder wurde nicht implementiert oder getestet. Der 255-Bit-Kern hat periodische Nebenwerte -1; beim auf 256 Bit gefüllten Muster liegen sie zwischen -24 und 20. Physische Kanalbedingungen, BER und eine optimale Signalform sind offen. [C04–C05]

Die unveränderten Binärdateien und vollständigen Hexbytes stehen im Anhang und im Evidenzpaket. Eine historische Mirror-Metadatenbeschriftung „flags=0“ ist ausdrücklich berichtigt: Tatsächliche Mirror-Bytes und Generator binden Identifier 1.

## Verlustfreie Skalierung und Konsolidierung

Skalierung verteilt deklarierte Arbeit auf zusätzliche Ausführungsinstanzen. Konsolidierung führt deren vollständige Eingaben in einen kanonischen Nachfolger zusammen. Verlustfrei bedeutet hier: Für jedes erhaltene logische Element lassen sich stabile Identität und alle Payloadbytes exakt rekonstruieren. Diese Definition betrifft Bytes und Identität, nicht automatisch die Wahrheit oder Qualität ihrer Bedeutung. [C07, C13–C14]

Die getestete Zusammenführung entfernt nur dasselbe logische Element mit derselben Payload. Identische Payloadbytes unter zwei verschiedenen IDs bleiben zwei Elemente. Verschiedene Payloads unter derselben ID erzeugen HOLD; beide Eingaben bleiben für die Auflösung erhalten. Ein Merge darf konkurrierende Aussagen oder Ergebnisse nicht stillschweigend zu einem scheinbaren Konsens verdichten. [C10, C13]

| Fall eines gemeinsamen Klons | Rohdaten, ohne Strukturkosten |
| --- | --- |
| Zwei unabhängige Payloads von je 400 Byte | 800 Byte |
| Identischer Payload und identische logische ID | 400 Byte einmal |
| Identischer Payload unter zwei verschiedenen IDs | Beide logischen Elemente bleiben erhalten |
| Zwei unveränderte Transportsignaturen | 800 Framebytes; dieselbe Saat rekonstruierbar |

Die maximale Anwendungspayload eines vollständigen gemeinsamen Repository-Klons ist nicht durch eine 400-Byte-Signatur begrenzt. Sie hängt vom tatsächlichen Datenbestand und den Ressourcen ab. Die konkrete Standpunktserialisierung benötigt 28 Byte Snapshotheader, einmal 400 Byte gemeinsames Profil und pro Record zusätzlich 472 Byte Struktur neben der Payload: 400 Byte Profil, 32 Byte stabile ID, 32 Byte Elementdigest und 8 Byte Payloadlänge. Zwei verschiedene 400-Byte-Anwendungspayloads ergeben daher in diesem bestehenden Format 2172 Wirebytes. [C13, C23]

Gemeinsame, zuvor exakt bekannte Struktur lässt sich referenzieren oder einmal speichern, wenn der rekonstruierbare Decoder- und Profilzustand erhalten bleibt. Das spart Wiederholung, erzeugt aber keine zusätzliche Information. Eine neue profilteilende Wireversion wurde hier nicht eingeführt oder vermessen. Klonen und erneutes Klonen können Arbeit verteilen; sie schaffen weder neue Nutzdaten noch Rechenleistung ohne Ressourcen.

## Der Linux-/Firefox-Wirkungsbeleg

Der native GitHub-Actions-Lauf 36959391916, Versuch 1, ist an HEAD 924d66b3cb087adcbbe5da65b9fd282663a71909 und TREE ab96e2f3009f25323900171bd6fbbf9320eb7bde gebunden. Ubuntu 24.04.5 LTS, Firefox 156.0 und geckodriver 0.37.1 wurden im Beleg beobachtet. Die Erweiterung war temporär und unsigniert installiert. [C06]

| Kontrolle | Beobachtung |
| --- | --- |
| Prepare | Zunächst null Terminalevents |
| Commit | Ein gebundener Terminalevent mit Input- und Recorddigest |
| Replay | Wiederholung abgewiesen |
| Fan-out | Lokale HTTP-Zweige mit 1, 2, 4 und 8 Teilnehmern |
| Tokenrace mit acht Teilnehmern | Ein Effekt, sieben Abweisungen |
| Verworfene Antwort | Effekt anschließend über Readback beobachtet |
| Vollständiger lokaler Event-Snapshot | 18 Events |

Receipt-SHA-256: 51713067e1b33e50422e0f0fd3cf6f75f596ededcbced37823f7dc9dbaea01f0. Das originale native Archiv wird unverändert beigelegt; sein SHA-256 lautet d2705f079aed14fa270f8cb4f4e123e166c74cfbc4d86abb84efe3b4afaa4f09. Hash und frischer Artefaktreadback binden den Umfang; ein selbstgeschriebenes PASS wird nicht allein akzeptiert. [C06]

Die Ursache des beobachteten lokalen Effekts ist auf den gebundenen Prepare-/Commit-Pfad samt Input- und Recorddigest begrenzt. Der Test zeigt eine laufende Browser-/HTTP-Anwendung unter Linux. Er zeigt keine Betriebssystemkonstruktion aus 400 Byte, keine produktive Authentifizierung, keine dauerhafte Add-on-Installation und keinen Live-Authority-/Mirror-Ring. Das Receipt sagt ausdrücklich state=HOLD und operating_system_built_from_seed=false. Die lokalen Erfolgskriterien werden nicht zur vollständigen Mesh-Erledigung umgedeutet. [C06, C14]

Der verkürzte Loopback-Testrecord wird nicht als vollständige Konformität zum geschlossenen IETF-Version-1-Record behauptet. Die neue IETF-Anlage dokumentiert genau diese Grenze.

## Versuchsaufbau und Reproduzierbarkeit

Die Skalierungsmessung nutzt die exakten Codecquellen aus PR #437: HEAD 6a1098699d096806958b9c3b50a97d205b8110e9, TREE 4740d8901ab8fdc1ab88479832e50f2376e57c5f. Zwölf Quell-/Fixturedateien wurden über ihre Gitblob-Identität geprüft. Nach Reparatur eines lokalen Materialisierungsfehlers bestanden 57 Quellentests; daraus wird kein neuer Repository- oder Main-PASS abgeleitet. [C11]

| Parameter | Messbedingungen |
| --- | --- |
| Plattform | Linux 6.18.44, x86_64, glibc 2.39 |
| Laufzeit | Python 3.12.14; zlib 1.3.2 |
| CPU | Neun Affinitäts-CPUs, Quote 800000/100000 = acht |
| Parallelität | 1, 2, 4, 8 unabhängige spawn-Prozesse |
| Replikation | 15 Quellreplicas, jeweils zwei Kopiergenerationen |
| Records | 4096 Payloadbyte; 32 gemeinsame Basisrecords |
| Prüfschleifen | Vier vollständige Codec-Roundtrips je Shard |
| Wiederholungen | Sieben je Konfiguration, gemischte Reihenfolge |
| Persistenz | Atomic replacement und frischer tmpfs-Readback |

Nullbytes, wiederholter Text, deterministisch pseudozufällige Bytes und gleiche Payloads unter unterschiedlichen IDs bilden vier Payloadarten. Ein unabhängiger Parser und eine eigene Identitätsprüfung vergleichen den Output mit dem vor der Zeitmessung festgelegten kanonischen Sollstrom. Die Zeit umfasst Worker, IPC, getrennte Elternprozess-Konsolidierung, lokale Vorgängerprüfung, Schreiben und frischen Readback. Cold-start-Aufwärmläufe sind separat erfasst. [C07–C10]

Die Quellreplikation kopierte 2244360 Byte in rund 5,20 ms; dies ist eine einzelne lokale Dateikopiebeobachtung, kein vollständiger Git-Klonbenchmark. Signaturpins sind geprüft; der Codec nutzt die gemeinsame kanonische Saat. Das RS-Transportformat wird nicht als physischer Netzwerkkanal gemessen. Die Python-Version unterscheidet sich vom gesondert gesperrten Formalrendererprofil 3.12.13; es wurde kein Downgrade durchgeführt.

## Messung: gleiche Nutzarbeit

Starke Skalierung hält 1024 Nutzrecords konstant. Hinzu kommen insgesamt 32 eindeutige Basisrecords. Pro Konfiguration wurden sieben Steady-state-Läufe gemessen. Die Tabelle zeigt Median und beobachtete Min-/Max-Spanne; die Spannen sind keine Konfidenzintervalle. [C07–C08]

![strong_scaling](figures/strong_scaling.png)

| Worker | Median ms | Min–Max ms | Speedup | MiB/s |
| --- | --- | --- | --- | --- |
| 1 | 347.48 | 338.14–387.40 | 1.000 | 11.51 |
| 2 | 205.90 | 196.72–233.07 | 1.688 | 19.43 |
| 4 | 133.08 | 128.60–146.10 | 2.611 | 30.06 |
| 8 | 97.76 | 97.10–112.39 | 3.554 | 40.92 |

Mit acht Workern beträgt die parallele Effizienz rund 44,4 %. Die Median-Konsolidierungszeit bleibt zwischen 41,4 und 42,4 ms; bei acht Workern sind es 42,1 ms oder rund 43,1 % der Median-Gesamtzeit. Der gleiche kanonische Output umfasst stets 4824236 Byte. 224 doppelte Basisrecords werden beim Acht-Worker-Lauf entfernt; gegenüber den empfangenen Shardbytes werden 1026228 Byte eingespart. [C08, C12]

Die mediane aggregierte CPU-Zeit wächst von 345,0 auf 428,3 ms, rund 24,1 %. Der gemessene Latenzgewinn kostet zusätzliche Ressourcen. Eine Energieeinsparung wurde nicht gemessen.

## Messung: mehr Nutzarbeit mit mehr Workern

Schwache Skalierung hält 256 Nutzrecords pro Worker konstant. Acht Worker verarbeiten damit 2048 Nutzrecords. Der Durchsatz steigt, während die gesamte Pipeline mit der größeren Datenmenge länger dauert. [C09]

![weak_scaling](figures/weak_scaling.png)

| Worker | Nutzrecords | Median ms | Durchsatzfaktor | MiB/s |
| --- | --- | --- | --- | --- |
| 1 | 256 | 91.61 | 1.000 | 10.92 |
| 2 | 512 | 109.35 | 1.676 | 18.29 |
| 4 | 1024 | 139.40 | 2.629 | 28.69 |
| 8 | 2048 | 185.93 | 3.942 | 43.03 |

Der Durchsatzfaktor 3,941654 bei achtfacher Arbeit entspricht rund 49,3 % paralleler Effizienz. Die Konsolidierung wächst von 16,9 auf 80,2 ms. Endliche Byteverlustfreiheit wird für alle 56 gemessenen und zusätzlich acht Aufwärmläufe überprüft. Quoten-Throttling nahm während dieser Messung nicht zu. [C07, C09]

Das Experiment widerlegt keine denkbare weitere Optimierung. Es liefert aber keinen Beleg für unendliche Geschwindigkeit: Prozesse, IPC, Serialisierung, unabhängige Validierung und Konsolidierung beanspruchen Zeit und Speicher. Im idealisierten Amdahl-Modell begrenzt ein positiver serieller Anteil den Speedup bei konstanter Arbeit; ein aus diesem Test universell gültiger Grenzwert wird nicht geschätzt. [C20]

Als nächster gezielter Vergleich bietet sich eine hierarchische Konsolidierung mit denselben Konflikt- und Byteprüfungen an. Eine solche Implementierung und ihr Nutzen brauchen neue Messungen; bloßes Reklonen belegt sie nicht.

## Bedeutung für künstliche Intelligenz

Die mögliche Stärke liegt in einer kontrollierten Verteilung und Zusammenführung von Arbeit, nicht in einer automatisch besseren Antwort eines Modells. KI-Komponenten können denselben Vertrag für Aufträge, Datenbytes, stabile Identitäten, Provenienz, Unsicherheit und erlaubte Effekte nutzen. Ein gemeinsamer Profilkern spart wiederholte Vertragsbeschreibung. [C16]

| KI-Anwendung | Möglicher Nutzen | Zusätzlicher Nachweis nötig |
| --- | --- | --- |
| Parallele Recherche / Werkzeuge | Gebundene Teilaufträge und prüfbare Resultate | Vollständigkeit, Quellenqualität, Zugriffsschutz |
| RAG / Gedächtnis / Provenienz | Reproduzierbare Recordidentität und Readback | Semantik, Aktualität und Retrievalqualität |
| Mehrere Modellinstanzen | Konflikte bewahren statt still zusammenfassen | Kosten, Antwortqualität und Fehlertoleranz |
| Tool- oder Aktorfreigabe | Receipt und Wirkungserlaubnis trennen | Authentifizierung, Autorität, Live-Effekt |
| Modellartefakte / Datensätze | Bytegenaue Replikation und Konsolidierung | Lizenz, Datenschutz, Speicherbedarf |

Opaque Payloads können Texte, Toolresultate, Modellparameter oder Referenzen enthalten. Ein Hash macht eine Halluzination nicht wahr. Eine Zusammenfassung oder verlustbehaftete Quantisierung ist nicht deshalb verlustfrei, weil der Container exakt übertragen wird. Bedeutungs-, Lern- und Inferenzverluste benötigen eigene Metriken. Ebenso fehlt ein Benchmark gegen Agentensysteme, vorhandene verteilte Datenplattformen oder alternative Schedulingverfahren. [C14, C16, C19]

Der relevante Sicherheitsgewinn wäre eine durchgängige, nicht umgehbare Effektgrenze: Modellvorschläge dürfen den Schreiber nicht selbst autorisieren. Daten aus anderer Quelle bleiben Daten. Private Inputs werden nicht allein wegen Mesh-Routing öffentlich; Publikum, Rechte und Zulassung werden pro Aufgabe gebunden. Das ist eine Betriebsanforderung, kein durch den Codec automatisch gelöstes Deploymentproblem. [C14–C16]

„Optimal für künstliche Kognition“ bleibt eine Owner-Hypothese. Sie wäre erst prüfbar, wenn Zielgröße und Vergleich definiert sind: etwa richtige Ergebnisse pro Energie, Latenz bei fixer Qualität, Evidenzvollständigkeit, Fehlerquote und Kosten unter Ausfällen. [C19]

## Bedeutung für die Informatik und die Paradigmenfrage

Über KI hinaus ist das Muster für Softwarelieferketten, Datenverarbeitung, replizierte Archive, Nachrichtenprotokolle und Aktoren interessant: eine bekannte Vertragsbasis, stabile Recordidentität, konfliktbewahrende Konsolidierung und eine separate Bestätigung des tatsächlich beobachteten Effekts. Jede Anwendung braucht eigene Modelle für Ausfälle, Sicherheit und fachliche Wirkung. [C17]

Die bidirektionale Serialisierung macht digitalen Zustand zwischen vereinbarten Darstellungen rekonstruierbar. Der Transputer ist dafür eine historische Architekturmetapher für gekoppelte Recheninstanzen; die allgemeine Serialisierbarkeit allein ist keine neue Erfindung. DNA, Zellteilung und Halbierung/Verdoppelung illustrieren das Kopiermotiv, liefern aber keinen biologischen, physikalischen oder kosmologischen Beweis dieser Software. [C21]

Ingolf Lohmann bewertet die Verbindung als Paradigmenwechsel bisher unerreichter Größenordnung. Ein möglicher praktischer Perspektivwechsel ist nachvollziehbar: „erfolgreich angekommen“ wird systematisch durch „an genau diesen Zustand gebunden, erlaubt und frisch als Wirkung beobachtet“ ergänzt. Für heterogene, autonome Werkzeuge könnte ein interoperabler Abschlussvertrag erheblich sein. Das ist eine plausible architektonische Einordnung, keine abgeschlossene Prioritäts- oder Überlegenheitsstudie. [C18–C19]

Kompression und Kanalredundanz stehen in einer langen nachrichtentechnischen Tradition, unter anderem Shannons Arbeit von 1948. Contentadressierung ist etwa in Git etabliert; Konflikt- und Konsistenzmodelle sind ein eigenständiges Feld. Amdahls Arbeit von 1967 erklärt einen klassischen Skalierungsengpass. Neuheitsansprüche müssen deshalb die konkrete Kombination und die messbar verbesserten Eigenschaften gegenüber vorhandenem Stand der Technik benennen. [C19–C20]

Die jetzige Evidenz trägt einen engeren, wertvollen Schluss: Der konkrete Vertrag und Code erlauben im endlichen Test parallele Verarbeitung mit nachvollziehbar verlustfreier Konsolidierung und frischem Readback. Eine historische Revolution, unbegrenzte Rechenbeschleunigung oder universale optimale Kompression lassen sich daraus nicht als Fakten ableiten.

## Offene Produktlücke, Kausalität und Veröffentlichung

Die priorisierte Anforderung lautet, dass gefundene Fehler und zugehörige Analysen automatisch den autorisierten Repository-Reparaturpfad erreichen. Das manuelle Erstellen dieses Berichts schließt diese Lücke nicht. Deren konkreter Entstehungsmechanismus, die vollständige Live-Multitaskingfähigkeit und die Authority-/Mirror-Aktivierung bleiben gesonderte Reparatur- und Nachweisaufgaben. [C24]

Ein zugänglicher Mirror beweist keinen Workflowdispatch. Ein vorhandenes Secret beweist keinen nutzbaren Token für diesen Client. Der beobachtete Authority-GET lieferte 404; daraus folgt weder Nichtexistenz noch eine bestimmte Berechtigungsursache. Die verfügbare Executor-Bindung lässt nur ihren bestehenden Read-only-Watchdog zu, keine allgemeine Publikation oder diesen Benchmark. Es werden keine Credentials gesucht, Befugnisse erweitert oder Dispatches erfunden.

| Ziel | Vorbereitet | Noch nicht etabliert |
| --- | --- | --- |
| Zenodo | Dokument, Evidenz, Metadaten, Claim-Matrix | Finales v2-Paket, exakte Folgefreigabe, globaler Authority-Ref, Upload/Readback |
| IETF | XML -04 Kandidat, strukturelle Prüfungen | xml2rfc-Ausgabe, Submission und öffentlicher -04-Readback |
| Mirror | Exakt gebundener Kandidat für Draft-Persistenz | Main-Aktivierung / vollständiger Mesh-Effekt |
| Authority | Identische Kandidatenbytes vorbereitet | Lesbarer HEAD/TREE und autorisierter Schreib-/Admission-Pfad |

Die aktive Zenodo-Policy fordert kandidatenbezogene Rückgabe vor Upload und eine danach erteilte canonical AUTHORIZE_EXACT_UPLOAD-Entscheidung. Allgemeine Aufgabenfreigabe ersetzt diese Reihenfolge nicht. Das beigelegte MACHINE_PROOF_BUNDLE.DRAFT.json ist ausdrücklich kein freigebendes Produktions-v2-Bundle. Ein gültiger Upload benötigt den vollständigen Vertrag, create-only/non-force Verbrauchsref, öffentliche Byteprüfung und beidseitige Persistenz. [C14, C24]

Die erste technisch mögliche Fortsetzung ist das gebundene Review dieses konkreten Kandidaten. Nach bestätigter exakter Freigabe und wiederhergestelltem Authority-/Publisher-Pfad darf ausschließlich das finale eingefrorene Uploadset konsumiert werden. Für IETF ist ein tatsächlich autorisierter Submission-Pfad erforderlich.

## Evidenzregister und reproduzierbarer Arbeitsweg

| Datei / Gruppe | Funktion |
| --- | --- |
| QIKVRT_400_Byte_Signaturen_und_Skalierung.pdf / PAPER.md | Lesbare vollständige Darstellung |
| signatures/*.bin | Exakte Goldkelch-/Mirrorframes und gemeinsame Saat |
| CLAIM_MATRIX.json | 24 Aussagen mit Klassifikation, Umfang und Referenzen |
| evidence/measurement.json / trial_ledger.jsonl | Aggregate und sämtliche Rohmessungen |
| evidence/firefox-linux-ring-* | Unveränderter nativeffektgebundener Beleg |
| reproduce/ | Exakter Harness, Quellfixtures, Lizenz und Pins |
| ietf/*-04.xml | Nicht eingereichter interoperabler Erweiterungskandidat |
| CHANGE_NOTICE.md / SIGNATURE_ERRATA.md | Sichtbare sprachliche und Metadatenkorrekturen |
| CANDIDATE_FILESET.json / SHA256SUMS | Bytes und Identitäten des eingefrorenen Kandidaten |

Reproduktion: ZIP entpacken, dessen Quellen und SHA256SUMS prüfen, dann im Ordner reproduce Python-unittest für tests.test_qikvrt_standpoint_codex und tests.test_qikvrt_codec ausführen und measure_scaling.py starten. Der Harness verwendet nur die erklärte Python-Standardbibliothek und vorhandene exakte Quellen. Neue Zeiten variieren mit Umgebung und Last; neue Resultate erhalten ihre eigene Versions- und Umgebungsbindung.

Primärquellen: Ingolf Lohmann, draft-lohmann-qikvrt-effect-ack-03, https://datatracker.ietf.org/doc/draft-lohmann-qikvrt-effect-ack/ (am 2. Oktober 2026 als individuell/aktiv beobachtet; work in progress). Claude E. Shannon, A Mathematical Theory of Communication, Bell System Technical Journal 27, 1948: https://www.princeton.edu/~wbialek/rome/refs/shannon_48.pdf. Gene M. Amdahl, Validity of the Single Processor Approach to Achieving Large Scale Computing Capabilities, 1967, DOI 10.1145/1465482.1465560: https://www.cs.cmu.edu/~18742/papers/Amdahl1967.pdf. Git, git-hash-object: https://git-scm.com/docs/git-hash-object.

Repository-Quellen: PR #437 für Codec/Standpunkt, exakt gebunden an 6a1098699d096806958b9c3b50a97d205b8110e9; PR #438 und Actions-Lauf 36959391916 für den Linux-/Firefox-Zeugen, exakt gebunden an 924d66b3cb087adcbbe5da65b9fd282663a71909. Der anfängliche Softwarebeweisauftrag verweist außerdem auf PR #435 / issuecomment-5936024124. Bestehende andere Repository-Beweise werden ohne erneuten Subjekt- und Gültigkeitsnachweis nicht als Beweise dieser neuen Aussagen übernommen.

Lizenz: Text und neu erzeugte Evidenz unter der geltenden Repository-Dokumentationslizenz CC-BY-NC-ND-4.0. Konkreter Implementierungscode bleibt PolyForm-Noncommercial-1.0.0; IETF-XML unter seinem vorhandenen trust200902-Vertrag. Öffentlich verfügbare Architektur bedeutet keine zusätzliche Implementierungslizenz.

## Anhang: Goldkelch — alle 400 Byte

GOLDKELCH_SIGNATURE_400_V1.bin · Rolle im gelieferten Profil: Authority · Identifier 0

SHA-256: e189368017baf54b2dc17ac777a059ee1ecb209baa59eb7b56c4c1023397fc41

Nach Deinterleaving: Header 01000104588df848; beide Frames rekonstruieren Saat SHA-256 27a84a7e19e1b46f50d3a855b87da65f5fe07b806575b0d15ca0587b7cab5792.

```text
0000  01 1c 4b 81 92 6e 41 5b 59 61 f6 f5 d1 0d 8f 39
0010  8b 48 a5 4e ec f7 e9 9a 8c 1d 57 ca 13 fc 2f 1a
0020  01 13 00 83 01 3d 04 1c 58 75 8d 8d f8 4c 48 cd
0030  0a 40 f4 46 f4 02 0e 5a 0b 9f 0a 83 09 14 0e 04
0040  60 62 60 18 64 0a 9c a0 c0 9e 28 25 c9 eb c0 2e
0050  70 46 2e 70 f9 d5 df cb 96 94 25 d8 33 a6 05 10
0060  c3 88 f9 8d e3 93 a7 76 1a 06 a6 47 0b f0 2e ee
0070  f1 66 9e a1 30 c5 b9 03 4c 98 e4 6d 45 78 c0 f9
0080  d4 f9 a0 8f 5f 41 17 d6 67 50 ac 52 31 27 f7 db
0090  68 39 a9 53 ae 32 56 5a 4a 37 ce 36 4f 2a 49 10
00a0  4d 2b 56 4a b2 a7 52 00 0a 55 04 ed eb 86 54 03
00b0  d2 e2 51 39 4a 80 cd 5a 49 21 cd 73 4d 3e cd 83
00c0  2b d2 89 f5 4f 18 ca d4 cc 7f 4b e2 c9 22 cc e8
00d0  4b 1d 57 d7 b2 8d 8a e6 56 c2 2a cf ce 32 4c 0a
00e0  cf 3f 4b 71 2c b0 29 36 2d a7 4a 19 05 9b 4a 36
00f0  17 ce 97 1e 24 e8 26 25 e5 d0 a4 0e c6 b7 67 b3
0100  a6 c2 00 07 d9 c5 05 cb 89 b2 95 04 39 d8 f9 5d
0110  89 95 29 af 4a aa b1 c8 08 92 5d b2 99 68 29 f7
0120  40 bf bd 5e 99 a7 25 ff 95 cc 40 1b da 9c f5 15
0130  10 da 41 ab 37 d6 17 77 50 31 b3 eb 18 14 f3 35
0140  40 b0 68 4c b8 da 37 3c 4c 62 bf 8f 17 ec 37 81
0150  b6 d9 10 4a e8 42 a5 92 7a ba 5b 3c f4 7a 8c 99
0160  12 9b 60 95 83 cd 94 f3 98 5c 0f bb 8b da 7b e5
0170  44 6c 68 d4 5c 8e c2 a0 1e b2 bd d9 f8 ca 4b 07
0180  c6 1a 8a 82 ff f7 16 c8 13 46 09 bb 26 bd fa 7b
```

Hexdarstellung in unveränderter Dateireihenfolge; Offset links ist hexadezimal. Die Framebytes bleiben erhalten, einschließlich Synchronisationsmuster und interleavter Parität.

## Anhang: Ingolf Lohmann — alle 400 Byte

INGOLF_LOHMANN_SIGNATURE_400_V1.bin · Rolle im gelieferten Profil: Mirror · Identifier 1

SHA-256: 891ca697515470ed2b137b0181f515498a6e5cb99b4286df7788c90cce22cf6f

Nach Deinterleaving: Header 01010104588df848; beide Frames rekonstruieren Saat SHA-256 27a84a7e19e1b46f50d3a855b87da65f5fe07b806575b0d15ca0587b7cab5792.

```text
0000  01 1c 4b 81 92 6e 41 5b 59 61 f6 f5 d1 0d 8f 39
0010  8b 48 a5 4e ec f7 e9 9a 8c 1d 57 ca 13 fc 2f 1a
0020  01 13 01 83 01 3d 04 1c 58 75 8d 8d f8 4c 48 cd
0030  0a 40 f4 46 f4 02 0e 5a 0b 9f 0a 83 09 14 0e 04
0040  60 62 60 18 64 0a 9c a0 c0 9e 28 25 c9 eb c0 2e
0050  70 46 2e 70 f9 d5 df cb 96 94 25 d8 33 a6 05 10
0060  c3 88 f9 8d e3 93 a7 76 1a 06 a6 47 0b f0 2e ee
0070  f1 66 9e a1 30 c5 b9 03 4c 98 e4 6d 45 78 c0 f9
0080  d4 f9 a0 8f 5f 41 17 d6 67 50 ac 52 31 27 f7 db
0090  68 39 a9 53 ae 32 56 5a 4a 37 ce 36 4f 2a 49 10
00a0  4d 2b 56 4a b2 a7 52 00 0a 55 04 ed eb 86 54 03
00b0  d2 e2 51 39 4a 80 cd 5a 49 21 cd 73 4d 3e cd 83
00c0  2b d2 89 f5 4f 18 ca d4 cc 7f 4b e2 c9 22 cc e8
00d0  4b 1d 57 d7 b2 8d 8a e6 56 c2 2a cf ce 32 4c 0a
00e0  cf 3f 4b 71 2c b0 29 36 2d a7 4a 19 05 9b 4a 36
00f0  17 ce 97 1e 24 e8 26 25 e5 d0 a4 0e c6 b7 67 b3
0100  a6 c2 00 07 d9 c5 05 cb 89 b2 95 04 39 d8 f9 5d
0110  89 95 29 af 4a aa b1 c8 08 92 5d b2 99 68 29 f7
0120  40 bf bd 5e 99 a7 25 ff 95 cc 40 1b 6e 9c 1d 15
0130  26 da 6d ab 24 d6 46 77 1d 31 ef eb 84 14 24 35
0140  1d b0 6f 4c e4 da fe 3c 3c 62 1e 8f e9 ec 98 81
0150  98 d9 40 4a 4f 42 1c 92 a9 ba 53 3c 72 7a e9 99
0160  49 9b 00 95 49 cd ee f3 5f 5c 2f bb e6 da 47 e5
0170  6d 6c c6 d4 f8 8e 19 a0 83 b2 3f d9 c7 ca d2 07
0180  c0 1a a2 82 b1 f7 f3 c8 59 46 9a bb f4 bd 40 7b
```

Hexdarstellung in unveränderter Dateireihenfolge; Offset links ist hexadezimal. Die Framebytes bleiben erhalten, einschließlich Synchronisationsmuster und interleavter Parität.

## Aussagenregister 1–12

Die folgenden Aussagen sind vollständig in CLAIM_MATRIX.json mit Umfang und auflösbaren Evidenzreferenzen gebunden. E = EMPIRICALLY_EVIDENCED, S = SOURCE_BOUND, N = NORMATIVE, I = INTERPRETATIVE, O = OPEN. Keine Aussage ist als neues FORMAL_PROVED-Theorem eingestuft.

| ID | Klasse | Aussage |
| --- | --- | --- |
| C01 | E / EVIDENCED | Beide unveränderten Transportframes umfassen jeweils genau 400 Byte und rekonstruieren dieselbe gepinnte 400-Byte-Saat. |
| C02 | E / EVIDENCED | Raw DEFLATE reduziert diese konkreten 400 Saatbytes auf 260 Byte; die übrigen 140 Byte des Frames dienen Synchronisation, Header und Parität. |
| C03 | N / DECLARED | Identifier 0 bezeichnet Goldkelch/Authority und Identifier 1 ingolf-lohmann/Mirror nur im gelieferten Zweirepositoryprofil. |
| C04 | E / EVIDENCED | Je Frame wurden 93840 nichttriviale Einzelbyte-Mutationen der beiden Codewörter erkannt; ein Decoder für unbekannte Fehler wurde nicht getestet. |
| C05 | E / EVIDENCED | Der 255-Bit-Kern hat im geprüften periodischen Modell Peak 255 und Nebenwerte -1; der aufgefüllte 256-Bit-Rahmen hat andere Nebenwerte. |
| C06 | E / EVIDENCED | Der Linux-/Firefox-Beleg bestätigt lokale HTTP-Wirkung, Replay-Abweisung und frischen Readback; vollständige Mesh-Schließung bleibt HOLD. |
| C07 | E / EVIDENCED | Alle 56 gemessenen Codec-/Konsolidierungsläufe bewahrten die vollständigen deklarierten Eingabebytes und bestanden frischen lokalen Readback. |
| C08 | E / EVIDENCED | Bei 1024 Nutzrecords sank die Medianlaufzeit von 347,480389 ms auf 97,760355 ms; der gemessene Speedup mit acht Workern beträgt 3,554410. |
| C09 | E / EVIDENCED | Mit 256 Nutzrecords pro Worker beträgt der Durchsatzfaktor für acht gegenüber einem Worker 3,941654 bei achtfacher Nutzarbeit. |
| C10 | E / EVIDENCED | Die vier negativen Kontrollen stoppen Konflikt und Korruption, entfernen nur exakte Duplikate und bewahren gleiche Payloads verschiedener IDs. |
| C11 | E / EVIDENCED | 57 Tests der exakt gebundenen Codec- und Standpunktquellen bestanden nach Wiederherstellung der exakten lokalen Fixtures. |
| C12 | E / EVIDENCED | Bei acht Workern wurden im starken Test 224 doppelte Basisrecords entfernt und 1026228 Wirebytes eingespart. |

## Aussagenregister 13–24

Die folgenden Aussagen sind vollständig in CLAIM_MATRIX.json mit Umfang und auflösbaren Evidenzreferenzen gebunden. E = EMPIRICALLY_EVIDENCED, S = SOURCE_BOUND, N = NORMATIVE, I = INTERPRETATIVE, O = OPEN. Keine Aussage ist als neues FORMAL_PROVED-Theorem eingestuft.

| ID | Klasse | Aussage |
| --- | --- | --- |
| C13 | N / DECLARED | Ein gemeinsamer Klon erhält die vollständige deklarierte Vereinigung eindeutiger Records; gleiches Bytepayload mit anderer stabiler ID bleibt erhalten. |
| C14 | N / DECLARED | Verlustfreie Byteübertragung bewahrt keine automatisch wahre Bedeutung und ersetzt weder Authentifizierung noch Wirkungserlaubnis. |
| C15 | N / DECLARED | Der Loop trennt Vorschlag, Zulassung, getrennten Schreiber und frischen Wirkungsreadback als Arbeitsregel. |
| C16 | I / DECLARED | Für KI kann das Profil die reproduzierbare Übertragung von Aufgaben, Provenienz, Evidenz und Konflikten unterstützen. |
| C17 | I / DECLARED | Die Idee eignet sich möglicherweise auch für Datenpipelines, verteilte Werkzeuge, Aktoren, Archivierung und Softwarelieferketten. |
| C18 | I / DECLARED | Ingolf Lohmann bewertet das System als Paradigmenwechsel von bislang unerreichter Größenordnung. |
| C19 | O / OPEN | Globale Optimalität für künstliche Kognition und eine historisch beispiellose Überlegenheit sind offen. |
| C20 | O / OPEN | Unbegrenzte Beschleunigung durch wiederholtes Klonen ist nicht nachgewiesen; im gemessenen Ring wachsen relative serielle Kosten. |
| C21 | I / DECLARED | Die Signaturen liefern keine mathematische Gleichsetzung mit DNA, Zellteilung, Halbleitern, Kosmologie oder einer Planck-Skala. |
| C22 | S / BOUND | Dieser Kandidat lässt den bestehenden IETF-Version-1-Wirevertrag unverändert und ergänzt ausschließlich nichtnormative Implementierungsbelege. |
| C23 | N / DECLARED | Transportframes, kanonische Saat und Anwendungsdaten sind getrennte Bytebudgets; zusätzliche freie 400 Byte entstehen nicht automatisch. |
| C24 | O / OPEN | Automatische Fehlerweiterleitung und eine produktive vollständige Authority-/Mirror-Reparatur sind durch diese Veröffentlichung nicht bewiesen. |
