# QIK-VRT: Signaturen, Skalierung, Konsolidierung

Publikationskandidat: qikvrt-400-byte-signatures-lossless-scaling-20261002-v1.
PAPER.md und das PDF enthalten die vollständige deutsche Darstellung.
Beide 400-Byte-Frames liegen unverändert in signatures/; Hexbytes auch im Anhang.
Die 56 Rohmessungen, acht Aufwärmläufe und native Firefox-Evidenz liegen in evidence/.

## Reproduktion

1. SHA256SUMS gegen die exakt entpackten Dateien prüfen.
2. Im Ordner reproduce ausführen:

```bash
python -m unittest tests.test_qikvrt_standpoint_codex tests.test_qikvrt_codec
python measure_scaling.py
```

Das überschreibt nur Messartefakte innerhalb dieses Reproduktionsordners.
Der Benchmark schreibt etwa 15 MB temporäre Snapshotdaten und verwendet bis
zu acht unabhängige Prozesse. Laufzeitbedingungen erneut protokollieren.
Die Generatoren in signatures/*/build_verify.py können im jeweiligen Ordner
gestartet werden. Sie erzeugen dieselben Frames, neue Verifikationsmetadaten
und ein lokales ZIP. Historische Belege in evidence/ werden nicht überschrieben.

## Veröffentlichung und Grenzen

Der IETF-XML-Kandidat -04 ist nicht eingereicht. Der veröffentlichte Stand ist -03.
Zenodo-Metadaten sind vorbereitet; kein Record, DOI, Upload oder Public Readback
wird behauptet. Es fehlt das finale freigebende v2-Paket samt exakter, nach
Rückgabe erteilter Owner-Entscheidung und globalem Authority-Verbrauchsref.
ROUTE_AND_RESUME_STATE.json bindet weitere konkrete Ausführungsgrenzen.
Eine Mirror-Draft-Persistenz ist keine Authority-Persistenz oder Main-Aktivierung.

## Rechte

Dokument und neue Evidenz: CC-BY-NC-ND-4.0, Copyright 2026 Ingolf Lohmann.
Vorhandener und neuer konkreter Implementierungscode:
PolyForm-Noncommercial-1.0.0. IETF-XML behält ipr=trust200902.
Öffentliche Architektur bedeutet keine weitergehende Implementierungslizenz.
