import hashlib, json, pathlib, struct, zlib, platform, zipfile
ROOT=pathlib.Path(__file__).resolve().parent
PIN='27a84a7e19e1b46f50d3a855b87da65f5fe07b806575b0d15ca0587b7cab5792'
seed=(ROOT/'canonical_seed.bin').read_bytes()
assert len(seed)==400 and hashlib.sha256(seed).hexdigest()==PIN
co=zlib.compressobj(1,zlib.DEFLATED,-15,1,zlib.Z_DEFAULT_STRATEGY)
payload=co.compress(seed)+co.flush()
assert len(payload)==260 and zlib.decompress(payload,-15)==seed
exp=[]; log=[0]*256; x=1
for i in range(255):
    exp.append(x); log[x]=i
    x<<=1
    if x&256: x^=0x11d
assert x==1 and len(set(exp))==255
exp*=2
def mul(a,b): return exp[log[a]+log[b]] if a and b else 0
def pmul(a,b):
    out=[0]*(len(a)+len(b)-1)
    for i,u in enumerate(a):
        for j,v in enumerate(b): out[i+j]^=mul(u,v)
    return out
def evaluate(poly,x):
    y=0
    for c in poly: y=mul(y,x)^c
    return y
g=[1]
for i in range(50): g=pmul(g,[1,exp[i]])
def encode(data):
    assert len(data)==134
    work=list(data)+[0]*50
    for i in range(len(data)):
        c=work[i]
        for j in range(1,len(g)): work[i+j]^=mul(g[j],c)
    word=bytes(data)+bytes(work[-50:])
    assert all(evaluate(word,exp[i])==0 for i in range(50))
    return word
state=1; bits=[]; seen=[]
for i in range(255):
    seen.append(state); bits.append((state>>7)&1)
    state=((state<<1)&255)^(0x1d if state&128 else 0)
assert state==1 and len(set(seen))==255
v=[1 if b else -1 for b in bits]
corr=[sum(v[i]*v[(i+k)%255] for i in range(255)) for k in range(255)]
assert corr[0]==255 and set(corr[1:])=={-1}
bits.append(0)
sync=bytes(sum(bits[i+j]<<(7-j) for j in range(8)) for i in range(0,256,8))
header=struct.pack('>BBHI',1,1,len(payload),zlib.crc32(payload))
data=header+payload
words=[encode(data[:134]),encode(data[134:])]
frame=sync+bytes(c for pair in zip(*words) for c in pair)
assert len(frame)==400
(ROOT/'INGOLF_LOHMANN_SIGNATURE_400_V1.bin').write_bytes(frame)
# Fresh readback: deinterleave, all syndromes, header, CRC, decompression, trusted pin.
read=(ROOT/'INGOLF_LOHMANN_SIGNATURE_400_V1.bin').read_bytes()
assert read[:32]==sync
A,B=read[32::2],read[33::2]
assert len(A)==len(B)==184
assert all(evaluate(w,exp[i])==0 for w in (A,B) for i in range(50))
raw=A[:134]+B[:134]
ver,flags,length,crc=struct.unpack('>BBHI',raw[:8])
assert (ver,flags,length)==(1,1,260)
assert zlib.crc32(raw[8:])==crc
reconstructed=zlib.decompress(raw[8:],-15)
assert reconstructed==seed and hashlib.sha256(reconstructed).hexdigest()==PIN
# Verify every single-symbol nonzero corruption is detected, for both words.
checks=0
for w in (A,B):
    for pos in range(184):
        for delta in range(1,256):
            damaged=bytearray(w); damaged[pos]^=delta
            assert evaluate(damaged,exp[0])!=0
            checks+=1

profile=json.loads((ROOT/'profile.json').read_text())
assert profile['repository']=='ingolf-lohmann/qik-vrt' and profile['header_identifier']==1
assert profile['shared_seed_sha256']==PIN

def accept_for_repository(candidate,expected_repository):
    if len(candidate)!=400 or candidate[:32]!=sync: raise ValueError('framing')
    a,b=candidate[32::2],candidate[33::2]
    if any(evaluate(w,exp[i]) for w in (a,b) for i in range(50)): raise ValueError('syndrome')
    r=a[:134]+b[:134]
    version,identifier,size,checksum=struct.unpack('>BBHI',r[:8])
    mapping=profile['identifier_map'].get(str(identifier))
    if version!=1 or mapping is None or mapping['repository']!=expected_repository: raise ValueError('subject mismatch')
    if size!=len(r[8:]) or size!=260 or zlib.crc32(r[8:])!=checksum: raise ValueError('payload integrity')
    recovered=zlib.decompress(r[8:],-15)
    if len(recovered)!=400 or hashlib.sha256(recovered).hexdigest()!=PIN: raise ValueError('seed pin')
    return recovered

gold=(ROOT/'GOLDKELCH_SIGNATURE_400_V1.bin').read_bytes()
assert hashlib.sha256(gold).hexdigest()=='e189368017baf54b2dc17ac777a059ee1ecb209baa59eb7b56c4c1023397fc41'
assert read!=gold
assert accept_for_repository(read,'ingolf-lohmann/qik-vrt')==seed
assert accept_for_repository(gold,'Goldkelch/qik-vrt')==seed
rejected=0
for frame_bytes,wrong_repository in [(read,'Goldkelch/qik-vrt'),(gold,'ingolf-lohmann/qik-vrt')]:
    try: accept_for_repository(frame_bytes,wrong_repository)
    except ValueError as e:
        assert str(e)=='subject mismatch'
        rejected+=1
    else: raise AssertionError('wrong repository accepted')
assert rejected==2

record={
 'name':'INGOLF_LOHMANN_SIGNATURE_400_V1', 'owner':'Ingolf Lohmann',
 'owner_request':'Generiere nun in der gleichen Art und Weise eine Signatur für das Ingolf Lohmann Repository.',
 'date_utc':'2026-10-02', 'meaning':'Owner-designated transport signature; not a cryptographic signature.',
 'bytes':400,'sha256':hashlib.sha256(read).hexdigest(),
 'seed_sha256':PIN,'seed_bytes':400,'payload_bytes':260,
 'sync_hex':sync.hex(), 'header_hex':header.hex(),
 'layout':{'sync_bytes':32,'header_bytes':8,'payload_bytes':260,'parity_bytes':100},
 'header':{'byte_order':'big endian','fields':['version:u8=1','flags:u8=0','payload_length:u16=260','payload_crc32:u32']},
 'compression':{'format':'raw DEFLATE','level':1,'memLevel':1,'strategy':'Z_DEFAULT_STRATEGY','zlib':zlib.ZLIB_RUNTIME_VERSION},
 'ecc':{'field':'GF(256)','primitive_polynomial':'0x11d','generator':2,'first_root':0,'roots':50,'shortened_from':[255,205],'leading_shortening_symbols':71,'codeword':[184,134],'blocks':2,'interleave':'A0 B0 A1 B1 ... A183 B183','theoretical_error_capacity_per_block':25},
 'tests':{'file_readback':True,'all_100_syndromes_zero':True,'crc32':True,'seed_byte_equality':True,'seed_sha256_pin':True,'single_symbol_corruption_detection_cases':checks,'pn255_period':255,'pn255_cyclic_sidelobes':[-1],'wrong_repository_rejection_cases':rejected,'goldkelch_frame_distinct':True,'unknown_error_decoder_tested':False,'physical_channel_tested':False},
 'runtime':{'python':platform.python_version()},
 'effect_scope':'Local generation and readback; existing canonical seed preserved. No repository or Authority activation.',
 'repository':'ingolf-lohmann/qik-vrt','role':'Mirror',
 'profile':json.loads((ROOT/'profile.json').read_text()),
 'mesh_route':{'execution_established':False,'blocker':'Available GitHub connector has no initial workflow dispatch; observed existing executor admits only its read-only watchdog, not this generator.'}
}
(ROOT/'verification.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(ROOT/'INGOLF_LOHMANN_SIGNATURE_400_V1.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for name in ['INGOLF_LOHMANN_SIGNATURE_400_V1.bin','GOLDKELCH_SIGNATURE_400_V1.bin','canonical_seed.bin','profile.json','verification.json','build_verify.py']:
        archive.write(ROOT/name,name)
print(json.dumps({'bytes':400,'sha256':record['sha256'],'checks':checks,'sync':sync.hex(),'header':header.hex(),'roundtrip':True}))
