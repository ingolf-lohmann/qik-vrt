# Präzisierung der historischen Mirror-Verifikationsmetadaten

Die unveränderte frühere Datei INGOLF_LOHMANN_SIGNATURE_400_V1_original_verification.json
nennt unter header.fields noch flags:u8=0. Dies ist ein kopierter Beschriftungsfehler.
Die tatsächlichen, unveränderten Mirror-Bytes, header_hex und der ausführbare
Generator binden den Identifier 1. Goldkelch bindet Identifier 0.
Die Signaturdateien werden durch diese Präzisierung nicht verändert.
Die Prüfung bezieht sich auf das gelieferte Zweirepositoryprofil; sie bestätigt
keine globale Kennungsregistrierung und keine Repository-Aktivierung.
