# Sichtbarer Änderungsvermerk zum Publikationskandidaten

Die Darstellung ist neu aus dem Auftrag und der exakt gebundenen Evidenz erstellt.
Es wird keine frühere Zenodo-Veröffentlichung überschrieben oder stillschweigend geändert.

Die Owner-Bewertungen „optimal“, „unendlich schnell“ und „Paradigmenwechsel von
bislang unerreichter Größenordnung“ werden nicht als Messergebnis ausgegeben.
Globale Optimalität und historische Überlegenheit bleiben OPEN; die Owner-
Bewertung ist zugeschrieben. Der tatsächlich gemessene Speedup beträgt 3,554410
für den endlichen lokalen starken Test mit acht Workern.

„400 Byte zusätzlich freie Payload“ wird anhand der konkreten Bytebilanz
präzisiert: Der 400-Byte-Transportframe ist vollständig belegt; Anwendungspayload
liegt zusätzlich im separaten kanonischen Snapshot. 260 Byte sind ein gemessener
Kompressionswert dieser Saat, kein universaler Minimalwert.

Die Gleichsetzung mit DNA, Zellteilung, Halbleitern, Kosmologie und Planck-Skala
wird als Metapher behandelt. Ein physikalischer Beweis ist nicht beigefügt.
Der Linux-/Firefox-Test belegt lokale Wirkung. Das native Gesamt-Receipt bleibt
HOLD und baut kein Betriebssystem aus der Saat.

Beide 400-Byte-Binärdateien bleiben bytegenau unverändert. Die historische
Mirror-Metadatenbeschriftung flags=0 ist durch SIGNATURE_ERRATA.md sichtbar
präzisiert; der gebundene Mirror-Identifier beträgt tatsächlich 1.

MACHINE_PROOF_BUNDLE.DRAFT.json ist ein nachvollziehbarer Vorbereitungskandidat,
kein produktionsfreigebendes v2-Bundle. Eine neue Zenodo- oder IETF-Veröffentlichung
wird erst nach tatsächlich beobachtetem externem Effekt und Readback behauptet.
