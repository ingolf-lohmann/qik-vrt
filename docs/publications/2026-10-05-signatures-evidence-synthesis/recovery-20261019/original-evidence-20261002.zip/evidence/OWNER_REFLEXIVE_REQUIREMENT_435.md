<!-- qikvrt-reflexive-api-return:required pr=435 head=3cfe025d0e85caba2ddcefdf2c131977bfe4f89c -->

**Owner clarification: the API is reflexive.** Its result must return both to the initiator and into the repository as a causally bound, freshly admitted input. The internal return must carry the same effect semantics as the external path. Reply delivery and result persistence alone are insufficient; the actual internal evaluation/effect and post-effect readback are required.

The existing #435 receipt has been returned and written/read back on this PR. Source inspection finds local dual result/audit persistence in `run_handler`, but `op_ingest` deliberately stores opaque bytes and does not execute their content. A productive authenticated API-result → repository-input → evaluation → admitted effect → readback path is therefore **OPEN**, not silently declared complete. Internal return uses the existing effect boundaries, including effective BLOCK/CONTINUE/ISOLATE/NACK, fresh admission, idempotency and independent authority; the result cannot approve or release itself. No second executor or predecessor review/gate transfer is introduced.

This records the binding acceptance requirement and implementation gap on consolidated #435. It performs no merge, automatic feedback dispatch or product effect and claims no EFFECT_ACK_DONE.

```json
{
  "schema": "qikvrt_reflexive_api_return_acceptance_requirement_v1",
  "declared_by": "Ingolf Lohmann, Product Owner",
  "recorded_utc": "2026-10-01T16:42:04.147Z",
  "subject": {
    "repository": "ingolf-lohmann/qik-vrt",
    "pr": 435,
    "head": "3cfe025d0e85caba2ddcefdf2c131977bfe4f89c",
    "tree": "79e5a174eb4d923b5813c95bd52a46f0dff88bff",
    "base": "469a95ac4ef14692dda69673b8a75eb2cf03685d"
  },
  "normative_status": "REQUIRED",
  "owner_requirement": "An API result derived from its inputs returns to the initiator and returns into the repository itself, where it must produce the same effect semantics as outside. A reply or a stored result alone does not fulfil this reflexive requirement.",
  "required_path": [
    "BOUND_API_INPUT",
    "API_EVALUATION",
    "BOUND_API_RESULT",
    "RETURN_TO_INITIATOR",
    "AUTHENTICATED_REPOSITORY_REENTRY_OF_THE_SAME_RESULT",
    "FRESH_NORMAL_INPUT_EVALUATION",
    "ADMITTED_REPOSITORY_EFFECT",
    "POST_EFFECT_READBACK",
    "RETURN_OF_THE_VERIFIED_OUTCOME"
  ],
  "acceptance": {
    "both_destinations_required": true,
    "same_result_content_and_causal_origin_binding_required": true,
    "same_effect_semantics_for_equivalent_bound_inputs_policy_state_and_capability": true,
    "internal_persistence_alone_sufficient": false,
    "internal_reentry_bypasses_effect_gate": false,
    "result_is_self_approval": false,
    "internal_and_external_effect_readbacks_required": true,
    "block_continue_isolate_nack_remain_effective_on_reentry": true,
    "predecessor_evidence_transfer": false,
    "fresh_subject_and_authority_observation_required": true,
    "replay_must_not_duplicate_effect": true,
    "reentry_steps_bounded_and_causally_linked": true,
    "no_second_executor": true
  },
  "current_evidence": {
    "product_admission_receipt": "https://github.com/ingolf-lohmann/qik-vrt/pull/435#issuecomment-5935884226",
    "receipt_return_and_repository_comment_readback_verified": true,
    "code_inspection": [
      {
        "path": "src/qikvrt_api_handler.py",
        "functions": [
          "run_handler",
          "op_ingest"
        ],
        "finding": "run_handler writes audit/last_result.json and persists the protocol before returning the result. op_ingest explicitly releases only opaque byte storage; it does not execute or semantically release its content."
      },
      {
        "path": "src/qikvrt_github_api_shim.py",
        "functions": [
          "QikvrtGitHubApiShim.do_POST"
        ],
        "finding": "The HTTP adapter derives its response from run_handler and the returned effect_state."
      },
      {
        "path": "tools/qikvrt_pr_closure_engine.py",
        "functions": [
          "execute",
          "recover"
        ],
        "finding": "The controller returns a bounded receipt; its successful effect journal is host-local. This inspection does not establish automatic authenticated semantic reentry of a returned API result into the productive repository executor."
      }
    ],
    "productive_authenticated_reflexive_reentry": "OPEN_NOT_VERIFIED",
    "same_external_and_internal_effect_end_to_end": "OPEN_NOT_VERIFIED",
    "effect_ack_done": false,
    "scope": "Exact #435 source inspection and actual receipt persistence/readback, not an executed live API self-feedback effect."
  },
  "implementation_obligation": {
    "reuse": [
      "src/qikvrt_api_handler.py",
      "src/qikvrt_effect_ack.py",
      "tools/qikvrt_pr_closure_engine.py"
    ],
    "next_missing_edge": "Bind a returned result to an actual authenticated repository-input admission in the existing executor and verify the resulting admitted effect. Persisting a comment or opaquely storing a payload cannot substitute for that edge.",
    "source_receipt_authorizes_execution": false,
    "current_native_protection_review_authority_and_subject_fences_preserved": true,
    "product_completion_requires_actual_post_effect_readback": true
  },
  "contribution_provenance": {
    "human": "Ingolf Lohmann supplied the reflexive dual-return/effect requirement.",
    "artificial_cognitive_system": "OpenAI Codex inspected the existing source and recorded the acceptance obligation and its unverified execution edge; no independent approval or implemented live reentry is inferred."
  }
}
```
