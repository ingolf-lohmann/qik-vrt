#!/usr/bin/env python3
"""Verify the frozen archive files. This detects changed bytes, not trusted origin."""
import hashlib
import json
from pathlib import Path

root=Path(__file__).parent.resolve()
manifest=json.loads((root/'MANIFEST.json').read_text())
bad=[]
for item in manifest['files']:
    path=root/item['path']
    if not path.is_file():
        bad.append({'path':item['path'],'error':'missing'})
        continue
    b=path.read_bytes()
    if len(b)!=item['bytes'] or hashlib.sha256(b).hexdigest()!=item['sha256']:
        bad.append({'path':item['path'],'error':'changed'})
print(json.dumps({'verified_files':len(manifest['files']),'findings':bad},ensure_ascii=False,indent=2))
raise SystemExit(bool(bad))
