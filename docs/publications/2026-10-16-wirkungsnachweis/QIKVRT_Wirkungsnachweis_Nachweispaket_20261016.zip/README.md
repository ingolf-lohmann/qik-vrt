# QIK-VRT: Der entscheidende Unterschied

Forschungs- und Autorenprüfpaket vom 16. Oktober 2026.

## Lesen

Unter output/ liegen die wissenschaftliche Erläuterung (13 Seiten) und die
allgemein verständliche Prosa (7 Seiten), jeweils als PDF, Markdown und Klartext.
Die Inhaltsquellen [1]-[3] sind bestehende veröffentlichte Zenodo-Werke von Ingolf
Lohmann. Die neue Arbeit hat noch keinen bestätigten eigenen Zenodo-Record.

Die dauerhaft gespeicherten PDFs wurden automatisch um C2PA-Herkunftsmetadaten
ergänzt. Die direkt zurückgegebenen Fassungen unter output/ sind exakt an diese
gespeicherten Bytes gebunden. Unter authored-originals/ bleiben die erzeugten
Original-PDFs erhalten. Für sämtliche Seiten wurde Gleichheit der gerenderten
Pixel sowie des extrahierbaren Texts und der Linkziele geprüft; die Hüllenbytes
unterscheiden sich. evidence/PERSISTENCE_VARIANTS.json dokumentiert beide
Identitäten. Die C2PA-Ergänzung ist kein zusätzlicher mathematischer Nachweis.

## Nachgewiesener Umfang

Drei genau gebundene Theoremkonstanten sind mit Lean 4.19.0 kernelgeprüft.
Eine absichtlich falsche negative Kontrolle wird abgelehnt. Eine vollständige
endliche Enumeration mit 64 und 1296 Funktionspaaren sowie 13 reale lokale
SQLite-Szenarien sind ausgeführt. Zwölf gestörte Fälle haben nach gezielter
Änderung der Voraussetzungen je einen akzeptierten Nachfolger.

Die gleich informierte konventionelle Kontrolle erzielt dieselben Entscheidungen
wie der QIK-VRT-Prinzipdemonstrator. Dieser Demonstrator ist keine Ausführung
des nativen QIK-VRT-Gesamtprodukts. Ein allumfassender Vorteil gegenüber jeder
anderen Technik und eine globale EFFECT_ACK_DONE-Abnahme werden nicht behauptet.

## Reproduzieren

Für den lokalen Versuch genügt Python 3 mit Standardbibliothek:

    python3 experiment.py --output replica-evidence

Erwartet sind die Fallzahlen in evidence/PROOF_REPORT.json, zwölf akzeptierte
Nachfolger, die 64/1296 endlichen Vergleiche und drei erfolgreiche
Grenzgegenbeispiele. Die neuen Zeitstempel und Berichtbytes dürfen abweichen.

Für die formale Prüfung: die in PROVENANCE.json bezeichnete offizielle
Lean-4.19.0-Distribution verwenden und ihren angegebenen SHA-256-Wert prüfen.
Die vorliegende offizielle Distributionsdatei wurde von der Herausgeberquelle
bezogen und lokal gehasht; ein separat signierter Herausgeberdigest lag nicht vor.
Die Toolchain selbst wird in diesem kleinen Begleitpaket nicht mitverteilt.

Auf einem üblichen Linux-Host reicht im entpackten Paket:

    lean -DwarningAsError=true -o replica-Proof.olean Proof.lean
    lean -DwarningAsError=true evidence/NegativeControl.lean

Der erste Aufruf soll erfolgreich sein; der zweite muss den falschen Beweis
zurückweisen. Die drei ausgegebenen Axiom-Audits stehen im Originalprotokoll.
Das neue kompilierte Artefakt muss wegen möglicher Pfad- und Metadatenbindung
nicht dieselben Bytes haben; maßgeblich sind dieselben Quellen und Theoreme.

Diese Arbeitsumgebung verweigert die numerische /proc/<eigene-pid>/exe-Abfrage,
erlaubt jedoch /proc/self/exe. Der beigefügte Adapter übersetzt ausschließlich
die eigene Abfrage. Wer genau diesen Lauf reproduzieren will, legt die offizielle
Distribution und das entpackte Verzeichnis unter tmp/ ab, kompiliert den Adapter
und führt danach check_formal.py aus:

    cc -shared -fPIC -O2 lean_self_path_adapter.c -ldl -o evidence/lean_self_path_adapter.so
    python3 check_formal.py

Weder Compilerdatei noch Beweisregeln werden dadurch geändert. Der ursprüngliche
Startfehler bleibt in evidence/LEAN_INITIAL_STARTUP_FAILURE.json erhalten.

Die Dokumente sind aus den finalen Markdown-Dateien mit render_documents.py
erzeugt. Zum Neurendern werden ReportLab und die im Skript genannten installierten
DejaVu-Schriften benötigt. Die Quellenanzeigenprüfung lässt sich am Paketstamm
mit tools/check_sources.py --manifest evidence/SOURCES.json und den jeweiligen
--artifact-Pfaden ausführen. Dieser Anzeigencheck prüft sichtbare Fundstellen
und Links; Quelleninhalt und wissenschaftliche Geltung sind getrennt beurteilt.

## Integrität

    python3 verify_package.py

MANIFEST.json bindet alle Dateien außer sich selbst durch Größe, SHA-256 und
berechnete Git-Blob-Identität. Letztere bedeutet nicht, dass ein Blob tatsächlich
in einem Repository gespeichert oder in Main integriert wurde. Der äußere
Archivhash wird außerhalb des Archivs dokumentiert; so entsteht keine zirkuläre
Selbsthashbehauptung. Hashgleichheit beweist Bytegleichheit unter der angegebenen
Hashannahme, nicht die vertrauenswürdige Herkunft des gesamten Archivs.

## Herkunft, Grenzen und nächster Publikationsschritt

Der Ausgangsgedanke und die QIK-VRT-Quellen stammen von Ingolf Lohmann.
Ausarbeitung, ergänzende Formalisierung, Versuchsprogramm und Durchführung
stammen von OpenAI Codex in seinem Auftrag. Eine unabhängige wissenschaftliche
Replikation oder Begutachtung durch Dritte wird nicht behauptet.

Die übernommenen Originalquelldateien und ihre vorhandenen Rechtehinweise bleiben
unverändert. Eine zusätzliche kommerzielle Nutzungslizenz wird nicht zugesagt.
Die vollständigen MIT-Quelltexte werden nicht erneut verteilt; erhalten bleiben
Fundstellen und Abrufhashes.

CLAIM_MATRIX.json trennt bewiesene, lokal evidenzierte, interpretative, normative
und offene Aussagen. CANDIDATE_BINDING.json bezeichnet die exakten zurückzugebenden
Manuskriptbytes. Es ist keine nachgewiesene Kandidatenfreigabe zum Upload.
Die konservierten öffentlichen V2-Schemata sind für den späteren Publikationsweg
beigefügt. Ein Produktionsmanifest mit zenodo_upload_authorized=true wird ohne
entsprechende kandidatenspezifische Freigabe nicht erzeugt. Der gespeicherte
öffentliche Domain-Readback bleibt ein operativer Befund mit eigenem Zeitpunkt.
Öffentliche Auslieferung, alle Repository-Nodes und neue Zenodo-Archivierung
werden nicht aus der lokalen Studie abgeleitet.
