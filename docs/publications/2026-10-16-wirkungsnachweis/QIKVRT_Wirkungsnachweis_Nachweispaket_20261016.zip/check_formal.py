#!/usr/bin/env python3
"""Run the exact Lean source and a deliberately invalid negative control."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess

root = Path(__file__).parent.resolve()
out = root / 'evidence'
out.mkdir(exist_ok=True)
exe = root / 'tmp/lean-4.19.0-linux/bin/lean'
env = dict(os.environ)
env['LD_PRELOAD'] = str(out / 'lean_self_path_adapter.so')

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def run(args):
    return subprocess.run([str(exe), *args], env=env, capture_output=True, text=True, cwd=root)

old = out/'LEAN_KERNEL_RECEIPT.json'
if old.exists() and not (out/'LEAN_INITIAL_STARTUP_FAILURE.json').exists():
    (out/'LEAN_INITIAL_STARTUP_FAILURE.json').write_bytes(old.read_bytes())
version = run(['--version'])
p = run(['-DwarningAsError=true', '-o', str(out/'Proof.olean'), str(root/'Proof.lean')])
(out/'lean-stdout.txt').write_text(p.stdout)
(out/'lean-stderr.txt').write_text(p.stderr)
bad = out/'NegativeControl.lean'
bad.write_text('example : False := by\n  exact True.intro\n')
n = run(['-DwarningAsError=true', str(bad)])
(out/'lean-negative-control.txt').write_text(n.stdout+n.stderr)
no_placeholders = not re.findall(r'\b(?:sorry|admit|axiom)\b', (root/'Proof.lean').read_text())
receipt = {
    'schema':'qikvrt-local-lean-kernel-receipt/v1',
    'verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'lean_version':version.stdout.strip(), 'exit_code':p.returncode,
    'stdout':p.stdout, 'stderr':p.stderr, 'source_sha256':sha(root/'Proof.lean'),
    'compiler_sha256':sha(exe),
    'official_distribution_sha256':sha(root/'tmp/lean-4.19.0-linux.tar.zst'),
    'official_distribution_url':'https://github.com/leanprover/lean4/releases/download/v4.19.0/lean-4.19.0-linux.tar.zst',
    'publisher_asset_digest_available':False,
    'path_compatibility_adapter':{
        'source_sha256':sha(root/'lean_self_path_adapter.c'),
        'binary_sha256':sha(out/'lean_self_path_adapter.so'),
        'scope':'Only numeric own-pid executable lookup is mapped to permitted /proc/self/exe; no proof rule changed.'},
    'theorem_constants':[
        'QIKVRTComparison.factorization_iff_fiber_constant',
        'QIKVRTComparison.indistinguishable_outcomes_no_perfect_classifier',
        'QIKVRTComparison.mediated_acceptance_implies_goal'],
    'no_unproved_placeholders':no_placeholders,
    'negative_control_rejected':n.returncode != 0, 'negative_control_exit_code':n.returncode,
    'negative_control_output':n.stdout+n.stderr,
    'native_mesh_execution':False,
    'scope':'Three source-bound mathematical implications; no proof of sensor soundness or product completion.'
}
if (out/'Proof.olean').exists(): receipt['olean_sha256'] = sha(out/'Proof.olean')
receipt['status'] = 'KERNEL_CHECKED' if p.returncode == 0 and no_placeholders and n.returncode != 0 else 'FAILED'
old.write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(receipt, ensure_ascii=False, indent=2))
