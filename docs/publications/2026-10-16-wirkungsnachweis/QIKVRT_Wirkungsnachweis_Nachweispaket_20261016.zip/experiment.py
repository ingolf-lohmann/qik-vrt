#!/usr/bin/env python3
"""Bounded, reproducible research demonstration; not the QIK-VRT runtime.

Only the Python standard library is required. The producer, observer and raw
state oracle each run in a fresh subprocess, on the same machine and account.
No network, native Mesh executor, power-loss durability or distributed-trust
property is asserted. Run: python3 experiment.py --output evidence
"""
import argparse
import base64
import hashlib
import itertools
import json
import os
import platform
import sqlite3
import subprocess
import sys
import tempfile
import time
from pathlib import Path

PAYLOAD = b"QIK-VRT: Zweck, Handlung, nachgelesene Wirkung.\n"
IDENTITY = ("origin", "target", "version", "run_id", "nonce")


def digest(b):
    return hashlib.sha256(b).hexdigest()


def canonical(x):
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def expected():
    return dict(origin="local://authority", target="publication/demo", version=7,
                run_id="trial-current", nonce="challenge-current",
                payload_sha256=digest(PAYLOAD))


def old_spec():
    return dict(expected(), version=6, run_id="trial-predecessor", nonce="old-challenge")


def save(conn, spec, payload, written_ns):
    conn.execute("INSERT OR REPLACE INTO records VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                 tuple(spec[k] for k in IDENTITY) +
                 (payload, digest(payload), written_ns))
    conn.commit()


def record(conn, origin, target):
    row = conn.execute("SELECT origin,target,version,run_id,nonce,payload,stored_sha256,written_ns "
                       "FROM records WHERE origin=? AND target=?", (origin, target)).fetchone()
    if row is None:
        return None
    result = dict(zip(IDENTITY, row[:5]))
    result.update(payload_b64=base64.b64encode(row[5]).decode(),
                  stored_sha256=row[6], written_ns=row[7])
    return result


def worker(request):
    """Three separately invoked modes; the oracle never calls a policy gate."""
    with sqlite3.connect(request["db"]) as conn:
        mode = request["operation"]
        if mode == "write":
            spec = dict(request["spec"])
            payload = PAYLOAD
            fault = request["fault"]
            if fault == "rollback":
                conn.execute("BEGIN")
                conn.execute("DELETE FROM records")
                conn.rollback()
            else:
                if fault == "wrong_payload":
                    payload = b"Different bytes.\n"
                if fault == "wrong_target":
                    spec["target"] = "publication/other"
                if fault == "wrong_origin":
                    spec["origin"] = "local://other"
                if fault == "wrong_version":
                    spec["version"] -= 1
                if fault == "wrong_run":
                    spec["run_id"] = "trial-other"
                if fault == "wrong_nonce":
                    spec["nonce"] = "replayed-challenge"
                save(conn, spec, payload, time.time_ns())
                if fault == "corruption":
                    conn.execute("UPDATE records SET payload=? WHERE origin=? AND target=?",
                                 (b"Corrupted after write.\n", spec["origin"], spec["target"]))
                    conn.commit()
            return {"transport_ack": fault != "ack_lost"}
        if mode == "observe":
            s = request["spec"]
            r = record(conn, s["origin"], s["target"])
            return {"schema": "local-effect-readback/v1", "read_origin": s["origin"],
                    "read_target": s["target"], "observed_ns": time.time_ns(), "record": r}
        if mode == "oracle":
            # Direct query against committed storage, independent of observer JSON
            # and independent of the two implementations of the full verifier.
            s = request["spec"]
            row = conn.execute("SELECT payload FROM records WHERE origin=? AND target=? "
                               "AND version=? AND run_id=? AND nonce=?",
                               tuple(s[k] for k in IDENTITY)).fetchone()
            return {"goal_holds": row is not None and row[0] == PAYLOAD}
        if mode == "release_fixture":
            conn.execute("CREATE TABLE IF NOT EXISTS release_log(event TEXT)")
            if request["gate_done"] or not request["mediated"]:
                conn.execute("INSERT INTO release_log VALUES ('ordinary-effect-fixture')")
                conn.commit()
            return {"transport_ack": True}
        if mode == "release_oracle":
            row = conn.execute("SELECT count(*) FROM release_log").fetchone()
            return {"release_count": row[0]}
    raise ValueError(request["operation"])


def invoke(db, operation, **kwargs):
    p = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--worker"],
                       input=canonical(dict(db=str(db), operation=operation, **kwargs)),
                       capture_output=True, text=True, check=True)
    return json.loads(p.stdout)


def qik_principle(spec, ack, observation, authority, start_ns, now_ns):
    """Small principle demonstrator, not full EFFECT_ACK wire conformance."""
    errors = []
    if not ack:
        errors.append("TRANSPORT_ACK_MISSING")
    if not authority:
        errors.append("AUTHORITY_NOT_GRANTED")
    if not isinstance(observation, dict):
        return {"done": False, "reasons": errors + ["OBSERVATION_MISSING"]}
    if observation.get("schema") != "local-effect-readback/v1":
        errors.append("SCHEMA")
    if (observation.get("read_origin"), observation.get("read_target")) != (spec["origin"], spec["target"]):
        errors.append("READ_ENDPOINT_BINDING")
    if not start_ns <= observation.get("observed_ns", 0) <= now_ns:
        errors.append("OBSERVATION_ORDER")
    if now_ns - observation.get("observed_ns", 0) > 2_000_000_000:
        errors.append("OBSERVATION_AGE")
    r = observation.get("record")
    if not isinstance(r, dict):
        return {"done": False, "reasons": errors + ["RECORD_MISSING"]}
    for key in IDENTITY:
        if r.get(key) != spec[key]:
            errors.append("IDENTITY_" + key.upper())
    if not start_ns <= r.get("written_ns", 0) <= observation.get("observed_ns", 0):
        errors.append("WRITE_ORDER")
    try:
        payload = base64.b64decode(r["payload_b64"], validate=True)
        if digest(payload) != r["stored_sha256"]:
            errors.append("INTEGRITY")
        if digest(payload) != spec["payload_sha256"]:
            errors.append("GOAL_BYTES")
    except (KeyError, ValueError, TypeError):
        errors.append("PAYLOAD_PARSE")
    return {"done": not errors, "reasons": errors}


def conventional_control(spec, ack, obs, authority, start_ns, now_ns):
    """Separately structured conventional end-to-end verifier, same evidence.

    This control calls no QIK-VRT implementation and is not a third-party
    product benchmark. It shares an author, machine, evidence contract and
    test harness with the demonstrator.
    """
    try:
        r = obs["record"]
        if ack is not True or authority is not True:
            return False
        if obs["schema"] != "local-effect-readback/v1":
            return False
        if tuple(r[k] for k in IDENTITY) != tuple(spec[k] for k in IDENTITY):
            return False
        if (obs["read_origin"], obs["read_target"]) != (spec["origin"], spec["target"]):
            return False
        if not start_ns <= r["written_ns"] <= obs["observed_ns"] <= now_ns:
            return False
        if now_ns - obs["observed_ns"] > 2_000_000_000:
            return False
        h = hashlib.sha256(base64.b64decode(r["payload_b64"], validate=True)).hexdigest()
        return h == spec["payload_sha256"] and h == r["stored_sha256"]
    except (KeyError, ValueError, TypeError):
        return False


def payload_only(obs):
    try:
        return base64.b64decode(obs["record"]["payload_b64"], validate=True) == PAYLOAD
    except (KeyError, ValueError, TypeError):
        return False


CASES = [
    ("nominal", "success", "live", True),
    ("ack_lost", "ack_lost", "live", True),
    ("rollback", "rollback", "live", True),
    ("wrong_payload", "wrong_payload", "live", True),
    ("wrong_target", "wrong_target", "live", True),
    ("wrong_origin", "wrong_origin", "live", True),
    ("wrong_version", "wrong_version", "live", True),
    ("wrong_run", "wrong_run", "live", True),
    ("wrong_nonce", "wrong_nonce", "live", True),
    ("corruption", "corruption", "live", True),
    ("observer_missing", "success", "missing", True),
    ("observer_stale", "success", "stale", True),
    ("authority_denied", "success", "live", False),
]


def trial(db, name, fault, observation_mode, authority):
    with sqlite3.connect(db) as conn:
        conn.execute("CREATE TABLE records(origin TEXT,target TEXT,version INTEGER,run_id TEXT,"
                     "nonce TEXT,payload BLOB,stored_sha256 TEXT,written_ns INTEGER,"
                     "PRIMARY KEY(origin,target))")
        # A matching payload from a predecessor cannot certify the current run.
        save(conn, old_spec(), PAYLOAD, time.time_ns() - 10_000_000_000)
    s = expected()
    old = invoke(db, "observe", spec=s)
    start_ns = time.time_ns()
    ack = invoke(db, "write", spec=s, fault=fault)["transport_ack"]
    obs = None if observation_mode == "missing" else (
        old if observation_mode == "stale" else invoke(db, "observe", spec=s))
    now_ns = time.time_ns()
    verified = qik_principle(s, ack, obs, authority, start_ns, now_ns)
    control = conventional_control(s, ack, obs, authority, start_ns, now_ns)
    truth = invoke(db, "oracle", spec=s)["goal_holds"]
    return {"case": name, "fault": fault, "observation_mode": observation_mode,
            "spec": s, "authority": authority, "start_ns": start_ns,
            "decision_ns": now_ns, "observation": obs, "goal_holds": truth,
            "policies": {"ack_only": ack, "payload_only": payload_only(obs),
                         "qik_principle": verified["done"], "conventional_e2e": control},
            "qik_reasons": verified["reasons"]}


def factorization(n, m):
    functions = list(itertools.product(range(m), repeat=n))
    semantics = list(itertools.product(range(2), repeat=n))
    decoders = list(itertools.product(range(2), repeat=m))
    counts = {"pairs": 0, "factorizable": 0, "not_factorizable": 0, "disagreements": 0}
    witness = None
    for e in functions:
        for p in semantics:
            on_fibers = all(e[i] != e[j] or p[i] == p[j] for i in range(n) for j in range(n))
            decoder_exists = any(all(h[e[i]] == p[i] for i in range(n)) for h in decoders)
            counts["pairs"] += 1
            counts["factorizable" if decoder_exists else "not_factorizable"] += 1
            counts["disagreements"] += on_fibers != decoder_exists
            if not decoder_exists and witness is None:
                witness = {"observation": e, "semantic_property": p}
    return dict(states=n, observation_values=m, **counts, counterexample=witness)


def run(output):
    output.mkdir(parents=True, exist_ok=True)
    rows = []
    repairs = []
    with tempfile.TemporaryDirectory(prefix="qik-proof-") as td:
        for idx, case in enumerate(CASES):
            current_db = Path(td) / f"case-{idx}.db"
            rows.append(trial(current_db, *case))
            if case[0] != "nominal":
                # A successor has a new identity. Fault injection is explicitly
                # removed, read access restored, and fixture authority granted.
                # These are changed causal premises, not an unchanged retry.
                successor = dict(expected(), version=8, run_id="trial-repaired",
                                 nonce="challenge-repaired")
                started = time.time_ns()
                a = invoke(current_db, "write", spec=successor, fault="success")
                o = invoke(current_db, "observe", spec=successor)
                v = qik_principle(successor, a["transport_ack"], o, True, started, time.time_ns())
                g = invoke(current_db, "oracle", spec=successor)["goal_holds"]
                repairs.append({"predecessor": case[0], "successor_spec": successor,
                                "goal_holds": g, "local_accept": v["done"],
                                "observation": o,
                                "changed_premises": "Fault removed, fresh successor write/read, fixture authority granted."})
        # Explicit tests that violate the observer trust or temporal assumptions.
        db = Path(td) / "boundary.db"
        b = trial(db, "forged_observer", "rollback", "live", True)
        fake = {"schema": "local-effect-readback/v1", "read_origin": expected()["origin"],
                "read_target": expected()["target"], "observed_ns": time.time_ns(),
                "record": dict(expected(), payload_b64=base64.b64encode(PAYLOAD).decode(),
                               stored_sha256=digest(PAYLOAD), written_ns=time.time_ns() - 1)}
        fake["observed_ns"] = time.time_ns()
        forged = qik_principle(expected(), True, fake, True, b["start_ns"], time.time_ns())["done"]
        forged_control = conventional_control(expected(), True, fake, True, b["start_ns"], time.time_ns())
        # The observation and gate accept t1. An adversarial update precedes the
        # final check of t2. This demonstrates absence of a future-state guarantee.
        race_db = Path(td) / "race.db"
        race = trial(race_db, "race_after_observation", "success", "live", True)
        with sqlite3.connect(race_db) as conn:
            conn.execute("UPDATE records SET payload=?", (b"changed after observation",))
            conn.commit()
        race_goal = invoke(race_db, "oracle", spec=expected())["goal_holds"]
        invoke(race_db, "release_fixture", gate_done=False, mediated=False)
        bypass_count = invoke(race_db, "release_oracle")["release_count"]
        boundary = [
            {"case": "forged_observer", "gate_done": forged,
             "conventional_done": forged_control, "goal_holds": b["goal_holds"],
             "expected_counterexample": forged and not b["goal_holds"],
             "violated_premise": "Observer report is not a sound account of storage."},
            {"case": "race_after_observation", "gate_done_at_observation": race["policies"]["qik_principle"],
             "goal_holds_later": race_goal,
             "expected_counterexample": race["policies"]["qik_principle"] and not race_goal,
             "violated_premise": "Observed state is not guaranteed unchanged at later use."},
            {"case": "unmediated_release", "gate_done": False,
             "release_via_bypass": bypass_count > 0, "release_log_count": bypass_count,
             "expected_counterexample": bypass_count == 1,
             "violated_premise": "Ordinary effect paths are not completely mediated."},
        ]
    summary = {}
    for policy in rows[0]["policies"]:
        summary[policy] = {
            "done": sum(r["policies"][policy] for r in rows),
            "true_done": sum(r["policies"][policy] and r["goal_holds"] for r in rows),
            "false_done": sum(r["policies"][policy] and not r["goal_holds"] for r in rows),
            "holds_despite_goal": sum(not r["policies"][policy] and r["goal_holds"] for r in rows),
            "holds_when_goal_absent": sum(not r["policies"][policy] and not r["goal_holds"] for r in rows),
        }
    finite = [factorization(3, 2), factorization(4, 3)]
    assert all(x["disagreements"] == 0 for x in finite)
    assert finite[0]["factorizable"] == 28 and finite[0]["not_factorizable"] == 36
    assert summary["qik_principle"]["false_done"] == 0
    assert summary["qik_principle"] == summary["conventional_e2e"]
    assert all(r["policies"]["qik_principle"] == r["policies"]["conventional_e2e"] for r in rows)
    assert all(b["expected_counterexample"] for b in boundary)
    assert len(repairs) == 12 and all(r["goal_holds"] and r["local_accept"] for r in repairs)
    report = {
        "schema": "qikvrt-bounded-comparison-research/v1",
        "completed_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "implementation_status": "PRINCIPLE_DEMONSTRATOR_NOT_NATIVE_QIKVRT_RUNTIME",
        "python": sys.version, "platform": platform.platform(), "sqlite": sqlite3.sqlite_version,
        "script_sha256": digest(Path(__file__).read_bytes()),
        "scenario_count": len(rows), "goal_true_cases": sum(r["goal_holds"] for r in rows),
        "goal_false_cases": sum(not r["goal_holds"] for r in rows),
        "policy_summary": summary, "finite_factorization": finite,
        "cases": rows, "boundary_counterexamples": boundary,
        "repairs": repairs, "repair_count": len(repairs),
        "repair_accept_count": sum(r["goal_holds"] and r["local_accept"] for r in repairs),
        "scope": "Deterministic finite models and same-host subprocess SQLite experiments, no population inference.",
        "independence": "Separate processes and separate control implementation; same author, machine and account.",
        "kernel_proof_executed_by_this_script": False, "native_mesh_execution": False,
        "universal_superiority_proved": False,
    }
    (output / "PROOF_REPORT.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({k: report[k] for k in ["completed_at_utc", "script_sha256", "scenario_count",
                     "goal_true_cases", "goal_false_cases", "policy_summary", "finite_factorization"]}, indent=2))


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--worker", action="store_true")
    p.add_argument("--output", default="evidence")
    a = p.parse_args()
    if a.worker:
        print(canonical(worker(json.load(sys.stdin))))
    else:
        run(Path(a.output))
