# Wann Technik wirklich geholfen hat
## Der entscheidende Unterschied zwischen einer Erfolgsmeldung und einer erreichten Wirkung

Ausgangspunkt: Ingolf Lohmann. Erläuternde Prosafassung: OpenAI Codex im Auftrag von Ingolf Lohmann. 16. Oktober 2026. Autorenprüffassung mit zugehöriger wissenschaftlicher Erläuterung und reproduzierbarem Begleitversuch.

Stell dir vor, du möchtest ein wichtiges Dokument veröffentlichen. Du gibst den Auftrag, ein Programm arbeitet, ein grünes Feld erscheint. „Erfolgreich“, steht dort. Du schickst jemandem den Link. Der Mensch öffnet ihn und findet nichts.

Was war erfolgreich? Vielleicht wurde der Auftrag entgegengenommen. Vielleicht wurde eine Datei erzeugt. Vielleicht lag sie sogar einen Augenblick lang an einer anderen Stelle. Für den Menschen, der sie unter der vereinbarten Adresse lesen sollte, ist der Auftrag trotzdem nicht erfüllt. Zwischen dem, was ein System über seine Tätigkeit meldet, und dem, was beim Menschen ankommt, kann eine entscheidende Lücke liegen.

Ingolf Lohmann stellt mit QIK-VRT genau diesen Unterschied ins Zentrum: Technik soll an ihrer Anwendung zeigen, welche hilfreiche Wirkung sie tatsächlich erreicht. Und der Vergleich soll zugleich sichtbar machen, was passiert, wenn diese Verbindung zwischen Absicht und überprüfter Wirkung fehlt. Der Gedanke steht in seinem größeren Erkenntnisweg, dem „Universum als Round Trip“: von einer beobachteten Wirklichkeit zu einer Erklärung und von der Erklärung wieder zurück zur überprüfbaren Wirklichkeit [1].

Das Wort Round Trip bedeutet Hin- und Rückweg. Im Alltag braucht es dafür keine schwierige Theorie. Du möchtest etwas erreichen, handelst, schaust auf das Ergebnis und vergleichst es mit deinem Vorhaben. Wenn das Ergebnis nicht stimmt, ist eine weitere Handlung nötig. Wenn es stimmt und ausreichend geprüft ist, darf die Aufgabe als abgeschlossen gelten. Der Rückweg bringt die tatsächliche Wirkung zum ursprünglichen Zweck zurück.

Eine solche Rückmeldung ist mehr als ein freundlicher Zusatz. Manchmal enthält sie die Information, ohne die Erfolg und Misserfolg überhaupt nicht zu unterscheiden sind. Ein ganz einfaches Gedankenexperiment zeigt das. In der ersten Situation wird dein Dokument richtig veröffentlicht. In der zweiten wird die Veröffentlichung zwar angenommen, danach aber verworfen. Beide Male leuchtet dasselbe grüne Feld. Wer nur dieses Feld sehen kann, bekommt beide Male genau dieselbe Information.

Kein noch so kluges Programm kann aus genau dieser einen unveränderten Meldung wissen, welche der beiden Situationen eingetreten ist. Nennt es beide erfolgreich, liegt es einmal falsch. Nennt es beide gescheitert, liegt es ebenfalls einmal falsch. Es kann ehrlich sagen: „Mit dieser Information weiß ich es noch nicht.“ Damit vermeidet es eine falsche Behauptung. Die fehlende Unterscheidung hat es aber noch nicht gewonnen.

Das ist der mathematische Kern des hier geführten Beweises. Wer einen Unterschied zuverlässig erkennen soll, braucht einen Befund, in dem dieser Unterschied tatsächlich vorkommt. Die ausführliche Erläuterung beweist das in beide Richtungen. Sind alle Zustände mit demselben Befund in der entscheidenden Eigenschaft gleich, kann die Eigenschaft aus dem Befund bestimmt werden. Gibt es darunter sowohl Erfolg als auch Misserfolg, reicht der Befund nicht. Die veröffentlichte QIK-VRT-Arbeit zur Wirkungssteuerung enthält dieses Kriterium bereits [2].

Der praktische nächste Schritt ist deshalb konkret: Man liest die veröffentlichte Datei dort zurück, wo sie zugänglich sein soll. Man prüft, ob es die richtige Datei in der richtigen Fassung ist. Und man hält fest, wann und unter welchem Auftrag diese Prüfung stattfand. Nun können sich die beiden vorher gleichen Situationen unterscheiden. Im einen Fall ist der passende Inhalt unter der passenden Adresse vorhanden. Im anderen nicht.

Auch ein zweiter Blick muss allerdings zur Sache passen. Eine alte Datei mit dem richtigen Titel kann die falsche Fassung sein. Derselbe Text kann in einem Testbereich liegen, während die öffentliche Seite leer bleibt. Ein Screenshot kann von gestern stammen. Eine Erfolgsbescheinigung kann zu einem anderen Auftrag gehören. Deshalb ist es hilfreich, nicht nur etwas Passendes zu finden, sondern die Herkunft und Zuordnung dieses Befunds mitzuprüfen.

Man kann sich das wie eine Abholnummer vorstellen. Zwei Pakete können gleich aussehen und denselben Inhalt haben. Trotzdem ist für einen bestimmten Übergabeauftrag wichtig, welches Paket an welchem Ort für wen bereitliegt. Wenn lediglich nach einem identischen Schraubenzieher gefragt wurde, mag jedes passende Exemplar genügen. Wenn der Auftrag die bestätigte Übergabe eines bestimmten Pakets verlangt, reicht ein irgendwo vorhandener gleicher Schraubenzieher nicht. Der Zweck entscheidet, welcher Unterschied zählt.

Um diese Überlegung nicht bei einem Bild stehenzulassen, wurde für die vorliegende Arbeit ein wirklicher kleiner Softwareversuch ausgeführt. Programme schrieben Datensätze in eine Datenbank. Andere, frisch gestartete Prozesse lasen sie zurück. Ein dritter Prüfweg schaute direkt auf die tatsächlich gespeicherten Daten. Es waren echte lokale Schreib- und Lesevorgänge, aber kein bereits laufendes öffentliches QIK-VRT-Gesamtsystem und kein Versuch auf mehreren unabhängigen Rechnern.

Insgesamt wurden dreizehn vorher festgelegte Situationen untersucht. Einmal lief alles richtig. In weiteren Situationen wurde beispielsweise eine Transaktion zurückgerollt, an das falsche Ziel geschrieben, eine alte Fassung verwendet oder eine richtige Beobachtung nicht mehr erreichbar. Der Versuch fragte jedes Mal zweierlei: Ist das genau vereinbarte Ergebnis wirklich vorhanden? Und welche Prüfweise erklärt den Auftrag für abgeschlossen?

Die einfachste Prüfweise schaute nur auf die Bestätigung des Schreibprogramms. Sie erklärte acht Aufträge für erledigt, obwohl deren vereinbartes Ziel nicht erreicht war. Eine zweite Prüfweise las immerhin den Text zurück. Sie irrte noch in sechs Fällen, weil der passende Text aus einem alten oder falsch zugeordneten Datensatz stammte. Das zeigt, warum das Wort „zurücklesen“ allein noch keine vollständige Lösung ist. Entscheidend ist, was genau unter welchem Auftrag zurückgelesen wird.

Die strengere, an QIK-VRT orientierte Prüfweise verlangte zusätzlich die richtige Zuordnung, die passenden Bytes, einen aktuellen Befund und die im Versuch vorgesehene Freigabe. Sie erklärte keinen dieser acht tatsächlich erfolglosen Aufträge für abgeschlossen. Damit ist ein konkreter Nutzen gezeigt: In diesen Fällen wurde eine falsche Sicherheit vermieden. Ein scheinbar erledigter Auftrag blieb als offene Aufgabe sichtbar.

Zum vollständigen Bild gehört eine weitere Kontrolle. Ein separat geschriebener konventioneller Prüfer bekam dieselben Informationen und dieselben Anforderungen. Er erzielte dasselbe Ergebnis. Diese Kontrolle wurde hier nach einem konventionellen End-to-End-Prinzip implementiert; sie ist kein vermessenes fremdes Produkt. Der Versuch zeigt daher den Nutzen der vollständigen, gebundenen Prüfung gegenüber den beiden schwächeren Prüfweisen. Er belegt keine alleinige Fähigkeit eines bestimmten Namens. Schon die klassische Informatik beschreibt, warum Ergebnisse am Ende des tatsächlichen Wegs geprüft werden müssen [4].

Ebenso wichtig ist der Preis der Strenge. In vier Situationen war die gewünschte Datenwirkung bereits eingetreten, aber die strengen Prüfer erklärten den Auftrag noch nicht für abgeschlossen. Eine Bestätigung war verloren gegangen, ein Beobachter fehlte, ein Befund war veraltet oder die Freigabe lag nicht vor. „Noch nicht ausreichend nachgewiesen“ und „nicht passiert“ sind verschiedene Aussagen. Wer diese beiden Aussagen verwechselt, kann durch vorsichtige Prüfung ebenso ein falsches Bild erzeugen wie durch vorschnellen Erfolg. Die Prüfung erfolgte in diesem Versuch nach dem Schreiben; sie kann einen bereits erfolgten unerlaubten Schreibvorgang nicht rückgängig machen.

Ein brauchbarer Arbeitsablauf muss deshalb offen gebliebene Aufgaben weiterführen können. Im Versuch wurde nach jeder der zwölf absichtlich gestörten Situationen die jeweilige Voraussetzung gezielt geändert. Es entstand ein neuer Auftrag mit neuer Kennung. Das richtige Ergebnis wurde neu geschrieben und frisch geprüft. Alle zwölf Nachfolger erreichten das vereinbarte Ziel und wurden akzeptiert. Das Programm hat dabei keine fremden Berechtigungen beschafft und keinen ausgefallenen Internetdienst geheilt; diese Voraussetzungen wurden in der kontrollierten Versuchsumgebung hergestellt.

Damit hat der Versuch einen echten Hin- und Rückweg: Ein Zweck wird festgelegt, eine Handlung ausgeführt, eine Abweichung erkannt, eine gezielte Änderung vorgenommen und deren neue Wirkung geprüft. Der erste Fehlschlag verschwindet dadurch nicht aus der Geschichte. Er erklärt, warum der nächste Schritt nötig war. Der erfolgreiche Nachfolger ist ein neuer Zustand mit seinem eigenen Nachweis.

Daneben wurde die mathematische Unterscheidungsregel in zwei kleinen Welten vollständig durchgerechnet. In der ersten gab es drei mögliche Zustände und zwei mögliche Befunde. Alle vierundsechzig Kombinationen von Beobachtung und gesuchter Eigenschaft wurden geprüft. In der zweiten gab es vier Zustände und drei Befunde; dort wurden sämtliche eintausendzweihundertsechsundneunzig Kombinationen geprüft. In keinem Fall widersprachen sich das Unterscheidungskriterium und die tatsächlich mögliche Entscheidung. Der allgemeine mathematische Kern wurde zusätzlich von Lean, einem formalen Beweisprüfer, geprüft. Drei genau benannte Sätze wurden akzeptiert; ein absichtlich falscher Beweis wurde abgelehnt. Das bestätigt die Ableitung aus den angegebenen Voraussetzungen. Ob ein wirklicher Sensor richtig misst, wird dadurch nicht automatisch entschieden.

Das kleine Experiment wurde bewusst auch an seinen Grenzen geprüft. Einem Prüfer wurde ein gefälschter, aber in sich stimmiger Bericht gegeben. Er enthielt alles, was der Prüfer erwartete: die richtigen Daten, die richtige Kennung und einen frischen Zeitpunkt. Tatsächlich war die Änderung nicht gespeichert worden. Beide strengen Prüfer ließen sich dadurch täuschen. Der Grund ist klar: Wer eine Beobachtung fälschen kann, kann einem darauf vertrauenden System ein falsches Bild liefern.

Eine Prüfsumme beseitigt dieses Problem allein nicht. Sie kann zeigen, dass bestimmte Bytes zu einer bestimmten Kennzahl passen. Eine gefälschte Aussage kann aber ebenfalls unverändert und mit passender Prüfsumme übertragen werden. Deshalb gehören ein glaubwürdiger Beobachtungsweg und eine passende Zuordnung zur Aufgabe. Mehrere Beobachter können helfen, wenn ihre tatsächlichen Fehlerquellen ausreichend verschieden sind. Mehrere Namen für denselben fehlerhaften Ursprung liefern diese Unabhängigkeit noch nicht.

Eine weitere Grenzprüfung zeigte: Nach einer richtigen Beobachtung kann sich der Zustand wieder ändern. Ein Foto der offenen Tür beweist nicht, dass die Tür eine Minute später noch offen steht. Bei einer unveränderlichen Veröffentlichung kann die konkrete geprüfte Fassung dauerhaft adressiert werden. Bei einer veränderlichen Anlage braucht man möglicherweise eine erneute Messung oder eine technische Bindung bis zur Nutzung. Welche Lösung reicht, muss der konkrete Fall zeigen.

Schließlich wurde eine Wirkung an der Prüfstelle vorbeigeführt. Obwohl die Prüfung keine Freigabe erteilt hatte, schrieb ein ausdrücklich zugelassener Umgehungspfad im lokalen Test einen Wirkungseintrag. Das Beispiel ist klein, die Bedeutung weitreichend: Eine Regel kann nur die Wege kontrollieren, die tatsächlich durch sie führen. In der Informatik ist diese Forderung als vollständige Mediation bekannt [5]. Ein sorgfältiger Eingangsschalter schützt keine offene Hintertür.

Diese Grenzen nehmen dem Nachweis nicht seinen Inhalt. Sie sagen, worin der nachgewiesene Inhalt besteht. QIK-VRT kann die Verbindung zwischen Zweck, Handlung, Nachweis und verantworteter Fortsetzung ausdrücklich organisieren. Es kann fehlenden Nachweis sichtbar halten und einen veränderten Nachfolger neu prüfen. Ob eine konkrete Anwendung dies vollständig und zuverlässig tut, wird an ihrem tatsächlichen Verhalten entschieden. Eine in einer Datei eingetragene Behauptung ersetzt diesen Weg nicht.

Für künstliche Kognition ist dieser Unterschied besonders greifbar. Ein System kann eine schlüssig klingende Antwort erzeugen, ohne die passende Quelle gelesen zu haben. Es kann sagen, eine Datei sei gespeichert, obwohl nur ein Entwurf entstand. Es kann eine frühere erfolgreiche Prüfung auf eine später veränderte Fassung übertragen. Ein gebundener Arbeitsweg macht aus diesen verschiedenen Situationen verschiedene, überprüfbare Zustände. Er verlangt die Quelle, die tatsächlich gespeicherte Fassung und den Nachweis für genau diesen Auftrag.

Daraus entsteht die Aussicht auf etwas Alltägliches und Wertvolles: weniger erneutes Erklären, weniger verlorene Zwischenergebnisse und besser nachvollziehbare Übergaben. Ein anderer Mensch oder ein anderes System könnte an einem dokumentierten Stand weiterarbeiten, statt aus einer überzeugenden Erzählung rekonstruieren zu müssen, was vielleicht geschehen ist. Wie groß dieser Vorteil im Alltag ausfällt, ist eine weitere messbare Frage. Der vorliegende Datenbankversuch allein hat ihn noch nicht für alle Anwendungen gemessen.

Über die Informatik hinaus bleibt der Gedanke verständlich. Eine Verwaltung erfüllt ihren Zweck, wenn der richtige Vorgang die zuständige Stelle erreicht und seine Wirkung für den betroffenen Menschen nachvollziehbar wird. Eine Lieferung erfüllt ihren Zweck, wenn das passende Gut am vereinbarten Übergabepunkt ankommt. Eine wissenschaftliche Aussage wird anschlussfähiger, wenn ihre Herkunft, Methode, Grenzen und Änderungen auffindbar bleiben. Für jedes dieser Beispiele muss man den wirklichen Weg und die richtige Beobachtung eigens bestimmen.

Dabei darf ein technisch erreichtes Ziel nicht schon als ein gutes menschliches Ziel gelten. Ein System kann eine ungerechte Entscheidung sehr zuverlässig ausführen. Es kann einen schlechten Auftrag mit großer Genauigkeit erfüllen. Welcher Nutzen für wen entsteht, welche Nebenfolgen zumutbar sind und wer entscheiden darf, bleibt deshalb Teil der verantwortlichen Zweckbestimmung. QIK-VRT kann diese Fragen an einen dokumentierten Arbeitsweg anschließen. Eine technische Erfolgsanzeige beantwortet sie nicht allein.

Auch die eigene Arbeit muss an diesem Maßstab gemessen werden. Die hier beschriebenen Ableitungen und lokalen Versuche sind ausgeführt und dokumentiert. Daraus folgt nicht, dass das gesamte Universale Raumzeit-Terminal bereits öffentlich unter raumzeitterminal.de funktioniert. Der gesondert zurückgelesene öffentliche Beobachtungsstand dieser Untersuchung meldete für diese Domain weiterhin einen Fehler und fehlende DNS-Auflösung. Ein anderer erreichbarer Host würde diesen konkreten Auftrag nicht erfüllen. Auch dieser neue Text ist noch keine bestätigte neue Zenodo-Veröffentlichung.

Der genaue Abschluss schützt zugleich vor dem entgegengesetzten Fehler, endlos dieselbe richtige Aussage zu wiederholen. Wenn für denselben unveränderten Gegenstand alle vereinbarten Nachweise vorliegen, darf diese Aufgabe enden. Wird der Gegenstand geändert oder entsteht eine neue Frage, beginnt die nächste Aufgabe mit eigener Prüfung. Die veröffentlichte QIK-VRT-Abschlussregel beschreibt genau diese Bindung an Gegenstand, Voraussetzungen und Zeitpunkt [3].

Ingolf Lohmanns Formulierung erhält damit einen überprüfbaren Sinn. Eine Anwendung zeigt ihre Fähigkeit durch die Wirkung, die sie unter den benannten Bedingungen tatsächlich erreicht. Ein Vergleich zeigt zugleich, welche entscheidende Information oder Prüfung einem anderen Vorgehen fehlt. Hier wurde dieser Unterschied mathematisch erklärt, in kleinen Zustandsräumen vollständig geprüft und an echten lokalen Speicherübergängen sichtbar gemacht.

Das ist der geführte Nachweis. Sein positiver Kern ist die Möglichkeit, sich auf eine konkret geprüfte Wirkung zu verständigen, an Fehlern gezielt weiterzuarbeiten und einen erreichten Zustand nachvollziehbar abzuschließen. Der Round Trip reicht dann vom menschlichen Zweck über die technische Handlung bis zum überprüften Ergebnis zurück. Dort bekommt das „Quod erat demonstrandum“ seinen bestimmten Gegenstand.

### Quellenanhang

Die Quellen [1] bis [3] sind bereits veröffentlichte Arbeiten von Ingolf Lohmann. Ihre Metadaten und neun ausgewählte Originaldateien wurden für diese Erläuterung frisch zurückgelesen und anhand ihrer Bytes geprüft. Die neue wissenschaftliche Ausarbeitung, ihre Formalisierung und der neue lokale Versuch liegen im Begleitpaket; sie besitzen in dieser Fassung noch keinen bestätigten eigenen Zenodo-Record. Alle Beispiele außerhalb des dokumentierten Softwareversuchs sind erläuternde Übertragungen, keine hier bereits vermessenen Anwendungen.

[1] Ingolf Lohmann. Von Softwarearchitektur zur Weltformel – DAS UNIVERSUM ALS ROUND TRIP. Version 1.0.0-candidate.1; Veröffentlichung 2026-08-08. DOI: 10.5281/zenodo.21888130.

DAS_UNIVERSUM_ALS_ROUND_TRIP_DE.md, Abschnitte 1, 3-6 und 8; zusätzlich ROUND_TRIP_PROMOTED_FORMAL_RESULTS_V1.md. Erkenntnisweg und Trennung von Modell, Ableitung und Wirklichkeitsabgleich.

Record: https://zenodo.org/records/21888130


[2] Ingolf Lohmann. QIK-VRT/EFFECT_ACK: Verfassungsschicht der Wirkung - Exhaustive Prüfung eines bedingten Kontrollsatzes, Grenzen universeller Rekonstruktion und cyberphysische Geltungsbedingungen. Version 1.0.0; Veröffentlichung 2026-07-22. DOI: 10.5281/zenodo.21498773.

ARTICLE_DE.md, besonders Abschnitte 2, 3, 5 und 7; proof-report.json, RE-001, EA-002, EA-003 und EA-005; EVIDENCE_BOUNDARY.md. Die Original-PDF ist ebenfalls frisch bytegeprüft.

Record: https://zenodo.org/records/21498773

Original-PDF: https://zenodo.org/records/21498773/files/QIK-VRT_EFFECT_ACK_Universalisierbare_Wirkungssteuerung_2026-07-22.pdf


[3] Ingolf Lohmann. Proof Closure: The Terminal Meta-Condition for an Evidence-Bound Subject. Version 1.0.0; Veröffentlichung 2026-09-24. DOI: 10.5281/zenodo.22941556.

PROOF_CLOSURE_DE.md, „Die Closure-Bedingung“, „Mutation eröffnet eine neue Beweiskette“ und „Wissenschaftliche Grenze“; PROOF_CLOSURE_CONTRACT.json und CLAIM_MATRIX.json. Drei dortige formale Claims bleiben historisch TO_BE_KERNEL_CHECKED.

Record: https://zenodo.org/records/22941556


[4] End-to-End Arguments in System Design. J. H. Saltzer, D. P. Reed und D. D. Clark. ACM Transactions on Computer Systems 2(4), 277-288, November 1984. Fundstelle: „End-to-end caretaking“, PDF-Seiten 2-3. Original-PDF am MIT. DOI: 10.1145/357401.357402.

https://web.mit.edu/Saltzer/www/publications/endtoend/endtoendA4.pdf


[5] The Protection of Information in Computer Systems. J. H. Saltzer und M. D. Schroeder. Proceedings of the IEEE 63(9), 1278-1308, September 1975. Fundstelle: Abschnitt I.A.3, besonders „Fail-safe defaults“ und „Complete mediation“. Autorenseite am MIT. DOI: 10.1109/PROC.1975.9939.

https://web.mit.edu/Saltzer/www/publications/protection/Basic.html
