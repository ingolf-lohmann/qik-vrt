#!/usr/bin/env python3
"""Render the research manuscripts with visible, clickable source locators."""
import html
import json
import re
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (BaseDocTemplate, Frame, KeepTogether, PageTemplate,
                               Paragraph, Spacer, Table, TableStyle)

ROOT = Path(__file__).parent.resolve()
OUT = ROOT / "output"
OUT.mkdir(exist_ok=True)
FONT_DIR = Path('/usr/share/fonts/truetype/dejavu')
for name, file in [('Body', 'DejaVuSerif.ttf'), ('Body-Bold', 'DejaVuSerif-Bold.ttf'),
                   ('Sans', 'DejaVuSans.ttf'),
                   ('Sans-Bold', 'DejaVuSans-Bold.ttf'), ('Mono', 'DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(name, str(FONT_DIR / file)))
pdfmetrics.registerFontFamily('Body', normal='Body', bold='Body-Bold', italic='Body', boldItalic='Body-Bold')
pdfmetrics.registerFontFamily('Sans', normal='Sans', bold='Sans-Bold', italic='Sans', boldItalic='Sans-Bold')

INK = colors.HexColor('#172d3b')
TEAL = colors.HexColor('#176a70')
MUTED = colors.HexColor('#52636a')
PALE = colors.HexColor('#edf4f4')
WIDTH = A4[0] - 42 * mm


def inline(text):
    text = html.escape(text, quote=False)
    text = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', text)
    # Every locator is visibly written, as well as linked to the exact address.
    return re.sub(r'https?://[^\s<>]+',
                  lambda m: '<a href="' + m.group().replace('&', '&amp;') +
                  '" color="#176a70">' + m.group() + '</a>', text)


class Manuscript(BaseDocTemplate):
    def __init__(self, path, kind, title, **kwargs):
        super().__init__(str(path), pagesize=A4, leftMargin=21*mm, rightMargin=21*mm,
                         topMargin=23*mm, bottomMargin=21*mm,
                         title=title, author='Ingolf Lohmann (Ausgangspunkt); OpenAI Codex (Ausarbeitung im Auftrag)',
                         subject='Bedingter Wirkungsnachweis; Autorenprüffassung vom 16.10.2026', **kwargs)
        self.kind = kind
        frame = Frame(self.leftMargin, self.bottomMargin, self.width, self.height,
                      leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
        self.addPageTemplates(PageTemplate('manuscript', [frame], onPage=self.page_design))
        self.heading_index = 0

    def page_design(self, c, doc):
        c.saveState()
        c.setFillColor(TEAL)
        c.rect(21*mm, A4[1]-15.5*mm, 12*mm, 1*mm, fill=1, stroke=0)
        c.setFont('Sans', 7.3)
        c.setFillColor(MUTED)
        c.drawString(37*mm, A4[1]-15.3*mm, 'QIK-VRT  |  ' + self.kind)
        c.setStrokeColor(colors.HexColor('#d5dfe0'))
        c.line(21*mm, 16.5*mm, A4[0]-21*mm, 16.5*mm)
        c.setFont('Sans', 7.2)
        c.drawString(21*mm, 12*mm, 'Autorenprüffassung  |  16. Oktober 2026')
        c.drawRightString(A4[0]-21*mm, 12*mm, str(doc.page))
        c.restoreState()

    def afterFlowable(self, flowable):
        if getattr(flowable, 'outline_title', None):
            self.heading_index += 1
            key = f'heading-{self.heading_index}'
            self.canv.bookmarkPage(key)
            self.canv.addOutlineEntry(flowable.outline_title, key, level=0, closed=False)


def render(markdown, destination, kind, prose=False):
    body_size = 11.0 if prose else 10.2
    leading = 16.8 if prose else 14.5
    styles = {
        'body': ParagraphStyle('body', fontName='Body', fontSize=body_size, leading=leading,
                               textColor=INK, spaceAfter=7.5, alignment=TA_LEFT,
                               splitLongWords=True, allowWidows=0, allowOrphans=0),
        'title': ParagraphStyle('title', fontName='Sans-Bold', fontSize=28, leading=32,
                                textColor=INK, spaceAfter=11, keepWithNext=True),
        'subtitle': ParagraphStyle('subtitle', fontName='Sans', fontSize=15, leading=20,
                                   textColor=TEAL, spaceAfter=14, keepWithNext=True),
        'heading': ParagraphStyle('heading', fontName='Sans-Bold', fontSize=12.5, leading=17,
                                  textColor=TEAL, spaceBefore=17, spaceAfter=8, keepWithNext=True),
        'quote': ParagraphStyle('quote', fontName='Body', fontSize=10.2, leading=15.5,
                                textColor=MUTED, leftIndent=12, rightIndent=10,
                                borderPadding=7, borderWidth=.6, borderColor=colors.HexColor('#c5dada'),
                                backColor=PALE, spaceAfter=9),
        'code': ParagraphStyle('code', fontName='Mono', fontSize=8.4, leading=12.5,
                               textColor=INK, leftIndent=10, rightIndent=7, spaceAfter=3,
                               splitLongWords=True),
        'table': ParagraphStyle('table', fontName='Sans', fontSize=8.25, leading=11.5,
                                textColor=INK, splitLongWords=True),
        'th': ParagraphStyle('th', fontName='Sans-Bold', fontSize=8.0, leading=11.3,
                             textColor=colors.white, splitLongWords=True),
    }
    story = []
    lines = markdown.splitlines()
    i = 0
    in_references = False
    while i < len(lines):
        line = lines[i].strip()
        if not line:
            i += 1
            continue
        if in_references and re.match(r'^\[\d+\]', line):
            # Keep a source's title, exact locator and scope together.
            entries = []
            current = []
            ref_style = ParagraphStyle('ref-group', parent=styles['body'], fontName='Sans',
                                       fontSize=9.0, leading=13.1, spaceAfter=8)
            while i < len(lines):
                value = lines[i].strip()
                if re.match(r'^\[\d+\]', value) and entries:
                    break
                if re.match(r'^\[\d+\]', value) and current:
                    break
                if value:
                    current.append(value)
                elif current:
                    entries.append(Paragraph(inline(' '.join(current)), ref_style))
                    current = []
                i += 1
            if current:
                entries.append(Paragraph(inline(' '.join(current)), ref_style))
            story.append(KeepTogether(entries))
            continue
        if line.startswith('```'):
            block = []
            i += 1
            while i < len(lines) and not lines[i].startswith('```'):
                block.append(Paragraph(html.escape(lines[i]) or '&#160;', styles['code']))
                i += 1
            story.append(KeepTogether([Spacer(1, 5), *block, Spacer(1, 8)]))
            i += 1
            continue
        if line.startswith('|'):
            cells = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                fields = [f.strip() for f in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r':?-+:?', f.replace(' ', '')) for f in fields):
                    cells.append(fields)
                i += 1
            n = len(cells[0])
            if n == 6:
                widths = [WIDTH * .48] + [WIDTH * .104] * 5
            elif n == 5:
                widths = [WIDTH * .38] + [WIDTH * .155] * 4
            elif n == 3:
                widths = [WIDTH * .32, WIDTH * .36, WIDTH * .32]
            else:
                widths = [WIDTH/n] * n
            rows = [[Paragraph(inline(v), styles['th'] if r == 0 else styles['table'])
                     for v in row] for r, row in enumerate(cells)]
            table = Table(rows, colWidths=widths, repeatRows=1, hAlign='LEFT')
            table.setStyle(TableStyle([
                ('BACKGROUND', (0,0), (-1,0), INK),
                ('VALIGN', (0,0), (-1,-1), 'TOP'),
                ('LEFTPADDING', (0,0), (-1,-1), 7),
                ('RIGHTPADDING', (0,0), (-1,-1), 7),
                ('TOPPADDING', (0,0), (-1,-1), 7),
                ('BOTTOMPADDING', (0,0), (-1,-1), 7),
                ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, PALE]),
                ('LINEBELOW', (0,-1), (-1,-1), .5, colors.HexColor('#c4d2d5')),
            ]))
            story += [Spacer(1, 5), table, Spacer(1, 12)]
            continue
        if line.startswith('# '):
            story.append(Paragraph(inline(line[2:]), styles['title']))
            i += 1
            continue
        if line.startswith('## '):
            story.append(Paragraph(inline(line[3:]), styles['subtitle']))
            i += 1
            continue
        if line.startswith('### '):
            h = line[4:]
            if h.startswith('Anhang B.') or h == 'Quellenanhang':
                in_references = True
            p = Paragraph(inline(h), styles['heading'])
            p.outline_title = h
            story.append(p)
            i += 1
            continue
        if line.startswith('>'):
            quotes = []
            while i < len(lines) and lines[i].strip().startswith('>'):
                quotes.append(lines[i].strip()[1:].strip())
                i += 1
            story.append(Paragraph(inline(' '.join(quotes)), styles['quote']))
            continue
        paragraph = [line]
        i += 1
        while i < len(lines) and lines[i].strip() and not lines[i].strip().startswith(('#', '|', '```', '>')):
            paragraph.append(lines[i].strip())
            i += 1
        style = styles['body']
        if in_references:
            style = ParagraphStyle('ref', parent=style, fontName='Sans', fontSize=9.0,
                                   leading=13.1, spaceAfter=9)
        story.append(Paragraph(inline(' '.join(paragraph)), style))
    doc = Manuscript(destination, kind, lines[0].lstrip('# '))
    doc.build(story)


if __name__ == '__main__':
    render((OUT/'QIKVRT_Wirkungsnachweis_Wissenschaft_20261016.md').read_text(),
           OUT/'QIKVRT_Wirkungsnachweis_Wissenschaft_20261016.pdf', 'Wissenschaftliche Erläuterung')
    render((OUT/'QIKVRT_Der_entscheidende_Unterschied_Prosa_20261016.md').read_text(),
           OUT/'QIKVRT_Der_entscheidende_Unterschied_Prosa_20261016.pdf', 'Allgemein verständliche Prosa', True)
