/* Environment compatibility only: Lean 4.19 queries /proc/<own-pid>/exe.
 * This runtime permits /proc/self/exe but denies the numeric own-pid alias.
 * Map only that exact caller-owned alias to the permitted self API.
 * Every other path and the actual returned executable path are unchanged.
 * No proof checking, trust setting, file permission or credential is changed.
 */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

ssize_t readlink(const char *path, char *buffer, size_t size) {
    typedef ssize_t (*readlink_function)(const char *, char *, size_t);
    readlink_function original = (readlink_function)dlsym(RTLD_NEXT, "readlink");
    char own_executable[80];
    snprintf(own_executable, sizeof(own_executable), "/proc/%ld/exe", (long)getpid());
    if (strcmp(path, own_executable) == 0)
        return original("/proc/self/exe", buffer, size);
    return original(path, buffer, size);
}
