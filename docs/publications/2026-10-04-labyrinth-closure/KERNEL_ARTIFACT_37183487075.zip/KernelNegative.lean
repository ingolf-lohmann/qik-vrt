import Std
example : False := by decide
