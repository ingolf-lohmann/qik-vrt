# Abgeschlossen und anschlussfähig - Artikel-Prüfpaket

Konzept und Aufgabenstellung: Ingolf Lohmann. Neue Formalisierung, Prüfharness
und Text: OpenAI Codex, KI-assistierter Beitrag; menschliche Annahme ausstehend.

## Tatsächlicher Status am 15. September 2026

**FORMAL_PENDING_KERNEL. Kein erfolgreicher neuer Lean-Kernellauf.**

Lean 4.19.0 wurde aus der offiziellen Distribution lokal bereitgestellt. Bereits
`lean --version` endet hier mit Exitcode 1 und `failed to locate application`.
Der vorgesehene `lake build` endet ebenfalls vor der Quellprüfung mit
`could not detect the configuration of the Lake installation`.
Es wurden keine Beweistaktiken durch Abschwächung ersetzt und keine
Zugriffsbeschränkungen umgangen. Historische Repository-Belege gelten nicht als
neue Ausführung dieses Pakets.

Das Paket enthält 14 neue Theoreme, 3 zusätzlich ausgewählte bestehende
Haupttheoreme für den Axiom-Audit und 3 absichtlich ungültige Negativkontrollen.
Diese Zahlen sind ein **Quellinventar**, keine erfolgreichen Testzahlen.

## Reproduktion

Voraussetzungen: ausführbare offizielle Lean-4.19.0-Distribution einschließlich
Lake und Std sowie Python 3.10 oder neuer (nur Standardbibliothek).
Mit bereits eingerichtetem Elan wählt `lean-toolchain` die Version aus.
Alternativ das `bin`-Verzeichnis der offiziellen Distribution dem PATH hinzufügen.
Es sind keine zusätzlichen Lake-Pakete und kein Mathlib erforderlich.

```sh
lean --version
lake --version
python3 verify.py
```

Der Prüfer führt einen sauberen Build, den vollständigen deklarierten
`#print axioms`-Audit und alle drei Negativkontrollen aus. Er akzeptiert nur
17 vollständige, leere Axiomenberichte. `sorry`, eigene Axiome und andere
deklarierte Ausweichmechanismen werden zusätzlich im Quelltext zurückgewiesen.
Ein erfolgreicher Lauf muss die drei ungültigen Dateien ablehnen.

`evidence/VERIFICATION_STATUS.json` bezeichnet den letzten Lauf.
Nur bei Erfolg verweist es auf ein frisches `KERNEL_RECEIPT.json`, das
Quellen, Toolversionen, Binärdateien, Buildobjekte und Logs bindet.
Ein eventuell von einem älteren Lauf vorhandenes Receipt ist bei einem
aktuellen Fehler **nicht** die Autorität des letzten Laufs.

Der PDF-Artikel ist zusätzlich im Unterverzeichnis `article/` des ZIP enthalten.
Nach dem Entpacken prüft `sha256sum -c SHA256SUMS` den gelieferten Dateiumfang.
Diese Byteprüfung ist keine Lean-Prüfung. Optional benötigt die PDF-Neuerzeugung
mit `render_article.py` ReportLab 4.4.9 und die DejaVu-Schriften unter dem
angegebenen Linux-Pfad. Die Layoutkontrolle verwendet pdfplumber 0.11.8,
Pillow und Poppler. Die Quellen reproduzieren den Satz; ohne festgelegte
PDF-Metadaten wird keine byteidentische Neurenderung behauptet.

## Beweisumfang und zentrale Voraussetzung

`closed_but_extendible` beweist im vorgesehenen Modell:
Die Abschlüsse C(S) und C(S union {z}) sind beide abgeschlossen;
C(S) ist im zweiten enthalten; falls z zulässig und nicht in C(S) liegt,
ist die Erweiterung echt. Dieser Abschluss bezeichnet Modellableitbarkeit,
nicht bereits beobachtete physische Ereignisse. Extensivität verlangt,
dass die Anfangselemente das Viabilitätsprädikat erfüllen.

`progress_for_every_finite_horizon` benötigt die gesonderte Voraussetzung,
dass **jeder** viable Zustand einen viablen Nachfolger hat.
`viable_deadlock` widerlegt die Weglassung dieser Voraussetzung.
Es wird weder unendliche reale Ausführung noch allgemeine Terminierung,
physikalische Universalgültigkeit oder ein fertiges SoC bewiesen.

## Herkunft und Rechte

Die zwei Dateien unter `QIKVRTFormalization/Process` sind unveränderte,
SHA-256-gebundene Auszüge aus Goldkelch/qik-vrt, Commit
`a86054139b49c13c5cd344753b248b46b5daf66f`.
Ihre Apache-2.0-Dateihinweise bleiben erhalten; der Lizenztext liegt unter
`licenses/Apache-2.0.txt`. Andere Teile des Repositories sind nicht mitlizenziert.
Für die neuen Ergänzungen wird hier kein zusätzlicher öffentlicher
Lizenz-, Prioritäts- oder Publikationsstatus behauptet.

Der neue Quellumfang ist ein lokaler, über Dateien gebundener Artikelkandidat,
kein neuer GitHub-Head. `PROVENANCE.json` enthält die getrennten Beiträge.
Dieses Paket ist kein Zenodo-v2-Freigabebündel und keine Upload-Autorisierung.

## Getrennte Folgeschritte

Zuerst den exakten Kandidaten erfolgreich bauen und auditieren, dann Text und
Beweisabbildung fachlich prüfen. Für eine SoC-Aussage sind zusätzlich konkrete
Schnittstellen, Endlichkeits-/Ressourcengrenzen, RTL, Refinement, Synthese,
Timing und Hardware-Readback erforderlich. Push, PR, Review, Approval, Merge,
Publication, PASS, FINAL_PASS und EFFECT_ACK_DONE werden nicht durch dieses
Prüfprogramm gesetzt oder abgeleitet.
