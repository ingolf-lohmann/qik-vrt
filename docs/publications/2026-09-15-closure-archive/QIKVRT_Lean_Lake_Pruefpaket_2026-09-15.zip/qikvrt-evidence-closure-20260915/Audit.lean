import EvidenceClosure

#print axioms QIKVRT.Article.EvidenceClosure.trace_append
#print axioms QIKVRT.Article.EvidenceClosure.closure_extensive
#print axioms QIKVRT.Article.EvidenceClosure.closure_monotone
#print axioms QIKVRT.Article.EvidenceClosure.closure_viable
#print axioms QIKVRT.Article.EvidenceClosure.closure_idempotent
#print axioms QIKVRT.Article.EvidenceClosure.closure_is_closed
#print axioms QIKVRT.Article.EvidenceClosure.closed_but_extendible
#print axioms QIKVRT.Article.EvidenceClosure.progress_for_every_finite_horizon
#print axioms QIKVRT.Article.EvidenceClosure.viable_deadlock
#print axioms QIKVRT.Article.EvidenceClosure.no_rules_closure
#print axioms QIKVRT.Article.EvidenceClosure.strict_extension_witness
#print axioms QIKVRT.Article.EvidenceClosure.no_stale_transfer
#print axioms QIKVRT.Article.EvidenceClosure.transport_does_not_imply_effect
#print axioms QIKVRT.Article.EvidenceClosure.counter_finite_progress
#print axioms QIKVRT.V2.OperationalContinuation.FIT001_checked
#print axioms QIKVRT.V2.ConnectabilitySimulation.FIT002_checked
#print axioms QIKVRT.V2.ConnectabilitySimulation.FIT003_checked
