# Abgeschlossen heißt nicht zu Ende

## Wie QIK-VRT Wissen bewahren und trotzdem Neues zulassen kann

Ein gutes technisches System muss zwei scheinbar gegensätzliche Dinge können: Es muss verlässlich festhalten, was bereits geklärt ist. Und es muss offen bleiben für das, was als Nächstes kommt.

Eine Brücke soll fertig geprüft sein, bevor Menschen sie benutzen. Trotzdem darf hinter ihr später eine neue Straße entstehen. Die Prüfung der Brücke wird dadurch nicht wertlos. Sie wird aber auch nicht automatisch zur Prüfung der neuen Straße.

Genau in dieser Unterscheidung liegt ein tragfähiger Kern des QIK-VRT-Gedankens von Ingolf Lohmann: abgeschlossene Begründungen können Anschlussstellen für weitere Begründungen sein.

### Was eine Maschine wirklich weiß

Ein Computer meldet: „Befehl empfangen.“ Ein Mensch liest: „Aufgabe erledigt.“ Zwischen beiden Aussagen kann ein erheblicher Unterschied liegen.

Vielleicht wurde ein Ventil angesteuert, hat sich aber nicht bewegt. Vielleicht wurde eine Datei übertragen, aber der Empfänger kann ihr Format nicht lesen. Vielleicht ist ein Test erfolgreich, gehört jedoch zu einer früheren Programmversion.

QIK-VRT richtet die Aufmerksamkeit auf diese Lücke. Eine Handlung wird mit einem bestimmten Ausgangszustand verbunden. Danach wird zurückgelesen, was tatsächlich vorliegt. Erst dann wird eingeordnet, welche Aussage das Ergebnis trägt.

Das Empfangssignal ist eine Information. Die beobachtete Wirkung ist eine andere. Beides darf zusammenpassen, muss aber nicht.

### Eine geprüfte Etappe bleibt eine geprüfte Etappe

Stellen wir uns einen Bestand begründeter Aussagen vor. Dazu gehören festgelegte Regeln, nach denen weitere Aussagen daraus folgen dürfen. Wir wenden diese Regeln an, bis eine erneute Anwendung nichts mehr hinzufügt. In diesem Sinn ist der Bestand abgeschlossen.

Das bedeutet nicht, dass er alles enthält, was es zu wissen gibt. Es bedeutet nur: Aus diesen Grundlagen folgt unter diesen Regeln nichts Zusätzliches mehr.

Kommt eine neue zulässige Grundlage hinzu, kann ein größerer Bestand entstehen. Auch dieser kann wieder abgeschlossen werden. Der frühere Bestand bleibt darin erhalten, soweit Regeln und Geltungsbedingungen unverändert bleiben.

Der Fachartikel formuliert diesen Zusammenhang präzise: Ein abgeschlossener Bestand kann echt erweitert werden, wenn ein neues zulässiges Element außerhalb seines bisherigen Abschlusses verfügbar ist. Das Wort „wenn“ gehört zum Ergebnis. Der Satz verspricht nicht, dass jedes System jederzeit eine solche Erweiterung besitzt.

Damit wird verständlich, wie etwas abgeschlossen und anschlussfähig zugleich sein kann: abgeschlossen hinsichtlich seiner bisherigen Grundlagen, anschlussfähig für eine begründete Erweiterung.

### Warum auch ein Halt richtig sein kann

Eine geprüfte Brücke garantiert noch keine Straße auf der anderen Seite. Ebenso garantiert ein gültiger Systemzustand keinen zulässigen nächsten Schritt.

Vielleicht fehlt eine Eingabe. Vielleicht ist ein Gerät nicht erreichbar. Vielleicht muss ein Mensch eine Entscheidung treffen. Dann kann Anhalten die richtige Reaktion sein.

Das ist keine Widerlegung des bisherigen Nachweises. Es markiert seine Grenze. Ein zuverlässiger Agent sollte diese Grenze erkennen können, ohne den vorhandenen Fortschritt zu verwerfen und ohne eine fehlende Freigabe zu erfinden.

Der Artikel enthält deshalb auch ein einfaches Gegenmodell: einen gültigen Zustand, von dem kein Übergang ausgeht. Es zeigt, weshalb Fortsetzung eine eigene Voraussetzung braucht.

### Vom Programm zum Chip

Software und Hardware können auf passenden Abstraktionsebenen als Systeme beschrieben werden, die Zustände besitzen und verändern. Das schafft eine gemeinsame Sprache, macht sie aber nicht zu derselben Sache.

Ein formales Modell kann beispielsweise festlegen, wann ein Kontrollkern eine Handlung zulassen darf. Für einen tatsächlichen Chip müssen daraus begrenzte Register, konkrete Schaltungen und überprüfte Schnittstellen werden. Anschließend muss gezeigt werden, dass diese Implementierung den Vertrag einhält.

Noch eine Grenze liegt zwischen Chip und Umwelt. Ein korrekt ausgegebenes Signal beweist nicht allein, dass der angeschlossene Motor die gewünschte Bewegung ausgeführt hat. Dafür braucht es einen geeigneten Messpfad. Selbst eine passende Messung muss dem richtigen Gegenstand zugeordnet sein und andere mögliche Ursachen berücksichtigen.

Der Weg zur SoC-Realisierung ist damit konkret beschreibbar. Er ist aber nicht schon dadurch vollständig beschritten, dass die Architektur gut zusammenpasst.

### Was ein mathematischer Prüfer beitragen kann

Lean kann prüfen, ob eine genau formulierte Aussage aus ihren angegebenen Voraussetzungen folgt. Das hilft insbesondere dort, wo eine sprachlich überzeugende Formulierung eine Voraussetzung verdeckt. Lake organisiert den zugehörigen Build.

Für diesen Artikel wurden vorhandene QIK-VRT-Module wiederverwendet und um den Abschlusssatz, Erweiterungsbedingungen und Gegenmodelle ergänzt. Die neue Maschinenprüfung ist allerdings noch offen: Die bereitgestellte Lean-Version scheitert in dieser Arbeitsumgebung bereits beim Start. Aus vorbereitetem Beweiscode wird deshalb kein behaupteter erfolgreicher Kernelnachweis.

Diese Unterscheidung ist selbst eine praktische Anwendung des behandelten Prinzips: Nicht der beabsichtigte Effekt entscheidet über die Statusmeldung, sondern der beobachtete.

### Die Stärke liegt in der überprüfbaren Verbindung

QIK-VRTs hier untersuchter Anspruch ist nicht, dass Maschinen nie irren. Er lautet: Aussagen sollen nachvollziehbar an ihre Grundlagen, ihre Geltungsgrenzen und ihre Prüfung gebunden sein.

So kann ein Ergebnis Bestand haben, ohne zum Schlusswort über alles zu werden. Eine neue Beobachtung kann hinzukommen, ohne die Vergangenheit umzuschreiben. Eine nächste Handlung kann vorbereitet werden, ohne ihre Wirkung vorwegzunehmen.

Die Bühne ist damit weder eine bloße Sammlung grüner Häkchen noch ein System, das sich selbst uneingeschränkt recht gibt. Sie ist eine geordnete Verbindung zwischen dem, was begründet ist, dem, was noch geprüft werden muss, und dem nächsten zulässigen Schritt.

Abgeschlossen heißt dann: Diese Etappe trägt.

Anschlussfähig heißt: Auf ihr kann weitergebaut werden, sobald die nächste Verbindung ebenfalls trägt.

*Konzept und Ausgangsgedanke: Ingolf Lohmann. KI-assistierte Ausarbeitung: OpenAI Codex.*
