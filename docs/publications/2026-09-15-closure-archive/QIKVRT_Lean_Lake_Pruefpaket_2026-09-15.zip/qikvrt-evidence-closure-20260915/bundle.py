"""Freeze a deterministic downloadable source package with noncircular hashes."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
PDF = ROOT.parent / "output/pdf/QIKVRT_Abgeschlossen_und_anschlussfaehig_2026-09-15.pdf"
OUTPUT = ROOT.parent / "output/QIKVRT_Lean_Lake_Pruefpaket_2026-09-15.zip"
paths = sorted(p for p in ROOT.rglob("*") if p.is_file()
               and not any(part.startswith(".") or part == "__pycache__" for part in p.relative_to(ROOT).parts)
               and p.name not in {"DELIVERY_MANIFEST.json", "SHA256SUMS"})
entries = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in paths}
entries["article/" + PDF.name] = PDF.read_bytes()
manifest = {"schema": "qikvrt-article-delivery-fileset-v1", "date": "2026-09-15",
            "kernel_status": "FORMAL_PENDING_KERNEL", "is_zenodo_v2_proof_bundle": False,
            "files": [{"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
                      for name, data in sorted(entries.items())],
            "excluded_from_own_inventory": ["DELIVERY_MANIFEST.json", "SHA256SUMS"],
            "publication_approval_and_effect_claims": False}
manifest_bytes = (json.dumps(manifest, indent=2, ensure_ascii=False) + "\n").encode()
entries["DELIVERY_MANIFEST.json"] = manifest_bytes
checksums = "".join(f"{hashlib.sha256(data).hexdigest()}  {name}\n" for name, data in sorted(entries.items()))
entries["SHA256SUMS"] = checksums.encode()
(ROOT / "DELIVERY_MANIFEST.json").write_bytes(manifest_bytes)
(ROOT / "SHA256SUMS").write_text(checksums)
with zipfile.ZipFile(OUTPUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
    for name, data in sorted(entries.items()):
        info = zipfile.ZipInfo("qikvrt-evidence-closure-20260915/" + name, (2026, 9, 15, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        zf.writestr(info, data)
with zipfile.ZipFile(OUTPUT) as zf:
    assert zf.testzip() is None
    for item in manifest["files"]:
        data = zf.read("qikvrt-evidence-closure-20260915/" + item["path"])
        assert len(data) == item["bytes"]
        assert hashlib.sha256(data).hexdigest() == item["sha256"]
print(json.dumps({"archive": str(OUTPUT), "archive_bytes": OUTPUT.stat().st_size,
                  "archive_sha256": hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),
                  "files": len(entries), "zip_and_payload_hash_validation": "VERIFIED"}, indent=2))
