"""Local artifact inspection and deterministic source-bundle packaging."""
from pathlib import Path
import ast
import hashlib
import json
import re
import zipfile
import pdfplumber
from PIL import Image, ImageOps, ImageDraw

ROOT = Path(__file__).resolve().parent
PDF = ROOT.parent / "output/pdf/QIKVRT_Abgeschlossen_und_anschlussfaehig_2026-09-15.pdf"
RENDER = ROOT.parent / "tmp/pdfs"
report = {"pdf": str(PDF), "pages": [], "python_syntax": [],
          "lean_status": "FORMAL_PENDING_KERNEL", "visual_review": "PENDING"}
with pdfplumber.open(PDF) as pdf:
    for i, page in enumerate(pdf.pages, 1):
        text = page.extract_text()
        if not text or len(text) < 500:
            raise RuntimeError(f"Empty or orphan page {i}")
        if "\ufffd" in text or "\x00" in text or "(cid:" in text:
            raise RuntimeError(f"Missing-glyph marker on page {i}")
        # Interior content must not collide with the header or footer.
        words = [w for w in page.extract_words() if w["top"] > 48 and w["bottom"] < 790]
        if any(w["x0"] < 55 or w["x1"] > 542 for w in words):
            raise RuntimeError(f"Text extends beyond page margin on {i}")
        report["pages"].append({"page": i, "characters": len(text)})
    full = "\n".join(p.extract_text() for p in pdf.pages)
    for expected in ("FORMAL_PENDING_KERNEL", "failed to locate application", "EC-08",
                     "a86054139b49c13c5cd344753b248b46b5daf66f"):
        if expected not in full:
            raise RuntimeError(f"Required status or binding absent: {expected}")

for path in sorted(ROOT.glob("*.py")):
    ast.parse(path.read_text())
    report["python_syntax"].append(path.name)

report["new_theorem_source_count"] = len(re.findall(r"^theorem ", (ROOT / "EvidenceClosure.lean").read_text(), re.M))
report["audit_source_count"] = len(re.findall(r"^#print axioms ", (ROOT / "Audit.lean").read_text(), re.M))
assert report["new_theorem_source_count"] == 14
assert report["audit_source_count"] == 17
assert len(list((ROOT / "negative").glob("*.lean"))) == 3
report["pdf_sha256"] = hashlib.sha256(PDF.read_bytes()).hexdigest()
visual_path = ROOT / "VISUAL_REVIEW.json"
if visual_path.exists():
    visual = json.loads(visual_path.read_text())
    if visual["pdf_sha256"] == report["pdf_sha256"]:
        report["visual_review"] = visual["result"]
(ROOT / "PDF_VALIDATION.json").write_text(json.dumps(report, indent=2) + "\n")

images = sorted(RENDER.glob("qikvrt-*.png"))[:len(report["pages"])]
for start in range(0, len(images), 5):
    sheet = Image.new("RGB", (1250, 930), "#dfe5e9")
    for j, path in enumerate(images[start:start+5]):
        im = Image.open(path).convert("RGB")
        im.thumbnail((395, 440))
        x, y = (j % 3) * 415 + 10, (j // 3) * 465 + 15
        sheet.paste(im, (x, y))
        ImageDraw.Draw(sheet).text((x, y + 443), path.stem, fill="black")
    sheet.save(RENDER / f"contact-{start//5+1}.png")
print(json.dumps(report, indent=2))
