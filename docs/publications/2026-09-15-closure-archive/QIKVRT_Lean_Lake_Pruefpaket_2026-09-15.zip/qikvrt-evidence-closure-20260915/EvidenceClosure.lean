import QIKVRTFormalization.Process.OperationalContinuation
import QIKVRTFormalization.Process.ConnectabilitySimulation

/-!
Article supplement, 2026-09-15.
Concept and requested claim: Ingolf Lohmann.
New formalization: OpenAI Codex, AI-assisted contribution, human review pending.

Closure below means finite *model derivability*, not observed physical effects.
Viability and transition contracts are premises, not established by this file.
This imports exact repository modules instead of replacing their trace model.
-/

namespace QIKVRT.Article.EvidenceClosure

open QIKVRT.V2.ConnectabilitySimulation
open QIKVRT.V2.OperationalContinuation

universe u v

variable {X : Type u} {L : Type v}

/-- Compose finite viable traces at an exactly matching endpoint. -/
theorem trace_append (T : TypedTransitionSystem X L)
    {a b c : X} {xs ys : List L}
    (h : ViableTrace T a xs b) (k : ViableTrace T b ys c) :
    ViableTrace T a (xs ++ ys) c := by
  induction xs generalizing a with
  | nil =>
    rcases h with ⟨hab, _⟩
    subst a
    exact k
  | cons x xs ih =>
    rcases h with ⟨next, hstep, htail⟩
    exact ⟨next, hstep, ih htail⟩

/-- Model closure of a seed predicate under finite viable derivations. -/
def C (T : TypedTransitionSystem X L) (seed : X → Prop) (x : X) : Prop :=
  ∃ a labels, seed a ∧ ViableTrace T a labels x

/-- Extensivity is conditional on seed viability (empty traces require it). -/
theorem closure_extensive (T : TypedTransitionSystem X L) (seed : X → Prop)
    {x : X} (hx : seed x) (hv : T.viable x) : C T seed x :=
  ⟨x, [], hx, rfl, hv⟩

theorem closure_monotone (T : TypedTransitionSystem X L)
    {seed larger : X → Prop} (h : ∀ x, seed x → larger x) :
    ∀ x, C T seed x → C T larger x := by
  rintro x ⟨a, labels, ha, ht⟩
  exact ⟨a, labels, h a ha, ht⟩

theorem closure_viable (T : TypedTransitionSystem X L) (seed : X → Prop)
    {x : X} (h : C T seed x) : T.viable x := by
  rcases h with ⟨a, labels, _, ht⟩
  exact viable_trace_target_viable T a x labels ht

theorem closure_idempotent (T : TypedTransitionSystem X L)
    (seed : X → Prop) (x : X) : C T (C T seed) x ↔ C T seed x := by
  constructor
  · rintro ⟨b, ys, ⟨a, xs, ha, hab⟩, hbc⟩
    exact ⟨a, xs ++ ys, ha, trace_append T hab hbc⟩
  · intro hx
    exact closure_extensive T (C T seed) hx (closure_viable T seed hx)

def Closed (T : TypedTransitionSystem X L) (seed : X → Prop) : Prop :=
  ∀ x, C T seed x ↔ seed x

theorem closure_is_closed (T : TypedTransitionSystem X L) (seed : X → Prop) :
    Closed T (C T seed) := closure_idempotent T seed

def Extend (seed : X → Prop) (new : X) (x : X) : Prop := seed x ∨ x = new

/-- A fresh viable seed strictly enlarges the old closure; old results remain. -/
theorem closed_but_extendible (T : TypedTransitionSystem X L)
    (seed : X → Prop) (new : X)
    (hv : T.viable new) (hfresh : ¬ C T seed new) :
    Closed T (C T seed) ∧
    Closed T (C T (Extend seed new)) ∧
    (∀ x, C T seed x → C T (Extend seed new) x) ∧
    C T (Extend seed new) new ∧ ¬ C T seed new := by
  exact ⟨closure_is_closed T seed, closure_is_closed T (Extend seed new),
    closure_monotone T (fun _ hx => Or.inl hx),
    closure_extensive T (Extend seed new) (Or.inr rfl) hv, hfresh⟩

/-- Operational progress is separate from logical closure. -/
theorem progress_for_every_finite_horizon (S : ContinuationSystem X)
    (henabled : ∀ x, S.viable x → HasViableSuccessor S x) :
    ∀ n x, S.viable x → Survives S n x := by
  intro n
  induction n with
  | zero => exact fun _ hx => hx
  | succ n ih =>
    intro x hx
    rcases henabled x hx with ⟨y, hxy⟩
    exact ⟨y, hxy, ih y hxy.2.2⟩

def deadlock : ContinuationSystem Unit where
  connects := fun _ _ => False
  viable := fun _ => True

/-- A viable current state need not have any operational successor. -/
theorem viable_deadlock : deadlock.viable () ∧ ¬ Survives deadlock 1 () := by
  constructor
  · trivial
  · rintro ⟨y, hxy, _⟩
    exact hxy.2.1

def noRules : TypedTransitionSystem Bool Unit where
  step := fun _ _ _ => False
  viable := fun _ => True

theorem no_rules_closure (seed : Bool → Prop) (x : Bool) :
    C noRules seed x ↔ seed x := by
  constructor
  · rintro ⟨a, labels, ha, ht⟩
    cases labels with
    | nil =>
      rcases ht with ⟨hax, _⟩
      subst a
      exact ha
    | cons label labels =>
      rcases ht with ⟨next, hstep, _⟩
      exact False.elim hstep.transition
  · intro hx
    exact closure_extensive noRules seed hx True.intro

/-- An inhabited, explicit witness: a closed set need not contain every state. -/
theorem strict_extension_witness :
    Closed noRules (C noRules (fun x => x = false)) ∧
    C noRules (Extend (fun x => x = false) true) true ∧
    ¬ C noRules (fun x => x = false) true := by
  constructor
  · exact closure_is_closed noRules _
  · constructor
    · exact closure_extensive noRules _ (Or.inr rfl) True.intro
    · intro h
      have hbad := (no_rules_closure (fun x => x = false) true).mp h
      cases hbad

/-- Bounded digital identity: no claim of cryptographic collision resistance. -/
structure Subject where
  artifact : Nat
  revision : Nat
  policy : Nat
  deriving DecidableEq

structure Receipt where
  subject : Subject
  validated : Prop

def Bound (r : Receipt) (s : Subject) : Prop := r.subject = s ∧ r.validated

theorem no_stale_transfer (r : Receipt) (s t : Subject)
    (h : Bound r s) (hne : s ≠ t) : ¬ Bound r t := by
  intro ht
  exact hne (h.1.symm.trans ht.1)

/-- A transport-only report has a model in which the effect is absent. -/
theorem transport_does_not_imply_effect :
    ¬ (∀ transport effect : Bool, transport = true → effect = true) := by
  intro h
  have impossible := h true false rfl
  cases impossible

/-- Concrete unbounded *model* with a computable successor, not a physical claim. -/
def counterSystem : ContinuationSystem Nat where
  connects := fun x y => y = x + 1
  viable := fun _ => True

theorem counter_finite_progress (n x : Nat) : Survives counterSystem n x := by
  apply progress_for_every_finite_horizon counterSystem
  · intro y _
    exact ⟨y + 1, True.intro, rfl, True.intro⟩
  · trivial

end QIKVRT.Article.EvidenceClosure
