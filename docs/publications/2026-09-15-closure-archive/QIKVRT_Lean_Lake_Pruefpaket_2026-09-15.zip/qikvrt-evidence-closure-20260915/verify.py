"""Rebuild the bounded article proof and record actual kernel/audit outputs.

No remote write, release, or whole-repository verdict is performed.
AI-assisted implementation for Ingolf Lohmann, 2026-09-15.
"""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "evidence"
OUT.mkdir(exist_ok=True)


def digest(path):
    data = path.read_bytes()
    return {"path": str(path.relative_to(ROOT)), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def run(argv, name, expected=0):
    result = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=180)
    output = result.stdout + result.stderr
    log = OUT / (name + ".log")
    log.write_bytes(output)
    record = {"argv": argv, "exit_code": result.returncode, "output": digest(log)}
    if (expected == 0 and result.returncode != 0) or (expected != 0 and result.returncode == 0):
        sys.stderr.write(output.decode("utf-8", errors="replace"))
        raise RuntimeError(f"Unexpected exit code in {name}: {result.returncode}")
    return record, output.decode("utf-8", errors="strict")


commands = []
try:
    lean_path = shutil.which("lean")
    lake_path = shutil.which("lake")
    if not lean_path or not lake_path:
        raise RuntimeError("Lean and Lake must be on PATH; pinned version is 4.19.0")
    rec, version = run(["lean", "--version"], "lean-version")
    commands.append(rec)
    if not re.search(r"version 4\.19\.0(?:\s|,|\))", version):
        raise RuntimeError(f"Wrong Lean version: {version}")
    rec, lake_version = run(["lake", "--version"], "lake-version")
    commands.append(rec)
    source_paths = sorted([ROOT / "EvidenceClosure.lean", ROOT / "Audit.lean",
                           *ROOT.glob("QIKVRTFormalization/Process/*.lean")])
    for path in source_paths:
        text = path.read_text()
        # Compiler-derived axiom audit below is authoritative; this is an extra scan.
        text = re.sub(r"/-.*?-/", "", text, flags=re.S)
        text = re.sub(r"--[^\n]*", "", text)
        if re.search(r"\b(sorry|admit|axiom|native_decide|unsafe)\b", text):
            raise RuntimeError(f"Proof escape token: {path}")
    rec, _ = run(["lake", "clean"], "clean")
    commands.append(rec)
    rec, build = run(["lake", "build"], "lake-build")
    commands.append(rec)
    rec, audit = run(["lake", "env", "lean", "Audit.lean"], "axiom-audit")
    commands.append(rec)
    expected = re.findall(r"^#print axioms (\S+)$", (ROOT / "Audit.lean").read_text(), re.M)
    empty = re.findall(r"^'([^']+)' does not depend on any axioms$", audit, re.M)
    if len(expected) != 17 or sorted(empty) != sorted(expected):
        raise RuntimeError("Axiom audit is missing a theorem or has nonempty dependencies")
    negatives = []
    negative_paths = [ROOT / "negative" / name for name in
                      ("FalseEffect.lean", "FalseProgress.lean", "StaleTransfer.lean")]
    if sorted((ROOT / "negative").glob("*.lean")) != sorted(negative_paths):
        raise RuntimeError("Negative-control fileset differs from the three declared controls")
    for path in negative_paths:
        rec, output = run(["lake", "env", "lean", str(path.relative_to(ROOT))],
                          "negative-" + path.stem, expected=1)
        if "error:" not in output or "unknown module" in output:
            raise RuntimeError("Negative control failed for an unintended environment reason")
        negatives.append(rec)
    manifests = [ROOT / "lean-toolchain", ROOT / "lakefile.toml", ROOT / "lake-manifest.json",
                 ROOT / "verify.py", ROOT / "PROVENANCE.json"]
    before = json.loads((ROOT / "PROVENANCE.json").read_text())
    for item in before["reused_sources"]:
        if digest(ROOT / item["local_path"])["sha256"] != item["sha256"]:
            raise RuntimeError("Reused source differs from bound upstream bytes")
    receipt = {
        "schema": "qikvrt-article-local-kernel-receipt-v1",
        "observed_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "result": "LOCAL_KERNEL_VERIFIED",
        "source_binding": "EXACT_FILESET_SHA256_NOT_A_NEW_GIT_HEAD",
        "upstream_commit": before["upstream_commit"],
        "lean_version": version.strip(), "lake_version": lake_version.strip(),
        "lean_binary_sha256": hashlib.sha256(Path(lean_path).read_bytes()).hexdigest(),
        "lake_binary_sha256": hashlib.sha256(Path(lake_path).read_bytes()).hexdigest(),
        "source_files": [digest(p) for p in source_paths + manifests + negative_paths],
        "compiled_objects": [digest(p) for p in sorted((ROOT / ".lake/build/lib/lean").rglob("*.olean"))],
        "commands": commands, "audited_constants": expected, "axiom_dependencies": [],
        "negative_controls": negatives,
        "new_theorems": 14, "reused_headline_theorems": 3,
        "boundaries": {"peer_review": "NOT_PERFORMED", "approval": "NOT_INFERRED",
                       "push": False, "merge": False, "publication": False,
                       "PASS": False, "FINAL_PASS": False, "EFFECT_ACK_DONE": False,
                       "physical_correspondence": "NOT_ESTABLISHED", "soc_implementation": "NOT_PROVED"}}
    (OUT / "KERNEL_RECEIPT.json").write_text(json.dumps(receipt, indent=2) + "\n")
    (OUT / "VERIFICATION_STATUS.json").write_text(json.dumps({
        "result": "LOCAL_KERNEL_VERIFIED", "receipt": digest(OUT / "KERNEL_RECEIPT.json")
    }, indent=2) + "\n")
    print("LOCAL_KERNEL_VERIFIED: 17 audited constants, empty axiom dependencies, 3 rejected negative controls")
except Exception as exc:
    failure = {"result": "LOCAL_VERIFICATION_FAILED", "error": str(exc), "commands": commands}
    (OUT / "LAST_FAILURE.json").write_text(json.dumps(failure, indent=2) + "\n")
    (OUT / "VERIFICATION_STATUS.json").write_text(json.dumps(failure, indent=2) + "\n")
    print(str(exc), file=sys.stderr)
    sys.exit(1)
