"""Render the scientific article; source and status are intentionally explicit."""
from pathlib import Path
import hashlib
import json
from xml.sax.saxutils import escape
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent / "output" / "pdf"
OUT.mkdir(parents=True, exist_ok=True)
PDF = OUT / "QIKVRT_Abgeschlossen_und_anschlussfaehig_2026-09-15.pdf"
FONTS = Path("/usr/share/fonts/truetype/dejavu")
for name, filename in [("Body", "DejaVuSerif.ttf"), ("BodyBold", "DejaVuSerif-Bold.ttf"),
                       ("Sans", "DejaVuSans.ttf"), ("SansBold", "DejaVuSans-Bold.ttf"),
                       ("Mono", "DejaVuSansMono.ttf")]:
    pdfmetrics.registerFont(TTFont(name, str(FONTS / filename)))
pdfmetrics.registerFontFamily("Body", normal="Body", bold="BodyBold", italic="Body", boldItalic="BodyBold")
pdfmetrics.registerFontFamily("Sans", normal="Sans", bold="SansBold", italic="Sans", boldItalic="SansBold")
NAVY = colors.HexColor("#16334A")
TEAL = colors.HexColor("#00796F")
GRAY = colors.HexColor("#4B5563")
LIGHT = colors.HexColor("#EAF3F3")
STYLES = {
    "body": ParagraphStyle("Body", fontName="Body", fontSize=10.1, leading=15.3, spaceAfter=8, textColor=colors.HexColor("#17212B")),
    "title": ParagraphStyle("Title", fontName="SansBold", fontSize=28, leading=34, textColor=NAVY, spaceAfter=14),
    "sub": ParagraphStyle("Sub", fontName="Sans", fontSize=13, leading=19, textColor=GRAY, spaceAfter=14),
    "h1": ParagraphStyle("H1", fontName="SansBold", fontSize=19, leading=25, textColor=NAVY, spaceAfter=14),
    "h2": ParagraphStyle("H2", fontName="SansBold", fontSize=11.7, leading=17, textColor=TEAL, spaceBefore=7, spaceAfter=7),
    "small": ParagraphStyle("Small", fontName="Sans", fontSize=8.5, leading=12, spaceAfter=7, textColor=GRAY),
    "cell": ParagraphStyle("Cell", fontName="Sans", fontSize=8.3, leading=11.7, spaceAfter=0),
    "code": ParagraphStyle("Code", fontName="Mono", fontSize=8.4, leading=13.2, spaceAfter=9, textColor=NAVY),
    "formula": ParagraphStyle("Formula", fontName="Sans", fontSize=11.1, leading=17, spaceAfter=11, leftIndent=12, textColor=NAVY),
}
story = []
text_export = []


def p(text, style="body"):
    story.append(Paragraph(text, STYLES[style]))
    text_export.append(text)


def page(title):
    if story:
        story.append(PageBreak())
    p(title, "h1")


def box(text):
    table = Table([[Paragraph(text, STYLES["body"])]], colWidths=[475])
    table.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), LIGHT),
                               ("BOX", (0, 0), (-1, -1), .6, TEAL),
                               ("LEFTPADDING", (0, 0), (-1, -1), 12),
                               ("RIGHTPADDING", (0, 0), (-1, -1), 12),
                               ("TOPPADDING", (0, 0), (-1, -1), 10),
                               ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    story.extend([table, Spacer(1, 11)])
    text_export.append(text)


def table(rows, widths):
    data = [[Paragraph(escape(str(cell)), STYLES["cell"]) for cell in row] for row in rows]
    tab = Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
    tab.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), LIGHT),
                             ("VALIGN", (0, 0), (-1, -1), "TOP"),
                             ("LINEBELOW", (0, 0), (-1, 0), .8, TEAL),
                             ("LINEBELOW", (0, 1), (-1, -1), .3, colors.HexColor("#D5DEE4")),
                             ("LEFTPADDING", (0, 0), (-1, -1), 7),
                             ("RIGHTPADDING", (0, 0), (-1, -1), 7),
                             ("TOPPADDING", (0, 0), (-1, -1), 7),
                             ("BOTTOMPADDING", (0, 0), (-1, -1), 7)]))
    story.extend([tab, Spacer(1, 12)])
    text_export.append("\n".join(" | ".join(row) for row in rows))


p("QIK-VRT  /  WISSENSCHAFTLICHER ARBEITSARTIKEL", "small")
story.append(Spacer(1, 22))
p("Abgeschlossen<br/>und anschlussfähig", "title")
p("Eine bedingte Formalisierung evidenzgebundener Zustandsarchitekturen mit einem Lean/Lake-Prüfpaket", "sub")
p("Ingolf Lohmann: Architekturidee, Ausgangstext und Fragestellung<br/>OpenAI Codex: KI-assistierte Ausarbeitung und neue Formalisierung<br/>15. September 2026 · Version 0.1 · fachlich noch nicht begutachtet", "small")
story.append(Spacer(1, 8))
p("Zusammenfassung", "h2")
p("Kann ein System in sich abgeschlossen und zugleich für neue Erkenntnisse offen sein? Die Antwort hängt davon ab, was abgeschlossen bedeutet. Dieser Artikel trennt den mathematischen Abschluss eines Modellbestands von operativer Fortsetzung, aktueller Evidenz und physischer Wirkung. Für ein explizites Übergangsmodell wird ein Abschlussoperator C über endlichen zulässigen Ableitungen definiert. Seine Monotonie und Idempotenz sowie eine bedingte echte Erweiterung werden elementar hergeleitet. Ein bereits abgeschlossener Bestand ist damit nicht notwendig maximal.")
p("Die Übertragung auf QIK-VRT erfolgt als präzise Architekturinterpretation: Aussagen bleiben an Subjekt und Version gebunden; zulässige Verkettung verlangt passende Schnittstellen. Fortsetzung benötigt eine eigene Nachfolgerannahme. Ein Gegenmodell zeigt, warum bloße Viabilität diese nicht ersetzt. Für Hardware und physische Prozesse bleiben Implementierungs- und Beobachtungskorrespondenz gesonderte Nachweispflichten.")
box("<b>Ausführungsstatus:</b> Der neue Lean-Code und das Prüfpaket sind vorhanden. Der lokale Kernellauf ist am Start der Lean-Umgebung gescheitert, noch vor der Prüfung der neuen Quellen. <b>FORMAL_PENDING_KERNEL</b> ist deshalb der Status dieses Kandidaten. Ein erfolgreicher Lean-Beweis, ein fertiger Chip oder eine Publikationsfreigabe werden nicht behauptet.")
p("Schlagwörter: QIK-VRT; Abschlussoperator; Zustandsübergang; Anschlussfähigkeit; Evidenzbindung; Lean 4; formale Verifikation; Refinement.", "small")

page("1  Fragestellung und Beitrag")
p("1.1  Die produktive Unterscheidung", "h2")
p("Der von Ingolf Lohmann formulierte Ausgangsgedanke verbindet Beobachten, Binden, Handeln und Rückbeobachten zu einem fortsetzbaren Erkenntnisprozess. In der vorliegenden Rekonstruktion bedeutet die Formel Observe → Bind → Act → Readback keine automatische Wahrheitsgarantie. Sie benennt Verpflichtungen: den Ausgangszustand bestimmen, den Bezug einer Handlung festlegen, ihre Zulässigkeit prüfen und anschließend das tatsächlich beobachtete Ergebnis einordnen.")
p("Eine abgeschlossene Begründung kann die Grundlage einer neuen Begründung bilden. Das ist kein Widerspruch, solange Abschluss relativ zu einem bestimmten Bestand, einer Regelmenge und einer Geltungsgrenze verstanden wird. Die Aussage, ein System habe sämtliche relevanten Eigenschaften seiner gesamten Umwelt bewiesen, wäre wesentlich stärker und folgt daraus nicht.")
p("1.2  Drei verschiedene Bedeutungen von Abschluss", "h2")
table([["Begriff", "Präzise Bedeutung", "Was daraus nicht folgt"],
       ["Modellabschluss", "Unter festgelegten Regeln entstehen bei erneuter Abschlussbildung keine zusätzlichen Elemente.", "Dass alle möglichen Grundlagen bereits enthalten sind."],
       ["Operativer Abschluss", "Ein abgegrenzter Arbeitsauftrag hat seine definierten Nachweise erbracht.", "Dass jede Folgehandlung zulässig oder ausführbar ist."],
       ["Empirischer Nachweis", "Beobachtungen tragen eine konkret begrenzte Aussage unter offengelegten Messbedingungen.", "Unfehlbarkeit des Sensors oder universelle Kausalität."]], [90, 202, 183])
p("1.3  Einordnung in vorhandene Arbeit", "h2")
p("Das Prüfpaket verwendet unverändert die Repository-Module OperationalContinuation und ConnectabilitySimulation. Dort sind endliche viable Fortsetzung sowie viable Spuren und Simulation bereits definiert. Der neue Zusatz ergänzt die Verkettung solcher Spuren, einen darauf aufgebauten Abschlussoperator und explizite Gegenmodelle. Es wird kein konkurrierendes Übergangsmodell eingeführt. [R1, R2]")
p("Abschlussoperatoren und die Komposition endlicher Übergänge sind etablierte mathematische Konstruktionen. Der Beitrag dieses Artikels ist ihre nachvollziehbare Zuordnung zur vorliegenden QIK-VRT-These, nicht ein Beweis historischer Priorität oder ein Anspruch auf die Erfindung von Rückkopplung. Eine vollständige Neuheitsprüfung gehört nicht zum ausgeführten Umfang.")
p("Auch in verteilten Systemen muss eine reine Zeitordnung von einer durch Prozess- und Nachrichtenbeziehungen definierten Ordnung unterschieden werden. Lamports happens-before-Beziehung liefert hierfür einen klassischen Bezugspunkt; sie beweist jedoch keine beliebige physische Ursache-Wirkungs-Behauptung. [R5]")

page("2  Modell und Begriffe")
p("Seien X und L Typen von Zuständen beziehungsweise Bezeichnungen. Ein System T besteht aus einer Relation step : X × L × X → Prop und einem Prädikat viable : X → Prop. Ein gültiger Einzelschritt verlangt Viabilität an beiden Endpunkten und eine gültige Übergangsrelation.")
p("ValidStep(x, l, y) ⇔ viable(x) ∧ step(x, l, y) ∧ viable(y).", "formula")
p("Das vorhandene Modell ViableTrace(T, x, w, y) beschreibt eine endliche Spur mit der Bezeichnungsfolge w. Die leere Spur verlangt x = y und viable(x). Eine nichtleere Spur besteht aus einem gültigen Schritt und einer gültigen Restspur. Es handelt sich um ein Modellprädikat, nicht um eine Behauptung, die beschriebene Ausführung sei tatsächlich geschehen.")
p("2.1  Abschluss eines Anfangsbestands", "h2")
p("Für einen Anfangsbestand S, dargestellt als Prädikat auf X, definieren wir:")
p("C<sub>T</sub>(S)(x) ⇔ ∃ a, w: S(a) ∧ ViableTrace(T, a, w, x).", "formula")
p("C enthält genau die von S aus durch endliche viable Spuren ableitbaren Elemente. Wird T als Regelgraph interpretiert, ist dies ein Abschluss unter diesen Regeln. Wird T als operatives Modell interpretiert, beschreibt C mögliche Modellzustände. Beides darf nicht mit einer Sammlung bereits gemessener Wirkungen gleichgesetzt werden.")
p("Die Domäne für einen extensiven Abschlussoperator sind hier die Bestände S mit S ⊆ V, wobei V die Menge viabler Zustände ist. Diese Einschränkung ist notwendig: Ein nichtviabler Anfangszustand besitzt im verwendeten Modell nicht einmal eine gültige leere Spur.")
p("2.2  Fixpunkt und Erweiterung", "h2")
p("Closed<sub>T</sub>(E) ⇔ ∀ x: C<sub>T</sub>(E)(x) ↔ E(x).", "formula")
p("Das Wort Fixpunkt bezeichnet ausschließlich diese Gleichheit von Prädikaten im extensionalen Sinn. Es bezeichnet weder ein selbstbestätigendes Programm noch einen abgeschlossenen Nachweis über die Welt. Die Lean-Fassung verwendet punktweise Äquivalenz, sodass keine Gleichheit von Funktionen zusätzlich benötigt wird.")
p("Extend(S, z)(x) ⇔ S(x) ∨ x = z.", "formula")
p("Eine echte Erweiterung benötigt ein viables z außerhalb des bisherigen Abschlusses. Ob ein solches z existiert und als neue empirische Grundlage angenommen werden darf, ist eine eigene Frage. Der Erweiterungssatz setzt es voraus; er erzeugt es nicht aus dem Begriff Abschluss.")

page("3  Abschlusssatz und Beweise")
p("Satz 1: Verkettung", "h2")
p("Aus ViableTrace(T, a, u, b) und ViableTrace(T, b, v, c) folgt ViableTrace(T, a, u ++ v, c). Beweis: Induktion über u. Für die leere Spur ist a = b, und die zweite Spur genügt. Im nichtleeren Fall bleibt der erste gültige Schritt erhalten; die Induktionsannahme verkettet die erste Restspur mit v. Entscheidend ist der identische Anschlusspunkt b, nicht bloß ein späterer Zeitstempel.")
p("Satz 2: Abschlussoperator", "h2")
p("Für viable Anfangsbestände gilt S ⊆ C(S). Der Zeuge ist die leere Spur am jeweiligen Anfangselement. Aus S ⊆ S′ folgt C(S) ⊆ C(S′): Dieselben Anfangs- und Spurzeugen bleiben gültig. Außerdem liegen alle Elemente von C(S) in V, weil jede viable Spur an einem viablen Zustand endet.")
p("C(C(S)) = C(S).", "formula")
p("Beweis der Idempotenz: Ein Element von C(C(S)) wird von einem Zwischenzustand b erreicht, der selbst von S erreichbar ist. Satz 1 verkettet beide endlichen Spuren zu einer Spur von S. Umgekehrt liegt jedes x aus C(S) über die leere Spur wieder in C(C(S)), da x viable ist. Damit ist C(S) ein Fixpunkt von C.")
p("Satz 3: Abgeschlossen und dennoch echt erweiterbar", "h2")
box("Seien z ∈ V und z ∉ C(S). Dann sind C(S) und C(S ∪ {z}) beide abgeschlossen, und es gilt:<br/><br/><b>C(S) ist eine echte Teilmenge von C(S ∪ {z}).</b>")
p("Beweis: Beide Bestände sind nach Satz 2 Fixpunkte. Monotonie erhält jedes bisherige Element. Die leere Spur zeigt z ∈ C(S ∪ {z}); die Voraussetzung z ∉ C(S) zeigt, dass die Inklusion echt ist. Damit ist der behauptete Zusammenhang für dieses Modell hergeleitet. Die Voraussetzungen bleiben Teil der Aussage.")
p("Ein konkreter Zeuge ist X = {false, true}, viable stets wahr und step stets falsch. Dann ist C(S) = S. Der Bestand {false} ist abgeschlossen und lässt sich zu {false, true} echt erweitern. Der Zeuge widerlegt die Gleichsetzung von abgeschlossen mit maximal; er belegt nicht, dass jede Erweiterung operativ sinnvoll ist.")
p("Lean-Zuordnung: trace_append; closure_extensive; closure_monotone; closure_viable; closure_idempotent; closure_is_closed; closed_but_extendible; no_rules_closure; strict_extension_witness. Der aktuelle Status dieser neuen Quellen ist FORMAL_PENDING_KERNEL.", "small")

page("4  Fortsetzung ist eine eigene Pflicht")
p("Der Abschlussoperator beantwortet eine Mengenfrage. Ob ein technischer Prozess weiterlaufen kann, ist eine andere Frage. Das wiederverwendete ContinuationSystem besitzt eine Verbindungsrelation connects und ein Viabilitätsprädikat. Eine viable Verbindung verlangt viable(x), connects(x,y) und viable(y). [R1]")
p("Survives(0, x) ⇔ viable(x).<br/>Survives(n+1, x) ⇔ ∃ y: ViableConnection(x,y) ∧ Survives(n,y).", "formula")
p("Satz 4: Bedingte endliche Fortsetzbarkeit", "h2")
p("Angenommen, jeder viable Zustand besitzt mindestens einen viablen Nachfolger. Dann gilt für jedes endliche n und jeden viablen Anfangszustand x: Survives(n,x). Beweis: Induktion über n. Der Nullfall ist die Viabilitätsvoraussetzung. Im Nachfolgerfall liefert die Annahme einen viablen Anschluss y; auf y wird die Induktionsannahme angewandt.")
p("∀ x ∈ V: ∃ y: ViableConnection(x,y)<br/>⇒ ∀ n ∈ ℕ, x ∈ V: Survives(n,x).", "formula")
p("Dies ist kein Satz über die tatsächliche Laufzeit eines realen Rechners. Er garantiert auch nicht, dass eine konkrete Auswahlstrategie den vorhandenen Nachfolger findet. Unbeschränkte reale Ausführung würde zusätzliche Ressourcen-, Umgebungs- und gegebenenfalls Fairnessbedingungen benötigen. Der Unterschied zwischen beliebig langen endlichen Möglichkeiten und einem real ausgeführten unendlichen Prozess bleibt bestehen.")
p("Gegenmodell: der sichere Stillstand", "h2")
p("Das Modell deadlock hat einen einzigen Zustand (), viable ist wahr, connects stets falsch. Damit ist der Zustand viable, aber Survives(1,()) falsch. Die Implikation ‚lokale Gültigkeit bedeutet nächste zulässige Handlung‘ ist folglich ohne Zusatzannahme ungültig. Ein owner-bound HOLD kann praktisch genau diese Grenze ausdrücken: Der bisherige Nachweis bleibt erhalten, während eine nächste Handlung noch nicht zugelassen ist.")
p("Nichtleerer Fortsetzungszeuge", "h2")
p("Im Modell counterSystem ist X = ℕ, jeder Zustand viable und y genau dann Nachfolger von x, wenn y = x+1. Die Nachfolgerannahme wird hier durch die konkrete Funktion x ↦ x+1 erfüllt. Für jedes endliche n folgt die entsprechende Modellfortsetzung. Dieser Zeuge verhindert eine ausschließlich unerfüllbare Voraussetzung im Beispiel; er zertifiziert keinen physischen Zähler und keinen Chip.")
p("Die wiederverwendeten Simulationssätze zeigen zusätzlich: Werden Viabilität und Schritte unter einer Relation erhalten, lassen sich endliche viable Spuren übertragen. Das verbindet Modelle unter expliziten Bedingungen. Es beweist nicht, dass zwei beliebige Implementierungen dieselbe Bedeutung besitzen. [R2]")

page("5  Identität, Evidenz und Wirkung")
p("5.1  Zustandsbindung ist keine globale Behauptung", "h2")
p("Der Zusatzcode modelliert ein Subjekt als Tupel aus Artefakt-, Revisions- und Policy-Kennung. Ein Receipt trägt dieses Subjekt und ein Validierungsprädikat. Bound(r,s) bedeutet: Die Subjektkennung stimmt exakt überein, und das Validierungsprädikat gilt. Die Validierung selbst bleibt eine Voraussetzung; das Modell prüft keinen Sensor, keinen Hashalgorithmus und keine reale Unterschrift.")
p("Bound(r,s) ∧ s ≠ t ⇒ ¬Bound(r,t).", "formula")
p("Beweis: Wäre dasselbe Receipt zugleich an t gebunden, ergäben beide Gleichheiten s = t, im Widerspruch zur Voraussetzung. In der Praxis verhindert dieser Typ von Bedingung, dass ein Head-spezifischer Nachweis allein wegen eines grünen Status auf einen anderen Head übertragen wird. Die Architektur muss die Vergleichsdaten tatsächlich prüfen und darf den Check nicht nur als frei setzbares Feld annehmen.")
p("Nichtübertragbarkeit eines Receipts bedeutet nicht, dass bei jeder Änderung alle Beweise verworfen werden. Ein expliziter Nachweis der Unverändertheit des relevanten Teilumfangs kann Wiederverwendung rechtfertigen. Dann trägt dieser zusätzliche Nachweis die Übertragung. Bloße Versionsähnlichkeit genügt nicht.")
p("5.2  Transport ist schwächer als Wirkung", "h2")
p("Die universelle Formel ‚für beliebige Bool-Werte transport und effect folgt aus transport = true auch effect = true‘ ist falsch. Der Zeuge transport = true, effect = false genügt. Diese elementare Negativaussage bildet die Architekturgrenze TRANSPORT_ACK ≠ EFFECT_ACK ab; sie ersetzt noch keine technische Spezifikation eines Übertragungsprotokolls.")
p("5.3  Rückbeobachtung ist notwendig, aber nicht allein hinreichend", "h2")
p("Ein Aktor kann einen Befehl empfangen haben, ohne die gewünschte Wirkung zu erzeugen. Umgekehrt kann die gewünschte Wirkung nach dem Befehl auch aus einer anderen Ursache eintreten. Deshalb muss eine belastbare Wirkungsbehauptung neben einer passenden Rückbeobachtung den richtigen Gegenstand, ein zulässiges Zeitfenster, die Messbedingungen und konkurrierende Erklärungen berücksichtigen.")
p("Für ein einfaches Messmodell y = H(x) + η kann eine Schranke |η| ≤ ε Bestandteil der Annahmen sein. Die zusätzliche Aussage ‚die beobachtete Abweichung liegt innerhalb ε‘ ist nur so belastbar wie die Referenzbindung und die empirische Rechtfertigung dieser Schranke. Lean könnte die bedingte Folgerung prüfen, aber ε nicht ohne Messdaten für ein konkretes Gerät beglaubigen.")
p("Evidenzgraphen ordnen somit Begründungen. Dass eine Kante technisch gespeichert wurde, beweist noch nicht, dass die physische Kausalbeziehung, die sie bezeichnet, zutrifft.")

page("6  Anschluss an Hardware und SoC")
p("Die gemeinsame Beschreibung von Hardware und Software als Zustandsübergangssystem liefert eine mögliche Abstraktionsschnittstelle. Sie macht die Implementierungen nicht identisch. Ein Prozessorzustand, ein Softwareprozess und ein Messwert besitzen unterschiedliche Beobachtungs- und Fehlergrenzen. Gerade diese Grenzen müssen in einer tragfähigen Komposition explizit bleiben.")
p("Für eine SoC-Realisierung von QIK-VRT ist zunächst eine konkrete, endliche und effektiv auswertbare Instanz des Kontrollkerns festzulegen. Der generische Lean-Typ Nat oder ein beliebiges Prädikat in Prop bezeichnet weder automatisch begrenzte Register noch eine synthetisierbare Schaltung. Die These ‚dieser konkrete Kern ist realisierbar‘ verlangt einen Implementierungszeugen und eine passende Verfeinerungsrelation.")
table([["Nachweisstufe", "Erforderliches Ergebnis", "Hier erbracht?"],
       ["Abstrakter Vertrag", "Zustände, Bedingungen, Übergänge und Grenzen explizit modellieren.", "Ja, für den begrenzten Artikelumfang."],
       ["Lean-Kernel", "Genau diese neuen Quellen ohne unbelegte Beweisannahmen prüfen.", "Nein: Startfehler der Umgebung."],
       ["Implementierung", "Endliche Datenpfade und eine konkrete RTL-/Programminstanz mit Refinement.", "Nein; kein Chip geliefert."],
       ["Synthese / Timing", "Ressourcen, Takt, Reset, Nebenläufigkeit und Fehlerpfade für ein Ziel prüfen.", "Nein."],
       ["Realer Effekt", "Frischen unabhängigen Readback der konkreten Hardware oder des Clients binden.", "Nein."]], [100, 240, 135])
p("Bei einer sicherheitsbezogenen Verfeinerung muss insbesondere jeder mögliche relevante Implementierungsschritt durch das abstrakte Modell gedeckt sein. Die Gegenrichtung - ein Implementierungsmodell kann jeden geforderten Spezifikationsschritt nachbilden - betrifft dagegen die Realisierbarkeit des geforderten Verhaltens. Eine einzelne Simulationsrichtung darf nicht stillschweigend für beide Ansprüche stehen.")
p("Ein geeigneter Weg wäre, den begrenzten Kontrollkern zunächst in ausführbarer Form zu definieren, die Übergangstabelle gegen die Spezifikation zu vergleichen, den RTL-Entwurf zu verfeinern und anschließend Synthese sowie Hardware-Readback zu binden. Testanzahlen müssen dabei klar als Zustände, Assertions, Testfälle oder Ausführungsläufe ausgewiesen werden. Viele Tests eines Referenzmodells beweisen nicht sämtliche Eigenschaften eines Transputers.")
p("Ein IP-bootfähiges Image würde zusätzlich Manifest, Format, Zielarchitektur, Integrität, sicheren Empfang, Startverhalten und den tatsächlich beobachteten Clientzustand benötigen. Dieser Artikel erzeugt kein solches Image und keine dafür gültige Download-URL.")

page("7  Reproduzierbarkeit und Ausführung")
p("7.1  Exakter Quellumfang", "h2")
p("Das Paket enthält EvidenceClosure.lean mit 14 neuen Theoremen, zwei unveränderte Repository-Module, Audit.lean mit 17 ausgewählten Konstanten und drei absichtlich ungültige Negativkontrollen. Die drei zusätzlich auditierten bestehenden Hauptsätze heißen FIT001_checked, FIT002_checked und FIT003_checked. Diese Zahlen beschreiben den vorbereiteten Quellumfang, keine erfolgreichen Prüfresultate.")
p("Upstream: Goldkelch/qik-vrt<br/>Commit: a86054139b49c13c5cd344753b248b46b5daf66f<br/>Lean: leanprover/lean4:v4.19.0<br/>Lake-Abhängigkeiten: nur die mitgelieferte Std-Bibliothek", "small")
p("PROVENANCE.json bindet die übernommenen Dateien mittels SHA-256. Der neue Zusatz ist über seine eigenen Dateien gebunden, nicht über den Upstream-Commit: Dieser Commit enthält die neuen Sätze nicht. Die Veröffentlichung älterer Belege ersetzt keinen neuen Kernellauf.")
p("7.2  Vorgesehener ausführbarer Prüfweg", "h2")
p("lean --version<br/>lake --version<br/>python3 verify.py", "code")
p("verify.py verlangt Version 4.19.0, führt lake clean und lake build aus und ruft danach lake env lean Audit.lean auf. Es verlangt für alle 17 Konstanten vollständige Berichte mit leerer Axiomenabhängigkeit. Die falschen Progress-, Stale-Transfer- und Effect-Dateien müssen mit einem sachbezogenen Lean-Fehler scheitern. Nur bei vollständigem Erfolg wird ein neues KERNEL_RECEIPT.json mit Quellen-, Binär-, Objekt- und Logbindungen erzeugt. [R3, R4]")
box("<b>Tatsächlich beobachtet:</b><br/>lean --version: Exitcode 1; ‚failed to locate application‘.<br/>lake build mit angegebenem LEAN_SYSROOT: Exitcode 1; ‚could not detect the configuration of the Lake installation‘.<br/><br/>Der Fehler liegt vor der Prüfung des neuen Quelltexts. Es gibt deshalb weder einen erfolgreichen neuen Build noch einen bestätigten Axiom-Audit oder ausgeführte Negativkontrollen.")
p("Die offizielle Distribution wurde lokal entpackt; ihr beobachteter SHA-256 steht in PROVENANCE.json. Da die Release-API keinen eigenen Digest lieferte, ist dieser Hash eine Bytebindung, kein unabhängiger Authentizitätsnachweis. Zugriffssperren wurden nicht umgangen.")
p("Erst ein erfolgreicher Lauf in einer regulär ausführbaren Lean-4.19.0-Umgebung kann den offenen Kernelstatus ändern. Lake organisiert den Build; den Beleg liefern die geprüften Terme samt Voraussetzungen. [R3]")

page("8  Aussagebilanz und offene Arbeit")
table([["ID", "Hauptaussage", "Nachweis / Status"],
       ["EC-01", "Passende finite Spuren sind verkettbar.", "Induktionsbeweis im Text; Lean-Kandidat trace_append."],
       ["EC-02", "C ist auf viablen Beständen extensiv, monoton und idempotent.", "Herleitung in Abschnitt 3; neuer Kernelstatus offen."],
       ["EC-03", "Ein frisches viables Element erlaubt echte Erweiterung abgeschlossener Bestände.", "Bedingter Satz; Existenz des frischen Elements vorausgesetzt."],
       ["EC-04", "Viable Nachfolger an jedem viablen Zustand tragen jeden endlichen Fortsetzungshorizont.", "Bedingter Induktionsbeweis; kein realer Unendlichkeitsbeweis."],
       ["EC-05", "Viabilität allein garantiert keine Fortsetzung.", "Explizites Einzustands-Gegenmodell."],
       ["EC-06", "Ein exakt gebundenes Receipt überträgt sich nicht automatisch auf ein anderes Subjekt.", "Gleichheitsargument; keine neue Kryptografie."],
       ["EC-07", "Transportbestätigung impliziert nicht generell den gewünschten Effekt.", "Bool-Gegenmodell; physische Zuordnung separat."],
       ["EC-08", "Ein konkretes QIK-VRT-SoC ist vollständig realisiert und geprüft.", "Nicht hergeleitet, nicht implementiert, nicht behauptet."]], [44, 231, 200])
p("8.1  Ergebnis", "h2")
p("Die präzise mathematische These ist tragfähig: Unter expliziten Regeln kann ein Bestand abgeschlossen sein und nach Hinzunahme einer neuen zulässigen Grundlage einen echt größeren abgeschlossenen Bestand erzeugen. Abgeschlossenheit ist relativ; sie ist keine Behauptung von Allwissenheit. Die Aussage ist durch die angegebenen Beweise begründet, während ihre neue maschinelle Bestätigung in dieser Umgebung aussteht.")
p("8.2  Was vor einer weitergehenden Aussage fehlt", "h2")
p("Zuerst fehlen der erfolgreiche neue Kernellauf und die fachliche Prüfung, ob Definitionen und Voraussetzungen den beabsichtigten QIK-VRT-Anspruch angemessen abbilden. Für reale Systeme fehlen anschließend konkrete Verfeinerungs- und Messbelege. Physikalische Allgemeingültigkeit, unabhängige Reproduktion und wissenschaftlicher Konsens folgen weder aus dem Ausgangstext noch aus einer möglichen Kernelannahme.")
p("Push, PR, Review, Approval, Merge und Publication sind jeweils eigene Vorgänge. PASS, FINAL_PASS und EFFECT_ACK_DONE sind getrennt zu evaluierende, scope-gebundene Zustände. Dieses lokale Artikelpaket setzt keinen dieser Zustände. Die Abgabe an den Auftraggeber ist keine Zenodo-Publikation und kein Peer Review.")

page("9  Quellen und Beitragsprovenienz")
references = [
    ("R1", "Lohmann, I. (2026): OperationalContinuation.lean. QIK-VRT, unveränderter Quellauszug am angegebenen Commit. Definitionen von ViableConnection und Survives sowie FIT-001.", "https://github.com/Goldkelch/qik-vrt/blob/a86054139b49c13c5cd344753b248b46b5daf66f/formalization/QIKVRT_Formalization_v2.0/QIKVRTFormalization/Process/OperationalContinuation.lean"),
    ("R2", "Lohmann, I. (2026): ConnectabilitySimulation.lean. Derselbe Commit. TypedTransitionSystem, ViableTrace und die Simulationssätze FIT-002/3.", "https://github.com/Goldkelch/qik-vrt/blob/a86054139b49c13c5cd344753b248b46b5daf66f/formalization/QIKVRT_Formalization_v2.0/QIKVRTFormalization/Process/ConnectabilitySimulation.lean"),
    ("R3", "Lean Language Reference, Version 4.19.0: Build Tools and Distribution / Lake. Offizielle Dokumentation des Buildwerkzeugs. Abgerufen am 15.09.2026.", "https://lean-lang.org/doc/reference/4.19.0/Build-Tools-and-Distribution/Lake/"),
    ("R4", "Theorem Proving in Lean 4: Axioms and Computation. Offizielle Darstellung von logischer Grundlage, zusätzlichen Axiomen und Rechenbedeutung. Abgerufen am 15.09.2026.", "https://lean-lang.org/theorem_proving_in_lean4/Axioms-and-Computation/"),
    ("R5", "Lamport, L. (1978): Time, Clocks, and the Ordering of Events in a Distributed System. Communications of the ACM 21(7), 558-565. Autorenseitig bereitgestellte Fassung.", "https://lamport.azurewebsites.net/pubs/time-clocks.pdf"),
    ("R6", "Lean 4, offizielle Release-Distribution v4.19.0. Quelle des lokal bereitgestellten Linux-Laufzeitsystems; Herkunft und beobachteter Hash im Begleitpaket.", "https://github.com/leanprover/lean4/releases/tag/v4.19.0"),
]
for key, desc, url in references:
    p(f"<b>[{key}]</b> {escape(desc)}", "small")
    p(f'<link href="{url}" color="#00796F">Quelle öffnen</link>', "small")
p("Beitrags- und Rechtehinweis", "h2")
p("Ingolf Lohmann hat das QIK-VRT-Konzept, den Ausgangsartikel und die hier bearbeitete Fragestellung geliefert. OpenAI Codex hat die neue Präzisierung, den Lean-Zusatz, den Prüfharness und diese Artikelfassung erzeugt. Diese Trennung ist eine Herkunftsangabe und kein Nachweis historischer Priorität. Eine fachliche Annahme des neuen Kandidaten durch Ingolf Lohmann wird nicht vorweggenommen.")
p("Die zwei wiederverwendeten Lean-Dateien behalten ihre Apache-2.0-Dateihinweise; der zugehörige Lizenztext ist im Paket enthalten. Durch diesen Artikel werden keine weiteren Rechte an anderen Repository-Bestandteilen eingeräumt. Das Begleitpaket enthält außerdem CHANGE_NOTICE.md, damit die Präzisierungen gegenüber den stärkeren Formulierungen der Ausgangsdiskussion sichtbar bleiben.")
p("Zitiervorschlag", "h2")
p("Lohmann, Ingolf (Konzept); OpenAI Codex (KI-assistierte Ausarbeitung): Abgeschlossen und anschlussfähig. Eine bedingte Formalisierung evidenzgebundener Zustandsarchitekturen mit einem Lean/Lake-Prüfpaket. Arbeitsartikel, Version 0.1, 15.09.2026. Unbegutachteter Kandidat; neuer Kernelstatus offen.", "small")


def chrome(c, doc):
    c.saveState()
    w, h = A4
    c.setStrokeColor(TEAL)
    c.setLineWidth(.6)
    c.line(60, h - 42, w - 60, h - 42)
    c.setFont("Sans", 7.5)
    c.setFillColor(GRAY)
    c.drawString(60, h - 32, "QIK-VRT  |  Abgeschlossen und anschlussfähig")
    c.drawString(60, 31, "Arbeitsartikel v0.1  ·  Neuer Lean-Kernelstatus offen  ·  15.09.2026")
    c.drawRightString(w - 60, 31, str(doc.page))
    c.restoreState()


doc = SimpleDocTemplate(str(PDF), pagesize=A4, rightMargin=60, leftMargin=60,
                        topMargin=63, bottomMargin=55,
                        title="QIK-VRT: Abgeschlossen und anschlussfähig",
                        author="Ingolf Lohmann (Konzept); OpenAI Codex (KI-assistierte Ausarbeitung)",
                        subject="Bedingte Formalisierung; neuer Lean-Kernelstatus offen")
doc.build(story, onFirstPage=chrome, onLaterPages=chrome)
(ROOT / "ARTICLE_TEXT.html").write_text("\n\n".join(text_export), encoding="utf-8")
print(PDF)
print(hashlib.sha256(PDF.read_bytes()).hexdigest())
