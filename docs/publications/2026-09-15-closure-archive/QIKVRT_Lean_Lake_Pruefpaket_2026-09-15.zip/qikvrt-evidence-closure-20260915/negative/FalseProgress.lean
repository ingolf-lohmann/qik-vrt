import EvidenceClosure
open QIKVRT.Article.EvidenceClosure
open QIKVRT.V2.OperationalContinuation
theorem rejected_progress : Survives deadlock 1 () := by
  exact True.intro
