import EvidenceClosure
open QIKVRT.Article.EvidenceClosure
theorem rejected_stale (r : Receipt) (s t : Subject) (h : Bound r s) :
    Bound r t := by
  exact h
