import EvidenceClosure
theorem rejected_effect : (false : Bool) = true := by
  rfl
