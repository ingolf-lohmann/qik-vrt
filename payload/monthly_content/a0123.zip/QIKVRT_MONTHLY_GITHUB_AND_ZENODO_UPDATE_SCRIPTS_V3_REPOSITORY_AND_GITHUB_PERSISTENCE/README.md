# QIKVRT Monthly GitHub + Zenodo Update Scripts V1

**Urheber:** Ingolf Lohmann  
**Zweck:** Update-Skriptpaket für die Persistenz der QIKVRT-Erkenntnisarbeit des letzten Monats.

Dieses Paket erzeugt zwei getrennte technische Update-Wege:

1. **GitHub-Update:** sämtliche lokalen PDFs und sämtliche lokale Erkenntnisarbeit des angegebenen Monats werden inventarisiert, gehasht, in ein GitHub-Staging-Repository kopiert, geprüft und optional gepusht.
2. **Zenodo-Update:** wissenschaftliche PDFs werden aus dem Inventar ausgewählt und als einzelne Zenodo-Deposits vorbereitet, hochgeladen und nur bei explizitem `--publish` veröffentlicht.

## Zeitraum-Voreinstellung

```text
2026-05-20 bis 2026-06-20
```

## GitHub

```bash
python tools/qikvrt_update_github.py --source /pfad/zur/qikvrt-arbeit --staging ./QIKVRT_MONTHLY_UPDATE_REPO --since 2026-05-20 --until 2026-06-20 --remote https://github.com/OWNER/REPO.git --branch main --no-push
```

Ohne `--no-push` wird nach bestandener Prüfung gepusht.

## Zenodo

```bash
python tools/qikvrt_update_zenodo_scientific_pdfs.py --source /pfad/zur/qikvrt-arbeit --since 2026-05-20 --until 2026-06-20 --dry-run
```

Veröffentlichung nur explizit:

```bash
python tools/qikvrt_update_zenodo_scientific_pdfs.py --source /pfad/zur/qikvrt-arbeit --since 2026-05-20 --until 2026-06-20 --publish
```

## Prüfung

```bash
python tools/verify_update_script_package.py
```

q.e.d.  
Ingolf Lohmann

## V2 Final Delivery Acceptance

V2 ergänzt die Fehlerklasse `FINAL_DELIVERY_CLAIM_WITHOUT_CONFIRMED_ARTIFACT_GENERATION`.

Keine finale Artefaktbehauptung ist zulässig, bevor Datei, Sidecar, ZIP-Integrität, SHA256-Konsistenz und interner Verifier unmittelbar bestätigt wurden.

## V3: Persistenz der Acceptance-Änderung im Repository und nach GitHub

Diese Version materialisiert die erkannte Fehlerklasse nicht nur in der Antwort, sondern im Repository selbst.

Neue/gesicherte Fehlerklassen:

```text
FINAL_DELIVERY_CLAIM_WITHOUT_CONFIRMED_ARTIFACT_GENERATION
AUSLIEFERUNGSBEHAUPTUNG_OHNE_BESTAETIGTE_ARTEFAKTGENERIERUNG
ACCEPTANCE_CHANGE_NOT_PERSISTED_TO_REPOSITORY_AND_GITHUB
AKZEPTANZ_AENDERUNG_NICHT_IM_REPOSITORY_UND_GITHUB_PERSISTIERT
```

GitHub-Persistenzskript:

```bash
python tools/persist_acceptance_change_to_github.py --repo /pfad/zum/git-repo --branch main
```

Oder mit Remote-Klon:

```bash
python tools/persist_acceptance_change_to_github.py --remote https://github.com/OWNER/REPO.git --branch main
```

Mit `--no-push` wird lokal vorbereitet, aber nicht gepusht.

q.e.d.  
Ingolf Lohmann
