# Status

```text
LOCAL_SCRIPT_PACKAGE_READY_FOR_MONTHLY_UPDATE_USE
```

Zeitraum-Voreinstellung:

```text
2026-05-20 bis 2026-06-20
```

Acceptance-Tests:

```text
MONTHLY_GITHUB_FULL_ARTIFACT_UPDATE_ACCEPTANCE_TEST
ZENODO_SCIENTIFIC_PDF_INDIVIDUAL_DEPOSIT_ACCEPTANCE_TEST
NO_EMBEDDED_SECRET_ACCEPTANCE_TEST
```

Fehlerklassen:

```text
MONTHLY_UPDATE_SOURCE_NOT_INVENTORIZED
MONTHLY_UPDATE_REQUIRED_ARTIFACT_NOT_HASHED
MONTHLY_UPDATE_GITHUB_PUSH_WITHOUT_ACCEPTANCE_PASS
ZENODO_SCIENTIFIC_PDF_NOT_INDIVIDUALIZED
ZENODO_PUBLICATION_WITHOUT_EXPLICIT_PUBLISH_FLAG
EMBEDDED_SECRET_IN_UPDATE_PACKAGE
```

## V2 Final Delivery Acceptance

Aktive zusätzliche Fehlerklasse:

```text
FINAL_DELIVERY_CLAIM_WITHOUT_CONFIRMED_ARTIFACT_GENERATION
```

Keine finale Auslieferung ohne bestätigte Datei, Hash, Verifikation und Link.

## V3 Repository + GitHub Persistence Requirement

Aktiver zusätzlicher Acceptance-Test:

```text
REPOSITORY_AND_GITHUB_PERSISTENCE_OF_ACCEPTANCE_CHANGES_TEST
```

Neue Anschlussfehlerklasse:

```text
ACCEPTANCE_CHANGE_NOT_PERSISTED_TO_REPOSITORY_AND_GITHUB
```

Statusgrenze:

Lokal wurde die Regel im Paket materialisiert und verifiziert.  
Externes GitHub-DONE darf erst behauptet werden, wenn `tools/persist_acceptance_change_to_github.py` gegen ein reales GitHub-Remote erfolgreich gepusht hat und der Remote-Zustand nachvollziehbar ist.

q.e.d.  
Ingolf Lohmann
