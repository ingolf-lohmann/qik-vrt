# Lizenz- und Nutzungsvereinbarung

Urheber und Rechteinhaber: **Ingolf Lohmann**

Sofern nicht ausdrücklich schriftlich anders vereinbart, gilt für die Inhalte dieses Pakets: **CC BY-NC-ND 4.0**.

Kommerzielle oder institutionelle Nutzung erfordert eine gesonderte Vereinbarung mit Ingolf Lohmann oder einer von ihm benannten juristischen Person.

Die Skripte dienen der lokalen Inventarisierung, Prüfung, Persistenzvorbereitung und optionalen Veröffentlichung. Sie speichern keine Zugangsdaten.

q.e.d.  
Ingolf Lohmann
