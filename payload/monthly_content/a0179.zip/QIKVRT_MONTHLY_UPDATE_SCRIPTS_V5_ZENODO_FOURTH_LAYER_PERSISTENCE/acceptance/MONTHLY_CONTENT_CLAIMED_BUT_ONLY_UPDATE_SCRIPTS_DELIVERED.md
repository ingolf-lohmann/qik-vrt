# MONTHLY_CONTENT_CLAIMED_BUT_ONLY_UPDATE_SCRIPTS_DELIVERED

Deutsch:

`MONATSINHALT_BEHAUPTET_ABER_NUR_UPDATE_SKRIPTE_GELIEFERT`

## Befund

Das zuvor gelieferte Paket `QIKVRT_MONTHLY_GITHUB_AND_ZENODO_UPDATE_SCRIPTS_V3_REPOSITORY_AND_GITHUB_PERSISTENCE.zip` enthielt nach harter Prüfung:

```text
PDF count = 0
QIKVRT_MONTHLY_ARTIFACT_MANIFEST.json = nicht vorhanden
ZIP-Integrität = PASS
Repository-Struktur = vorhanden
Monatscontent = nicht enthalten
```

Damit war es ein Update-Skriptpaket, aber kein Paket, das den tatsächlichen Content des letzten Monats enthält.

## Fehlerklasse

`MONTHLY_CONTENT_CLAIMED_BUT_ONLY_UPDATE_SCRIPTS_DELIVERED`

## Bedeutung

Wenn der Nutzer ein Update-Skript oder Paket verlangt, das „sämtliche PDFs und sämtliche Erkenntnisarbeit des letzten Monats enthält“, darf nicht ausgeliefert oder behauptet werden, dass der Monatscontent enthalten sei, wenn nur Skripte zur späteren Inventarisierung enthalten sind.

## Drei-Schichten-Persistenzpflicht

Diese Erkenntnis muss in drei Schichten persistiert werden:

1. **Arbeits-/Memory-Schicht:** als dauerhafte Regel.
2. **Repository-Schicht:** als Acceptance-Test, Audit-Finding, Manifest, SHA256SUMS und Verifier-Regel.
3. **GitHub-Persistenzschicht:** als Skript und Workflow, mit dem die Regel in ein reales GitHub-Repository übertragen werden kann.

## Neue Acceptance-Regel

Ein Paket, das Monatscontent beansprucht, muss mindestens eine der folgenden Bedingungen erfüllen:

```text
A) Content-Modus:
   PDF_count > 0
   QIKVRT_MONTHLY_ARTIFACT_MANIFEST.json vorhanden
   alle Monatsartefakte physisch im Paket oder Staging enthalten
   SHA256SUMS deckt alle Monatsartefakte ab

ODER

B) Script-only-Modus:
   Paket bezeichnet sich ausdrücklich nur als Update-Skriptpaket
   Paket behauptet nicht, Monatscontent zu enthalten
   Paket enthält einen Runtime-Acceptance-Test, der beim realen Lauf den Monatscontent inventarisiert
```

Wenn A nicht erfüllt ist, darf das Paket nicht als „enthält sämtliche PDFs und Erkenntnisarbeit des letzten Monats“ beschrieben werden.

## Merksatz

Ein Update-Skript zur späteren Sammlung ist kein Monatscontent-Paket.

q.e.d.  
Ingolf Lohmann
