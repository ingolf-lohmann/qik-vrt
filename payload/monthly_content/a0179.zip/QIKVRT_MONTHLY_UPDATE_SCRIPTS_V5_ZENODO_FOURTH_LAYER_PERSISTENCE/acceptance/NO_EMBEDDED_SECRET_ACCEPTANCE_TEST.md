# NO_EMBEDDED_SECRET_ACCEPTANCE_TEST

Dieses Paket darf keine GitHub- oder Zenodo-Tokens, privaten Schlüssel oder eingebetteten Zugangsdaten enthalten.

Fehlerklasse: `EMBEDDED_SECRET_IN_UPDATE_PACKAGE`.

q.e.d. Ingolf Lohmann
