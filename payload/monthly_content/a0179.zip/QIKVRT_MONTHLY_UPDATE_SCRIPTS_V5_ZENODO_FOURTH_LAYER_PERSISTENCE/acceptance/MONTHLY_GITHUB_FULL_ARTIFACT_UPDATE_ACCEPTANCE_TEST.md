# MONTHLY_GITHUB_FULL_ARTIFACT_UPDATE_ACCEPTANCE_TEST

Kein GitHub-Update ohne vollständige Monatsinventur.

GitHub-Update-PASS ist nur zulässig, wenn der Quellordner existiert, alle passenden lokalen Artefakte des Zeitraums inventarisiert sind, alle PDFs als Pflichtartefakte geführt werden, alle Erkenntnisarbeitsdateien klassifiziert sind, jedes Artefakt SHA256-gehasht ist, jedes Artefakt im Monatsmanifest steht und der GitHub-Push erst nach bestandenem Acceptance-Test erfolgt.

Fehlerklassen: `MONTHLY_UPDATE_SOURCE_NOT_INVENTORIZED`, `MONTHLY_UPDATE_REQUIRED_ARTIFACT_NOT_HASHED`, `MONTHLY_UPDATE_GITHUB_PUSH_WITHOUT_ACCEPTANCE_PASS`, `CLAIMED_OR_REQUIRED_ARTIFACT_NOT_FULLY_INCLUDED`.

q.e.d. Ingolf Lohmann
