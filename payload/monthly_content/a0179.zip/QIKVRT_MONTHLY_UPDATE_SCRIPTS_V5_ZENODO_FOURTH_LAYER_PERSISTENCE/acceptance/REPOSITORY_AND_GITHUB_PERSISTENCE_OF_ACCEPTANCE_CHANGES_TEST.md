# REPOSITORY_AND_GITHUB_PERSISTENCE_OF_ACCEPTANCE_CHANGES_TEST

## Zweck

Diese Regel stellt sicher, dass eine erkannte Acceptance-Test-Änderung nicht nur in einer Chat-Antwort genannt wird, sondern zweifach persistiert wird:

1. im Repository selbst,
2. im GitHub-Repository, sobald ein reales Remote-Ziel angegeben und der Push erfolgreich ausgeführt wurde.

## Ausgangsfehlerklasse

`FINAL_DELIVERY_CLAIM_WITHOUT_CONFIRMED_ARTIFACT_GENERATION`

Deutsch:

`AUSLIEFERUNGSBEHAUPTUNG_OHNE_BESTAETIGTE_ARTEFAKTGENERIERUNG`

## Neue Anschlussfehlerklasse

`ACCEPTANCE_CHANGE_NOT_PERSISTED_TO_REPOSITORY_AND_GITHUB`

Deutsch:

`AKZEPTANZ_AENDERUNG_NICHT_IM_REPOSITORY_UND_GITHUB_PERSISTIERT`

## Regel

Wenn eine Acceptance-Test-Regel, Fehlerklasse oder finale Auslieferungsregel geändert oder ergänzt wird, gilt:

```text
Acceptance-Änderung erkannt
=> Repository-Datei angelegt oder aktualisiert
=> Manifest aktualisiert
=> SHA256SUMS aktualisiert
=> Verifier prüft neue Regel
=> GitHub-Persistenzskript vorhanden
=> GitHub-Push nur nach erfolgreicher lokaler Prüfung
=> GitHub-DONE erst nach realem Push + erfolgreichem Remote-Workflow
```

## PASS-Bedingungen

Ein lokales Repository-PASS ist nur zulässig, wenn:

1. Diese Datei im Repository enthalten ist.
2. `FINAL_DELIVERY_CLAIM_WITHOUT_CONFIRMED_ARTIFACT_GENERATION` enthalten ist.
3. `ACCEPTANCE_CHANGE_NOT_PERSISTED_TO_REPOSITORY_AND_GITHUB` enthalten ist.
4. `tools/persist_acceptance_change_to_github.py` vorhanden ist.
5. Manifest und SHA256SUMS aktualisiert sind.
6. Der Verifier diese Marker prüft.
7. Die finale Antwort nur behauptet, was lokal tatsächlich geprüft wurde.
8. Externes GitHub-DONE nur bei echtem Push und nachvollziehbarem Remote-Ergebnis behauptet wird.

## Merksatz

Eine Acceptance-Änderung ist erst dann anschlussfähig, wenn sie im Repository selbst materialisiert und für GitHub-Persistenz ausführbar gemacht ist.

q.e.d.  
Ingolf Lohmann
