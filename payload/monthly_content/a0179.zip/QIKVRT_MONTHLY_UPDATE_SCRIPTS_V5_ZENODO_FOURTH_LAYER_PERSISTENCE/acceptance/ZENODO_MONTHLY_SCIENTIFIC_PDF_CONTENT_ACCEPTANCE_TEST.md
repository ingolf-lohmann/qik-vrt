# ZENODO_MONTHLY_SCIENTIFIC_PDF_CONTENT_ACCEPTANCE_TEST

## Zweck

Dieser Acceptance-Test ergänzt die vierte Persistierungsschicht: Zenodo.

Wenn wissenschaftliche PDFs des letzten Monats für Zenodo genannt, vorbereitet, persistiert oder veröffentlicht werden sollen, reicht ein allgemeines Upload-Skript nicht aus. Es muss entweder der wissenschaftliche PDF-Content physisch enthalten sein oder ein geprüftes Zenodo-Monatsmanifest mit Einzeldeposit-Plan je PDF vorliegen.

## Fehlerklasse

`ZENODO_SCIENTIFIC_PDF_CONTENT_CLAIM_NOT_MATERIALIZED`

Deutsch:

`ZENODO_WISSENSCHAFTLICHER_PDF_INHALT_BEHAUPTET_ABER_NICHT_MATERIALISIERT`

## Regel

Zenodo-Persistenz wissenschaftlicher PDFs ist nur zulässig, wenn:

```text
wissenschaftliche_PDFs_ausgewählt
=> PDF_count > 0
=> je PDF eigener Deposit-Plan
=> je PDF eigener Metadatenblock
=> je PDF SHA256 fixiert
=> keine Tokens im Paket
=> Veröffentlichung nur mit explizitem --publish
=> Zenodo-DONE nur mit echter DOI/Record-URL
```

## Nicht zulässig

Nicht zulässig ist:

```text
Zenodo-Upload-Skript vorhanden
aber
keine wissenschaftlichen PDFs inventarisiert
und
kein geprüfter Einzeldeposit-Plan vorhanden
```

Das ist nur eine Upload-Möglichkeit, aber keine Zenodo-Persistenz wissenschaftlicher PDFs.

## Vier-Schichten-Persistenzpflicht

Bei diesem Fehler sind vier Schichten zu sichern:

1. Memory-/Arbeitsregel.
2. Repository-Schicht.
3. GitHub-Persistenzschicht.
4. Zenodo-Persistenzschicht.

## Merksatz

Zenodo-Skript ohne wissenschaftliche PDFs oder geprüften Einzeldeposit-Plan ist keine Zenodo-Persistenz wissenschaftlicher PDFs.

q.e.d.  
Ingolf Lohmann
