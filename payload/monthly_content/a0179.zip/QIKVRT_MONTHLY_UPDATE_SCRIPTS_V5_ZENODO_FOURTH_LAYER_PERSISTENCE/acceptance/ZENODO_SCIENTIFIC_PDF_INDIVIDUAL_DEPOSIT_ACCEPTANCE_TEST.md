# ZENODO_SCIENTIFIC_PDF_INDIVIDUAL_DEPOSIT_ACCEPTANCE_TEST

Ein wissenschaftliches PDF bedeutet ein eigener Zenodo-Record.

Für jedes wissenschaftliche PDF gilt: PDF vorhanden, wissenschaftlich klassifiziert, SHA256 fixiert, eigener Zenodo-Metadatenblock, eigener Deposit-Plan, Upload einzeln, Veröffentlichung nur mit `--publish`.

Fehlerklassen: `ZENODO_SCIENTIFIC_PDF_NOT_INDIVIDUALIZED`, `ZENODO_PUBLICATION_WITHOUT_EXPLICIT_PUBLISH_FLAG`, `CLAIMED_ZENODO_ARTIFACT_NOT_INCLUDED`.

q.e.d. Ingolf Lohmann
