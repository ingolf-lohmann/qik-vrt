$ErrorActionPreference = "Stop"
python tools\qikvrt_update_zenodo_scientific_pdfs.py @args
