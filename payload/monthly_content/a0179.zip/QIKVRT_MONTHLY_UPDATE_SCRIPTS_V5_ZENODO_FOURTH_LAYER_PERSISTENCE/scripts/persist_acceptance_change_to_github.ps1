$ErrorActionPreference = "Stop"
python tools\persist_acceptance_change_to_github.py @args
