#!/usr/bin/env bash
set -euo pipefail
python3 tools/qikvrt_update_github.py "$@"
