#!/usr/bin/env bash
set -euo pipefail
python3 tools/persist_acceptance_change_to_github.py "$@"
