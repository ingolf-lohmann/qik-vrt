$ErrorActionPreference = "Stop"
python tools\qikvrt_update_github.py @args
