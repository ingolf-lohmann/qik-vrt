$ErrorActionPreference = "Stop"
python tools\persist_zenodo_fourth_layer_to_github.py @args
