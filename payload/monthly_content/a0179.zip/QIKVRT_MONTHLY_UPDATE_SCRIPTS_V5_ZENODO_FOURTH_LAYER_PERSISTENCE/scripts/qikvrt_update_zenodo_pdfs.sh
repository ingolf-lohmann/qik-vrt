#!/usr/bin/env bash
set -euo pipefail
python3 tools/qikvrt_update_zenodo_scientific_pdfs.py "$@"
