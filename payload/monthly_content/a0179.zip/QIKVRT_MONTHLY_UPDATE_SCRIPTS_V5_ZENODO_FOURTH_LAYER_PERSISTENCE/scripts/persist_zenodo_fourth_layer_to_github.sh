#!/usr/bin/env bash
set -euo pipefail
python3 tools/persist_zenodo_fourth_layer_to_github.py "$@"
