$ErrorActionPreference = "Stop"
python tools\persist_monthly_content_acceptance_failure_to_github.py @args
