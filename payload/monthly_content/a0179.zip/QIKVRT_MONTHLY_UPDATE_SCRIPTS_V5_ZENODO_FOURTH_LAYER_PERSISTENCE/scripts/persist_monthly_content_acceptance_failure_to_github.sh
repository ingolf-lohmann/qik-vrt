#!/usr/bin/env bash
set -euo pipefail
python3 tools/persist_monthly_content_acceptance_failure_to_github.py "$@"
