#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import pathlib
import sys

SCIENTIFIC_KEYWORDS = [
    "quantengravitation",
    "quanten",
    "quantum",
    "gravitation",
    "raumzeit",
    "spacetime",
    "physik",
    "physics",
    "beweis",
    "skript",
    "semester",
]

def sha256_file(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for c in iter(lambda: f.read(1024 * 1024), b""):
            h.update(c)
    return h.hexdigest()

def is_scientific_pdf(path: pathlib.Path, all_pdfs: bool = False) -> bool:
    if path.suffix.lower() != ".pdf":
        return False
    if all_pdfs:
        return True
    name = path.name.lower()
    return any(k in name for k in SCIENTIFIC_KEYWORDS)

def main() -> int:
    parser = argparse.ArgumentParser(description="Create a Zenodo monthly scientific PDF individual-deposit plan.")
    parser.add_argument("--source", required=True)
    parser.add_argument("--output", default="QIKVRT_ZENODO_MONTHLY_SCIENTIFIC_PDF_PLAN.json")
    parser.add_argument("--all-pdfs", action="store_true")
    args = parser.parse_args()

    source = pathlib.Path(args.source).resolve()
    if not source.is_dir():
        print("FAIL source folder missing", file=sys.stderr)
        return 1

    pdfs = sorted([p for p in source.rglob("*.pdf") if is_scientific_pdf(p, args.all_pdfs)], key=lambda p: p.as_posix().lower())
    if not pdfs:
        print("FAIL ZENODO_SCIENTIFIC_PDF_CONTENT_CLAIM_NOT_MATERIALIZED: no scientific PDFs selected", file=sys.stderr)
        return 1

    plan = {
        "schema": "qikvrt_zenodo_monthly_scientific_pdf_plan_v1",
        "created_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "acceptance_test": "ZENODO_MONTHLY_SCIENTIFIC_PDF_CONTENT_ACCEPTANCE_TEST",
        "separate_deposit_per_pdf": True,
        "publish_requires_explicit_flag": True,
        "pdf_count": len(pdfs),
        "deposits": []
    }

    for idx, pdf in enumerate(pdfs, 1):
        title = pdf.stem.replace("_", " ").replace("-", " ")
        plan["deposits"].append({
            "deposit_id": f"monthly_scientific_pdf_{idx:03d}",
            "source_path": str(pdf),
            "filename": pdf.name,
            "bytes": pdf.stat().st_size,
            "sha256": sha256_file(pdf),
            "expected_files_per_deposit": 1,
            "metadata": {
                "metadata": {
                    "title": title,
                    "upload_type": "publication",
                    "publication_type": "book",
                    "description": "Wissenschaftliches QIKVRT-PDF. Einzeldeposit. Veröffentlichung nur mit explizitem --publish.\\n\\nq.e.d. Ingolf Lohmann",
                    "creators": [{"name": "Lohmann, Ingolf", "affiliation": "Independent researcher"}],
                    "license": "cc-by-nc-nd-4.0",
                    "keywords": ["QIKVRT", "Quantengravitation", "wissenschaftliches PDF", "Quantenphysik", "Raumzeit"]
                }
            }
        })

    pathlib.Path(args.output).write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"PASS Zenodo monthly scientific PDF plan created: {args.output}")
    print(f"PDF count: {len(pdfs)}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
