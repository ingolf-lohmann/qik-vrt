from __future__ import annotations
import datetime as dt, hashlib, json, pathlib, shutil
from dataclasses import dataclass
DEFAULT_CONFIG=pathlib.Path(__file__).resolve().parents[1]/'config'/'qikvrt_update_config.json'
@dataclass(frozen=True)
class Artifact:
    source_path:pathlib.Path; relative_path:str; size_bytes:int; sha256:str; modified_utc:str; artifact_class:str; role:str
def load_config(path=None): return json.loads((pathlib.Path(path) if path else DEFAULT_CONFIG).read_text(encoding='utf-8'))
def parse_date(value, fallback): return dt.datetime.fromisoformat(value or fallback).replace(tzinfo=dt.timezone.utc)
def file_modified_utc(path): return dt.datetime.fromtimestamp(path.stat().st_mtime, tz=dt.timezone.utc)
def sha256_file(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for c in iter(lambda:f.read(1024*1024), b''): h.update(c)
    return h.hexdigest()
def is_excluded(path, exclude_dirs): return any(x in path.parts for x in exclude_dirs)
def classify(path,cfg):
    s=path.suffix.lower()
    if s=='.pdf': return 'pdf','required_pdf_artifact'
    if s in set(cfg['github']['research_work_extensions']): return 'research_work','monthly_research_artifact'
    return 'supporting_artifact','supporting_file'
def discover_artifacts(source,since,until,cfg,include_all=False):
    source=source.resolve(); inc=set(x.lower() for x in cfg['github']['include_extensions']); ex=cfg['github'].get('exclude_dirs',[]); out=[]
    for path in source.rglob('*'):
        if not path.is_file() or is_excluded(path,ex) or path.suffix.lower() not in inc: continue
        mt=file_modified_utc(path)
        if not include_all and not (since <= mt <= until + dt.timedelta(days=1)): continue
        ac,role=classify(path,cfg); rel=path.relative_to(source).as_posix()
        out.append(Artifact(path,rel,path.stat().st_size,sha256_file(path),mt.strftime('%Y-%m-%dT%H:%M:%SZ'),ac,role))
    return sorted(out,key=lambda a:(a.artifact_class,a.relative_path.lower()))
def safe_copy_artifacts(artifacts,source,staging):
    payload=staging/'payload'
    if payload.exists(): shutil.rmtree(payload)
    payload.mkdir(parents=True,exist_ok=True)
    for a in artifacts:
        dst=payload/a.relative_path; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(a.source_path,dst)
def write_sha256sums(staging):
    lines=[]
    for p in sorted([p for p in staging.rglob('*') if p.is_file() and '.git' not in p.parts], key=lambda p:p.relative_to(staging).as_posix()):
        if p.name=='SHA256SUMS.txt': continue
        lines.append(f'{sha256_file(p)}  {p.relative_to(staging).as_posix()}')
    (staging/'SHA256SUMS.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
def write_staging_manifest(staging,artifacts,since,until):
    m={'schema':'qikvrt_monthly_artifact_manifest_v1','since':since,'until':until,'artifact_count':len(artifacts),'pdf_count':sum(1 for a in artifacts if a.artifact_class=='pdf'),'research_work_count':sum(1 for a in artifacts if a.artifact_class=='research_work'),'artifacts':[{'source_path':str(a.source_path),'payload_path':'payload/'+a.relative_path,'relative_path':a.relative_path,'size_bytes':a.size_bytes,'sha256':a.sha256,'modified_utc':a.modified_utc,'artifact_class':a.artifact_class,'role':a.role} for a in artifacts]}
    (staging/'QIKVRT_MONTHLY_ARTIFACT_MANIFEST.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8')
def verify_staging(staging):
    mp=staging/'QIKVRT_MONTHLY_ARTIFACT_MANIFEST.json'; sp=staging/'SHA256SUMS.txt'
    if not mp.is_file(): return False,'MONTHLY_UPDATE_SOURCE_NOT_INVENTORIZED: manifest missing'
    if not sp.is_file(): return False,'MONTHLY_UPDATE_REQUIRED_ARTIFACT_NOT_HASHED: SHA256SUMS missing'
    m=json.loads(mp.read_text(encoding='utf-8')); arts=m.get('artifacts',[])
    if not arts: return False,'MONTHLY_UPDATE_SOURCE_NOT_INVENTORIZED: no artifacts discovered'
    sums={}
    for line in sp.read_text(encoding='utf-8').splitlines():
        if line.strip(): expected,path=line.split(maxsplit=1); sums[path.strip()]=expected
    for e in arts:
        pp=e['payload_path']; p=staging/pp
        if not p.is_file(): return False,'CLAIMED_OR_REQUIRED_ARTIFACT_NOT_FULLY_INCLUDED: '+pp
        if sha256_file(p)!=e['sha256']: return False,'MONTHLY_UPDATE_REQUIRED_ARTIFACT_NOT_HASHED: '+pp
        if sums.get(pp)!=e['sha256']: return False,'MONTHLY_UPDATE_REQUIRED_ARTIFACT_NOT_HASHED: SHA256SUMS '+pp
    return True,'PASS'
def scientific_pdf_filter(a,cfg): return a.artifact_class=='pdf' and any(k.lower() in a.relative_path.lower() for k in cfg['zenodo']['scientific_pdf_keywords'])
