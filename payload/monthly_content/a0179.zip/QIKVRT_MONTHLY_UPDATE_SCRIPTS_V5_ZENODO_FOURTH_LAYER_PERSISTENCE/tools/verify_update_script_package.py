#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
REQ=['README.md','LICENSE_NOTICE.md','STATUS.md','config/qikvrt_update_config.json','acceptance/MONTHLY_GITHUB_FULL_ARTIFACT_UPDATE_ACCEPTANCE_TEST.md','acceptance/ZENODO_SCIENTIFIC_PDF_INDIVIDUAL_DEPOSIT_ACCEPTANCE_TEST.md','acceptance/NO_EMBEDDED_SECRET_ACCEPTANCE_TEST.md','tools/common_qikvrt_update.py','tools/qikvrt_update_github.py','tools/qikvrt_update_zenodo_scientific_pdfs.py','tools/verify_update_script_package.py','scripts/qikvrt_update_github.sh','scripts/qikvrt_update_github.ps1','scripts/qikvrt_update_zenodo_pdfs.sh','scripts/qikvrt_update_zenodo_pdfs.ps1','.github/workflows/verify-update-scripts.yml','REPOSITORY_FILE_MANIFEST.json','SHA256SUMS.txt']
TEXT=['MONTHLY_GITHUB_FULL_ARTIFACT_UPDATE_ACCEPTANCE_TEST','ZENODO_SCIENTIFIC_PDF_INDIVIDUAL_DEPOSIT_ACCEPTANCE_TEST','NO_EMBEDDED_SECRET_ACCEPTANCE_TEST','MONTHLY_UPDATE_SOURCE_NOT_INVENTORIZED','ZENODO_PUBLICATION_WITHOUT_EXPLICIT_PUBLISH_FLAG','EMBEDDED_SECRET_IN_UPDATE_PACKAGE','Ingolf Lohmann']
def fail(m): print('FAIL '+m,file=sys.stderr); return 1
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1024*1024), b''): h.update(c)
 return h.hexdigest()
def files(): return [p for p in ROOT.rglob('*') if p.is_file() and '.git' not in p.parts]
def token_markers(): return ['gh'+'p_','github'+'_pat_','zenodo'+'_pat_','-----BEGIN '+'PRIVATE KEY-----','access'+'_'+'token=']
def main():
    missing=[p for p in REQ if not (ROOT/p).is_file()]
    if missing: return fail('missing required files: '+', '.join(missing))
    combined=''
    for p in files():
        if p.name=='SHA256SUMS.txt': continue
        try: combined+='\n'+p.read_text(encoding='utf-8')
        except UnicodeDecodeError: pass
    for marker in token_markers():
        if marker in combined: return fail('embedded secret marker found')
    for marker in TEXT:
        if marker not in combined: return fail('required text marker not found: '+marker)
    cfg=json.loads((ROOT/'config/qikvrt_update_config.json').read_text(encoding='utf-8'))
    if not cfg.get('default_since') or not cfg.get('default_until'): return fail('default date range missing')
    sums={}
    for line in (ROOT/'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
        if line.strip(): expected,path=line.split(maxsplit=1); sums[path.strip()]=expected
    for path,expected in sums.items():
        p=ROOT/path
        if not p.is_file(): return fail('SHA256SUMS covers missing file: '+path)
        if sha(p)!=expected: return fail('SHA256SUMS mismatch: '+path)
    for req in REQ:
        if req not in {'SHA256SUMS.txt','REPOSITORY_FILE_MANIFEST.json'} and req not in sums: return fail('required file not covered by SHA256SUMS: '+req)
    manifest=json.loads((ROOT/'REPOSITORY_FILE_MANIFEST.json').read_text(encoding='utf-8')); paths={e.get('path') for e in manifest.get('files',[])}
    for req in REQ:
        if req!='REPOSITORY_FILE_MANIFEST.json' and req not in paths: return fail('required file not in file manifest: '+req)
    print('PASS QIKVRT monthly update script package verification'); return 0
if __name__=='__main__': raise SystemExit(main())
