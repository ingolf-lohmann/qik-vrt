#!/usr/bin/env python3
from __future__ import annotations

import json
import pathlib
import sys
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[1]

REQUIRED_MARKERS = [
    "MONTHLY_CONTENT_CLAIMED_BUT_ONLY_UPDATE_SCRIPTS_DELIVERED",
    "MONATSINHALT_BEHAUPTET_ABER_NUR_UPDATE_SKRIPTE_GELIEFERT",
    "Ein Update-Skript zur späteren Sammlung ist kein Monatscontent-Paket",
]

def fail(msg: str) -> int:
    print("FAIL " + msg, file=sys.stderr)
    return 1

def main() -> int:
    acceptance = ROOT / "acceptance" / "MONTHLY_CONTENT_CLAIMED_BUT_ONLY_UPDATE_SCRIPTS_DELIVERED.md"
    audit = ROOT / "audit" / "V3_MONTHLY_CONTENT_ACCEPTANCE_FAILURE_REPORT.json"
    github_script = ROOT / "tools" / "persist_monthly_content_acceptance_failure_to_github.py"

    for p in [acceptance, audit, github_script]:
        if not p.is_file():
            return fail(f"required persistence file missing: {p.relative_to(ROOT)}")

    text = acceptance.read_text(encoding="utf-8")
    for marker in REQUIRED_MARKERS:
        if marker not in text:
            return fail(f"required marker missing: {marker}")

    report = json.loads(audit.read_text(encoding="utf-8"))
    if report.get("result") != "FAIL":
        return fail("audit report must preserve FAIL result")
    if report.get("pdf_count") != 0:
        return fail("audit report must preserve pdf_count=0 for V3 failure")
    if report.get("monthly_manifest_present") is not False:
        return fail("audit report must preserve missing monthly manifest finding")

    print("PASS monthly content claim acceptance failure persisted")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
