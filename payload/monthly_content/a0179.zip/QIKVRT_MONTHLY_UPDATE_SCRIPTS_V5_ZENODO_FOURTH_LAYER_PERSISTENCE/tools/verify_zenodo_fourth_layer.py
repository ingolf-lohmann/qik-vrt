#!/usr/bin/env python3
from __future__ import annotations

import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]

REQUIRED_FILES = [
    "acceptance/ZENODO_MONTHLY_SCIENTIFIC_PDF_CONTENT_ACCEPTANCE_TEST.md",
    "audit/V4_ZENODO_FOURTH_LAYER_ACCEPTANCE_FINDING.json",
    "tools/verify_zenodo_fourth_layer.py",
    "tools/persist_zenodo_fourth_layer_to_github.py",
    "tools/qikvrt_create_zenodo_monthly_scientific_pdf_plan.py",
]

REQUIRED_MARKERS = [
    "ZENODO_MONTHLY_SCIENTIFIC_PDF_CONTENT_ACCEPTANCE_TEST",
    "ZENODO_SCIENTIFIC_PDF_CONTENT_CLAIM_NOT_MATERIALIZED",
    "ZENODO_WISSENSCHAFTLICHER_PDF_INHALT_BEHAUPTET_ABER_NICHT_MATERIALISIERT",
    "Zenodo-Skript ohne wissenschaftliche PDFs oder geprüften Einzeldeposit-Plan ist keine Zenodo-Persistenz wissenschaftlicher PDFs",
]

def fail(msg: str) -> int:
    print("FAIL " + msg, file=sys.stderr)
    return 1

def main() -> int:
    for rel in REQUIRED_FILES:
        if not (ROOT / rel).is_file():
            return fail(f"required Zenodo fourth-layer file missing: {rel}")

    text = ""
    for rel in REQUIRED_FILES:
        try:
            text += "\n" + (ROOT / rel).read_text(encoding="utf-8")
        except UnicodeDecodeError:
            pass

    for marker in REQUIRED_MARKERS:
        if marker not in text:
            return fail(f"required marker missing: {marker}")

    finding = json.loads((ROOT / "audit/V4_ZENODO_FOURTH_LAYER_ACCEPTANCE_FINDING.json").read_text(encoding="utf-8"))
    if finding.get("missing_layer") != "Zenodo scientific PDF persistence layer":
        return fail("audit finding does not preserve Zenodo missing layer")
    if finding.get("result") != "FAIL_AS_INCOMPLETE_PERSISTENCE_LAYER_COVERAGE":
        return fail("audit finding does not preserve failure result")

    print("PASS Zenodo fourth-layer acceptance persistence verified")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
