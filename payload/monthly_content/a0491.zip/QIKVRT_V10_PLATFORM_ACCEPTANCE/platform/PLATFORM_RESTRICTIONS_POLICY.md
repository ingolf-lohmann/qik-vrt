# Target Platform Restrictions Policy

## Windows

```text
max_relative_path_length = 180
max_path_component_length = 80
```

Verboten in Pfadkomponenten:

```text
< > : " / \ | ? *
ASCII-Control-Zeichen 0x00-0x1F
abschließende Leerzeichen
abschließende Punkte
reservierte Namen: CON, PRN, AUX, NUL, COM1..COM9, LPT1..LPT9
```

## macOS/APFS

Paketpfade verwenden ausschließlich portable ASCII-Zeichen:

```text
[A-Z a-z 0-9 . _ - /]
```

Umlaute und Unicode sind im Dateiinhalt zulässig, aber nicht in Pfadnamen dieses Pakets.

## Linux/Unix

Shellskripte verwenden LF-Zeilenenden. Ausführungsbits werden im ZIP dokumentiert, aber der maßgebliche Startpfad bleibt interpreterbasiert:

```bash
python tools/qikvrt_master_acceptance_gate.py
bash qikvrt.sh master-gate
```

## Runtime

```text
python_min_version = 3.10
dependencies = Python standard library only
network_required_for_local_verification = false
```

## Prüfsummen-Ausnahme

`SHA256SUMS.txt` wird nicht durch sich selbst gehasht. Sie wird durch ZIP-Integrität und ZIP-Sidecar-SHA256 abgesichert.

q.e.d.  
Ingolf Lohmann
