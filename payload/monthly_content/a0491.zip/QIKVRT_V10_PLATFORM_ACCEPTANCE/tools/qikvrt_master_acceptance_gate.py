#!/usr/bin/env python3
from __future__ import annotations

import ast, hashlib, json, pathlib, re, stat, sys, unicodedata

ROOT = pathlib.Path(__file__).resolve().parents[1]
WINDOWS_RESERVED = {"CON","PRN","AUX","NUL",*(f"COM{i}" for i in range(1,10)),*(f"LPT{i}" for i in range(1,10))}
FORBIDDEN_WIN_CHARS = set('<>:"\\|?*')
PORTABLE_PATH_RE = re.compile(r"^[A-Za-z0-9._\-/]+$")
MAX_REL_PATH_LEN = 180
MAX_COMPONENT_LEN = 80

REQUIRED_FILES = [
    "LICENSE_NOTICE.md","README.md","STATUS.md","PACKAGE_MODE.md","SHA256SUMS.txt","REPOSITORY_FILE_MANIFEST.json",
    "platform/PLATFORM_RESTRICTIONS_POLICY.md","platform/RUNTIME_ENVIRONMENT.json",
    "acceptance/TARGET_PLATFORM_RESTRICTIONS_ACCEPTANCE_TEST.md",
    "acceptance/WINDOWS_PATH_LENGTH_ACCEPTANCE_TEST.md",
    "acceptance/WINDOWS_RESERVED_NAMES_AND_CHARS_ACCEPTANCE_TEST.md",
    "acceptance/UNICODE_NORMALIZATION_AND_UMLAUT_ACCEPTANCE_TEST.md",
    "acceptance/CASE_COLLISION_ACCEPTANCE_TEST.md",
    "acceptance/RUNTIME_ENVIRONMENT_ACCEPTANCE_TEST.md",
    "acceptance/LINE_ENDING_AND_ENCODING_ACCEPTANCE_TEST.md",
    "acceptance/ARCHIVE_EXTRACTION_PORTABILITY_ACCEPTANCE_TEST.md",
    "acceptance/ABSOLUTE_PATH_AND_LOCAL_LEAK_ACCEPTANCE_TEST.md",
    "acceptance/COMMAND_QUOTING_AND_SPACE_PATH_ACCEPTANCE_TEST.md",
    "acceptance/CHECKSUM_SELF_REFERENCE_ACCEPTANCE_TEST.md",
]
REQUIRED_MARKERS = [
    "TARGET_PLATFORM_RESTRICTIONS_NOT_ENFORCED","WINDOWS_PATH_LENGTH_LIMIT_NOT_ENFORCED",
    "WINDOWS_RESERVED_NAME_OR_CHARACTER_PRESENT","UNICODE_NORMALIZATION_OR_UMLAUT_PATH_RISK",
    "CASE_INSENSITIVE_PATH_COLLISION","RUNTIME_ENVIRONMENT_REQUIREMENTS_NOT_DECLARED_OR_VERIFIED",
    "LINE_ENDING_OR_ENCODING_NOT_PORTABLE","ARCHIVE_EXTRACTION_PORTABILITY_NOT_VERIFIED",
    "ABSOLUTE_PATH_OR_LOCAL_ENVIRONMENT_LEAK_PRESENT","COMMAND_QUOTING_OR_SPACE_PATH_UNSAFE",
    "CHECKSUM_FILE_SELF_HASH_REQUIRED","COPYRIGHT_AND_LICENSE_COMPLIANCE_NOT_ENFORCED",
    "ACCEPTANCE_COVERAGE_INCOMPLETE",
]

def fail(msg: str) -> int:
    print("FAIL " + msg, file=sys.stderr); return 1
def sha256_file(path: pathlib.Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for c in iter(lambda:f.read(1024*1024), b""): h.update(c)
    return h.hexdigest()
def rel(path: pathlib.Path) -> str: return path.relative_to(ROOT).as_posix()
def iter_files():
    return sorted([p for p in ROOT.rglob("*") if p.is_file() and ".git" not in p.parts and "__pycache__" not in p.parts], key=lambda p: rel(p).lower())
def read(path: pathlib.Path) -> str: return path.read_text(encoding="utf-8")

def check_required_files():
    for r in REQUIRED_FILES:
        if not (ROOT/r).is_file(): return False, f"required file missing: {r}"
    return True, "required files present"

def check_path_policy():
    seen_lower={}; seen_norm={}
    for p in iter_files():
        rp=rel(p)
        if len(rp)>MAX_REL_PATH_LEN: return False, f"relative path too long ({len(rp)}): {rp}"
        if not PORTABLE_PATH_RE.match(rp): return False, f"non-portable path characters: {rp}"
        for comp in rp.split("/"):
            if not comp or len(comp)>MAX_COMPONENT_LEN: return False, f"path component invalid length: {rp}"
            if comp.endswith(" ") or comp.endswith("."): return False, f"Windows trailing space/dot: {rp}"
            if any(ord(ch)<32 for ch in comp): return False, f"control character in path: {rp}"
            if any(ch in FORBIDDEN_WIN_CHARS for ch in comp): return False, f"Windows-forbidden char in path: {rp}"
            if comp.split(".")[0].upper() in WINDOWS_RESERVED: return False, f"Windows reserved name: {rp}"
        low=rp.lower()
        if low in seen_lower and seen_lower[low]!=rp: return False, f"case collision: {seen_lower[low]} vs {rp}"
        seen_lower[low]=rp
        nfc=unicodedata.normalize("NFC", rp)
        nfd=unicodedata.normalize("NFD", rp)
        if rp!=nfc or rp!=nfd: return False, f"non-normalization-stable path: {rp}"
        key=nfc.casefold()
        if key in seen_norm and seen_norm[key]!=rp: return False, f"normalization collision: {seen_norm[key]} vs {rp}"
        seen_norm[key]=rp
    return True, "path policy ok"

def check_text_encoding_line_endings():
    text_exts={".md",".json",".py",".sh",".ps1",".cmd",".bat",".txt",".yml",".yaml"}
    for p in iter_files():
        if p.suffix.lower() in text_exts or p.name in {"README","LICENSE","VERSION"}:
            data=p.read_bytes()
            if data.startswith(b"\xef\xbb\xbf"): return False, f"UTF-8 BOM not allowed: {rel(p)}"
            try: txt=data.decode("utf-8")
            except UnicodeDecodeError: return False, f"text file not UTF-8: {rel(p)}"
            if p.suffix.lower() in {".py",".sh"} and "\r\n" in txt: return False, f"CRLF not allowed in Python/shell: {rel(p)}"
    return True, "encoding and line endings ok"

def check_python_syntax():
    for p in iter_files():
        if p.suffix.lower()==".py":
            try: ast.parse(read(p))
            except SyntaxError as exc: return False, f"Python syntax error in {rel(p)}: {exc}"
    return True, "python syntax ok"

def check_manifest_sha():
    manifest=json.loads(read(ROOT/"REPOSITORY_FILE_MANIFEST.json"))
    manifest_paths={entry.get("path") for entry in manifest.get("files",[])}
    for r in REQUIRED_FILES:
        if r not in manifest_paths: return False, f"required file absent from manifest: {r}"
    sum_map={}
    for line in read(ROOT/"SHA256SUMS.txt").splitlines():
        if line.strip():
            h,path=line.split(maxsplit=1); sum_map[path.strip()]=h
    for r in REQUIRED_FILES:
        if r=="SHA256SUMS.txt": continue
        if r not in sum_map: return False, f"required file absent from SHA256SUMS: {r}"
    if "SHA256SUMS.txt" in sum_map: return False, "SHA256SUMS.txt must not self-hash"
    for path,expected in sum_map.items():
        p=ROOT/path
        if not p.is_file(): return False, f"SHA256SUMS references missing file: {path}"
        if sha256_file(p)!=expected: return False, f"SHA256 mismatch: {path}"
    return True, "manifest and SHA256 ok"

def check_markers_mode_secret():
    text="\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in iter_files() if p.suffix.lower() in {".md",".json",".py",".sh",".ps1",".cmd",".bat",".txt",".yml",".yaml"})
    for marker in REQUIRED_MARKERS:
        if marker not in text: return False, f"required marker missing: {marker}"
    mode=read(ROOT/"PACKAGE_MODE.md")
    if "script_package_with_acceptance_coverage_and_runtime_content_inventory_tools" not in mode: return False, "package mode missing"
    if "kein vollständiges Monatscontent-Paket" not in mode and "not a full monthly content package" not in mode: return False, "monthly content boundary missing"
    for pattern in ["gh"+"p_"+r"[A-Za-z0-9_]{20,}","github"+"_pat_"+r"[A-Za-z0-9_]{20,}","zenodo"+"_pat_"+r"[A-Za-z0-9_]{10,}","-----BEGIN "+"PRIVATE KEY-----","access"+"_token"+r"\s*="]:
        if re.search(pattern, text): return False, "forbidden secret-like pattern found"
    return True, "markers, mode and secret scan ok"

def check_runtime():
    env=json.loads(read(ROOT/"platform/RUNTIME_ENVIRONMENT.json"))
    if tuple(env.get("python_min_version",[])) < (3,10): return False, "python minimum below 3.10"
    if not env.get("python_standard_library_only"): return False, "external dependency declared"
    if env.get("local_verification_requires_network"): return False, "local verification requires network"
    for marker in ["python tools/qikvrt_master_acceptance_gate.py","python qikvrt.py master-gate","qikvrt.cmd master-gate",".\\qikvrt.ps1 master-gate"]:
        if marker not in env.get("required_start_paths",[]): return False, f"runtime start path missing: {marker}"
    if not env.get("path_policy",{}).get("checksum_file_self_hash_excluded"): return False, "checksum self-hash exception not declared"
    return True, "runtime environment ok"

def check_wrappers():
    cmd=read(ROOT/"qikvrt.cmd") if (ROOT/"qikvrt.cmd").is_file() else ""
    bat=read(ROOT/"qikvrt.bat") if (ROOT/"qikvrt.bat").is_file() else ""
    ps1=read(ROOT/"qikvrt.ps1") if (ROOT/"qikvrt.ps1").is_file() else ""
    sh=read(ROOT/"qikvrt.sh") if (ROOT/"qikvrt.sh").is_file() else ""
    for marker in ['"%SCRIPT_DIR%qikvrt.py"',"exit /b %ERRORLEVEL%"]:
        if marker not in cmd: return False, f"qikvrt.cmd missing marker: {marker}"
    if "exit /b %ERRORLEVEL%" not in bat: return False, "qikvrt.bat missing exit propagation"
    for marker in ['"$ScriptDir\\qikvrt.py"',"$LASTEXITCODE"]:
        if marker not in ps1: return False, f"qikvrt.ps1 missing marker: {marker}"
    for marker in ['"$SCRIPT_DIR/qikvrt.py"','exec "$PYTHON_BIN"']:
        if marker not in sh: return False, f"qikvrt.sh missing marker: {marker}"
    return True, "wrapper quoting and exit propagation ok"

def main() -> int:
    for check in [check_required_files,check_path_policy,check_text_encoding_line_endings,check_python_syntax,check_manifest_sha,check_markers_mode_secret,check_runtime,check_wrappers]:
        ok,msg=check()
        if not ok: return fail(msg)
        print("PASS", msg)
    print("PASS QIKVRT master acceptance gate")
    return 0
if __name__=="__main__": raise SystemExit(main())
