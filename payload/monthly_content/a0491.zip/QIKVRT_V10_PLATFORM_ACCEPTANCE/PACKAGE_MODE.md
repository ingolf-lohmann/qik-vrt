# Package Mode Declaration

```text
package_mode = script_package_with_acceptance_coverage_and_runtime_content_inventory_tools
```

Dieses Paket ist ein Skript-, Plattformrestriktions- und Acceptance-Coverage-Paket. Es ist **kein vollständiges Monatscontent-Paket**, solange kein `QIKVRT_MONTHLY_ARTIFACT_MANIFEST.json` und kein entsprechendes Payload-Staging erzeugt wurde.

GitHub-DONE ist erst zulässig mit echter GitHub-Evidenz.  
Zenodo-DONE ist erst zulässig mit echter DOI/Record-URL-Evidenz.

q.e.d.  
Ingolf Lohmann
