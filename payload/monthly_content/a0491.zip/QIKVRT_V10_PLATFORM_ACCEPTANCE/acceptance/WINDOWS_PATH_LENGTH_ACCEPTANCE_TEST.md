# WINDOWS_PATH_LENGTH_ACCEPTANCE_TEST

## Fehlerklasse

`WINDOWS_PATH_LENGTH_LIMIT_NOT_ENFORCED`

Deutsch:

`WINDOWS_PFADLAENGEN_GRENZE_NICHT_ERZWUNGEN`

## Regel

Relative Paketpfade müssen konservativ kurz bleiben, damit Windows-Entpackpfade genügend MAX_PATH-Reserve behalten.

q.e.d.  
Ingolf Lohmann
