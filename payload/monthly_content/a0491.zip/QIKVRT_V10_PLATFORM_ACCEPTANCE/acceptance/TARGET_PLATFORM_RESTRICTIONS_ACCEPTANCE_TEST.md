# TARGET_PLATFORM_RESTRICTIONS_ACCEPTANCE_TEST

## Fehlerklasse

`TARGET_PLATFORM_RESTRICTIONS_NOT_ENFORCED`

Deutsch:

`ZIELPLATTFORM_RESTRIKTIONEN_NICHT_ERZWUNGEN`

## Regel

Windows, macOS und Linux müssen mit Dateisystem-, Pfad-, Unicode-, Shell- und Laufzeitgrenzen geprüft werden.

q.e.d.  
Ingolf Lohmann
