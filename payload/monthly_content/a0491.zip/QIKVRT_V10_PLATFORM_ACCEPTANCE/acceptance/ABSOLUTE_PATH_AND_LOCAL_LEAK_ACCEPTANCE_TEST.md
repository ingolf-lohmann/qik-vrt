# ABSOLUTE_PATH_AND_LOCAL_LEAK_ACCEPTANCE_TEST

## Fehlerklasse

`ABSOLUTE_PATH_OR_LOCAL_ENVIRONMENT_LEAK_PRESENT`

Deutsch:

`ABSOLUTPFAD_ODER_LOKALE_UMGEBUNG_GELEAKT`

## Regel

Keine lokalen absoluten Pfade oder Umgebungsspezifika dürfen als feste Paketvoraussetzung eingebettet sein.

q.e.d.  
Ingolf Lohmann
