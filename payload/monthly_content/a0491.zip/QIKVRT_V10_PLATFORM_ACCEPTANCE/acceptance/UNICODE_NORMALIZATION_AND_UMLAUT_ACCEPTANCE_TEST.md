# UNICODE_NORMALIZATION_AND_UMLAUT_ACCEPTANCE_TEST

## Fehlerklasse

`UNICODE_NORMALIZATION_OR_UMLAUT_PATH_RISK`

Deutsch:

`UNICODE_NORMALISIERUNG_ODER_UMLAUT_PFADRISIKO`

## Regel

Pfade müssen portabel ASCII-basiert sein; Umlaute und Unicode bleiben im Inhalt erlaubt, aber nicht in Dateipfaden.

q.e.d.  
Ingolf Lohmann
