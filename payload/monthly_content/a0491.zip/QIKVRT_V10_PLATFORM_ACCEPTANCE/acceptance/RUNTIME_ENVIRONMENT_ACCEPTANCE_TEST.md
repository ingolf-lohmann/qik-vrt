# RUNTIME_ENVIRONMENT_ACCEPTANCE_TEST

## Fehlerklasse

`RUNTIME_ENVIRONMENT_REQUIREMENTS_NOT_DECLARED_OR_VERIFIED`

Deutsch:

`LAUFZEITUMGEBUNG_NICHT_DEKLARIERT_ODER_GEPRUEFT`

## Regel

Python-Mindestversion, Standardbibliotheksnutzung und Interpreter-Startpfade müssen deklariert und geprüft sein.

q.e.d.  
Ingolf Lohmann
