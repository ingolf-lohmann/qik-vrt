# CASE_COLLISION_ACCEPTANCE_TEST

## Fehlerklasse

`CASE_INSENSITIVE_PATH_COLLISION`

Deutsch:

`GROSS_KLEIN_SCHREIBUNG_PFADKOLLISION`

## Regel

Keine Pfadkollision bei case-insensitive Dateisystemen.

q.e.d.  
Ingolf Lohmann
