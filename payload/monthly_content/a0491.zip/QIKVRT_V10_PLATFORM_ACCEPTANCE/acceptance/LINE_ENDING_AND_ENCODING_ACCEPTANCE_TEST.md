# LINE_ENDING_AND_ENCODING_ACCEPTANCE_TEST

## Fehlerklasse

`LINE_ENDING_OR_ENCODING_NOT_PORTABLE`

Deutsch:

`ZEILENENDEN_ODER_KODIERUNG_NICHT_PORTABEL`

## Regel

Textdateien müssen UTF-8 ohne BOM nutzen; Python- und Shellskripte müssen LF-zeilentauglich sein.

q.e.d.  
Ingolf Lohmann
