# WINDOWS_RESERVED_NAMES_AND_CHARS_ACCEPTANCE_TEST

## Fehlerklasse

`WINDOWS_RESERVED_NAME_OR_CHARACTER_PRESENT`

Deutsch:

`WINDOWS_RESERVIERTER_NAME_ODER_ZEICHEN_VORHANDEN`

## Regel

Windows-reservierte Namen, verbotene Zeichen, Steuerzeichen, abschließende Leerzeichen und Punkte sind in Pfadkomponenten verboten.

q.e.d.  
Ingolf Lohmann
