# ARCHIVE_EXTRACTION_PORTABILITY_ACCEPTANCE_TEST

## Fehlerklasse

`ARCHIVE_EXTRACTION_PORTABILITY_NOT_VERIFIED`

Deutsch:

`ARCHIV_ENTPACKBARKEIT_NICHT_PORTABEL_GEPRUEFT`

## Regel

Das ZIP muss normal entpackbar sein; der Master-Gate muss nach normalem Entpacken per Python-Interpreter laufen.

q.e.d.  
Ingolf Lohmann
