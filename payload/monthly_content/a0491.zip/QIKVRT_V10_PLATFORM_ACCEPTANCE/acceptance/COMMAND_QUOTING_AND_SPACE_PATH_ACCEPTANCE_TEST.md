# COMMAND_QUOTING_AND_SPACE_PATH_ACCEPTANCE_TEST

## Fehlerklasse

`COMMAND_QUOTING_OR_SPACE_PATH_UNSAFE`

Deutsch:

`BEFEHLSQUOTING_ODER_LEERZEICHENPFAD_UNSICHER`

## Regel

Startskripte müssen Leerzeichenpfade quoten und Exit-Codes weitergeben.

q.e.d.  
Ingolf Lohmann
