# CHECKSUM_SELF_REFERENCE_ACCEPTANCE_TEST

## Fehlerklasse

`CHECKSUM_FILE_SELF_HASH_REQUIRED`

Deutsch:

`PRUEFSUMMENDATEI_SELBSTHASH_VERLANGT`

## Regel

SHA256SUMS.txt darf nicht ihren eigenen finalen Inhalt in sich selbst hashen müssen; sie wird über Manifest-Präsenz, ZIP-Integrität und Sidecar abgesichert.

q.e.d.  
Ingolf Lohmann
