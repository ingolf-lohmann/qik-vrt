#!/usr/bin/env python3
from __future__ import annotations
import hashlib
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]

REQUIRED_FILES = [
    "README.md",
    "LICENSE_NOTICE.md",
    "STATUS.md",
    "docs/00_KURZFASSUNG.md",
    "acceptance/GITHUB_THREE_QUANTUM_GRAVITY_PDFS_PERSISTENCE_ACCEPTANCE_TEST.md",
    "github_three_pdf_persistence_plan.json",
    "REPOSITORY_FILE_MANIFEST.json",
    "SHA256SUMS.txt",
    "tools/verify_github_three_pdf_package.py",
    "tools/update_sha256sums.py",
    "tools/persist_to_github.py",
    "scripts/persist_git.sh",
    "scripts/persist_git.ps1",
    ".github/workflows/verify.yml",
]

REQUIRED_TEXT = [
    "GITHUB_THREE_QUANTUM_GRAVITY_PDFS_PERSISTENCE_ACCEPTANCE_TEST",
    "GITHUB_REQUIRED_PDF_ARTIFACT_NOT_INCLUDED",
    "GITHUB_THREE_PDF_PERSISTENCE_NOT_ENFORCED",
    "GITHUB_PERSISTENCE_WITHOUT_FULL_ARTIFACT_BODY",
    "Ingolf Lohmann",
]

def fail(msg: str) -> int:
    print(f"FAIL {msg}", file=sys.stderr)
    return 1

def sha256_file(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def all_files() -> list[pathlib.Path]:
    return [p for p in ROOT.rglob("*") if p.is_file() and ".git" not in p.parts]

def load_sums() -> dict[str, str]:
    sums = {}
    for line in (ROOT / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
        if line.strip():
            expected, path = line.split(maxsplit=1)
            sums[path.strip().lstrip("*")] = expected
    return sums

def main() -> int:
    missing = [p for p in REQUIRED_FILES if not (ROOT / p).is_file()]
    if missing:
        return fail("missing required files: " + ", ".join(missing))

    combined = ""
    for p in all_files():
        if p.name == "SHA256SUMS.txt":
            continue
        try:
            combined += "\n" + p.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            pass
    for marker in REQUIRED_TEXT:
        if marker not in combined:
            return fail(f"required text marker not found: {marker}")

    try:
        plan = json.loads((ROOT / "github_three_pdf_persistence_plan.json").read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(f"github persistence plan invalid: {exc}")

    pdfs = plan.get("required_pdfs", [])
    if plan.get("required_pdf_count") != 3:
        return fail("required_pdf_count must be 3")
    if len(pdfs) != 3:
        return fail(f"expected exactly 3 required PDFs, found {len(pdfs)}")

    paths = []
    hashes = []
    for entry in pdfs:
        path = entry.get("path")
        expected_hash = entry.get("sha256")
        if not path or not expected_hash:
            return fail("PDF entry missing path or sha256")
        p = ROOT / path
        if not p.is_file():
            return fail(f"required PDF missing: {path}")
        if p.suffix.lower() != ".pdf":
            return fail(f"required PDF entry is not a PDF: {path}")
        if p.stat().st_size <= 0:
            return fail(f"required PDF is empty: {path}")
        actual_hash = sha256_file(p)
        if actual_hash != expected_hash:
            return fail(f"required PDF hash mismatch: {path}")
        paths.append(path)
        hashes.append(actual_hash)

    if len(set(paths)) != 3:
        return fail("required PDF paths are not unique")
    if len(set(hashes)) != 3:
        return fail("required PDF hashes are not unique")

    sums = load_sums()
    required = set(REQUIRED_FILES + paths)
    for path, expected in sums.items():
        p = ROOT / path
        if not p.is_file():
            return fail(f"SHA256SUMS covers missing file: {path}")
        if sha256_file(p) != expected:
            return fail(f"SHA256SUMS mismatch: {path}")
    for path in required:
        if path != "SHA256SUMS.txt" and path not in sums:
            return fail(f"required file not covered by SHA256SUMS: {path}")

    manifest = json.loads((ROOT / "REPOSITORY_FILE_MANIFEST.json").read_text(encoding="utf-8"))
    manifest_paths = {entry.get("path") for entry in manifest.get("files", [])}
    for path in required:
        if path != "REPOSITORY_FILE_MANIFEST.json" and path not in manifest_paths:
            return fail(f"required file not in file manifest: {path}")

    print("PASS GitHub three PDF persistence package verification")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
