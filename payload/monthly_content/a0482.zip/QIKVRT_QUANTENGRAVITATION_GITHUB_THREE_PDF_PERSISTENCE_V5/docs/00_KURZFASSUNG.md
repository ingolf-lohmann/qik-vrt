# Kurzfassung

Dieses GitHub-Persistenzpaket stellt sicher, dass alle drei Quantengravitations-PDFs gemeinsam als Pflichtartefakte nach GitHub persistiert werden.

Der zentrale Acceptance-Test verhindert, dass nur Repository-Struktur, README, Verifier oder Kurztexte übertragen werden, während die vollständigen PDF-Artefakte fehlen.

q.e.d.  
Ingolf Lohmann
