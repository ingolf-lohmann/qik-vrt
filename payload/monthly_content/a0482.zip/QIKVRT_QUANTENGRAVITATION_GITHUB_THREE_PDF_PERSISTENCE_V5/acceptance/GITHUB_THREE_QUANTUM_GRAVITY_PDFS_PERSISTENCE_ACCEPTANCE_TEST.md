# GITHUB_THREE_QUANTUM_GRAVITY_PDFS_PERSISTENCE_ACCEPTANCE_TEST

## Zweck

Dieser Acceptance-Test verhindert, dass ein GitHub-Repository als PASS, READY oder DONE gilt, obwohl die drei zentralen Quantengravitations-PDFs nicht vollständig enthalten sind.

## Fehlerklassen

- `GITHUB_REQUIRED_PDF_ARTIFACT_NOT_INCLUDED`
- `GITHUB_THREE_PDF_PERSISTENCE_NOT_ENFORCED`
- `GITHUB_PERSISTENCE_WITHOUT_FULL_ARTIFACT_BODY`

## Regel

Alle drei Quantengravitations-PDFs sind Pflichtartefakte.

Für jedes der drei PDFs gilt:

```text
PDF vorhanden
=> PDF im GitHub-Persistenzplan geführt
=> PDF im Artefaktinventar geführt
=> PDF in SHA256SUMS abgedeckt
=> PDF im Dateimanifest geführt
=> PDF vom Verifier erzwungen
=> GitHub-Persistenz erst danach zulässig
```

## PASS-Bedingungen

Der lokale Package-PASS ist nur zulässig, wenn:

1. Genau drei Pflicht-PDFs im Persistenzplan geführt werden.
2. Jede Pflicht-PDF physisch vorhanden ist.
3. Jede Pflicht-PDF eine eindeutige Datei ist.
4. Jede Pflicht-PDF einen SHA256-Wert im Plan besitzt.
5. Jeder SHA256-Wert mit der Datei übereinstimmt.
6. Jede Pflicht-PDF in `SHA256SUMS.txt` abgedeckt ist.
7. Jede Pflicht-PDF in `REPOSITORY_FILE_MANIFEST.json` geführt wird.
8. Der Verifier diese Bedingungen erzwingt.
9. Das GitHub-Persistenzskript vor Commit und Push den Verifier ausführt.
10. GitHub-Actions denselben Verifier ausführt.

## Merksatz

GitHub-PASS ohne alle drei vollständigen Quantengravitations-PDFs ist kein Repository-PASS.

q.e.d.  
Ingolf Lohmann
