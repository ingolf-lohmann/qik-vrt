# Status

Repository-Zustand:

```text
LOCAL_GITHUB_THREE_PDF_PERSISTENCE_PACKAGE_READY_FOR_VERIFICATION
```

Aktiver Acceptance-Test:

```text
GITHUB_THREE_QUANTUM_GRAVITY_PDFS_PERSISTENCE_ACCEPTANCE_TEST
```

Fehlerklassen:

```text
GITHUB_REQUIRED_PDF_ARTIFACT_NOT_INCLUDED
GITHUB_THREE_PDF_PERSISTENCE_NOT_ENFORCED
GITHUB_PERSISTENCE_WITHOUT_FULL_ARTIFACT_BODY
```

Statusgrenze:

Lokaler PASS bedeutet: Paketstruktur, alle drei PDFs, Manifest, SHA256SUMS, Skripte und GitHub-Workflow sind lokal konsistent.  
GitHub DONE ist erst zulässig, wenn der Push gegen ein echtes Remote erfolgt ist und der GitHub-Actions-Workflow dort erfolgreich läuft.

q.e.d.  
Ingolf Lohmann
