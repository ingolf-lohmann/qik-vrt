# QIKVRT Quantengravitation — GitHub Three PDF Persistence V5

**Urheber:** Ingolf Lohmann  
**Ziel:** Alle drei Quantengravitations-PDFs werden als Pflichtartefakte in einem GitHub-persistierbaren Repository geführt.

## Inhalt

Dieses Repository enthält drei vollständige PDF-Artefakte:

1. `01_qik_vrt_quantengravitation_semester2_beweisskript_v4.pdf`
2. `02_quantengravitation_bekannte_mathematik_physik_semester2_v5.pdf`
3. `03_quantengravitation_semester3_abschluss_beweis_v3.pdf`

Diese drei PDFs sind nicht optional. Sie sind Pflichtartefakte.

## Acceptance-Test

Aktiver Acceptance-Test:

```text
GITHUB_THREE_QUANTUM_GRAVITY_PDFS_PERSISTENCE_ACCEPTANCE_TEST
```

Fehlerklassen:

```text
GITHUB_REQUIRED_PDF_ARTIFACT_NOT_INCLUDED
GITHUB_THREE_PDF_PERSISTENCE_NOT_ENFORCED
GITHUB_PERSISTENCE_WITHOUT_FULL_ARTIFACT_BODY
```

Kernregel:

```text
GitHub-PASS ohne alle drei vollständigen Quantengravitations-PDFs ist kein Repository-PASS.
```

## Lokale Prüfung

```bash
python tools/verify_github_three_pdf_package.py
```

Erwartetes Ergebnis:

```text
PASS GitHub three PDF persistence package verification
```

## GitHub-Persistenz

Plattformneutral:

```bash
python tools/persist_to_github.py --remote <github-remote-url> --branch main
```

Linux/macOS:

```bash
bash scripts/persist_git.sh <github-remote-url> main
```

Windows:

```powershell
.\scripts\persist_git.ps1 -Remote "<github-remote-url>" -Branch "main"
```

Der Persistenzweg ruft vor Git-Commit und Push den Verifier auf. Ohne bestandenen Drei-PDF-Acceptance-Test erfolgt kein Push.

q.e.d.  
Ingolf Lohmann
