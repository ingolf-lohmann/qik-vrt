#!/usr/bin/env python3
from __future__ import annotations
import json, pathlib, re, sys, hashlib, ast, stat

ROOT = pathlib.Path(__file__).resolve().parents[1]

REQUIRED_FILES = [
    "acceptance/ACCEPTANCE_COVERAGE_REGISTRY.json",
    "acceptance/ACCEPTANCE_COVERAGE_COMPLETE_META_TEST.md",
    "acceptance/MODE_DECLARATION_SCRIPT_ONLY_VS_CONTENT_PACKAGE_TEST.md",
    "acceptance/EXTERNAL_EVIDENCE_REQUIRED_FOR_DONE_TEST.md",
    "acceptance/SECRET_TOKEN_EXCLUSION_ACCEPTANCE_TEST.md",
    "acceptance/MANIFEST_SHA256_ZIP_INTEGRITY_ACCEPTANCE_TEST.md",
    "acceptance/NON_RECURSIVE_VERIFIER_ACCEPTANCE_TEST.md",
    "acceptance/README_COMMAND_COVERAGE_ACCEPTANCE_TEST.md",
    "acceptance/ERROR_CLASS_PERSISTENCE_ACCEPTANCE_TEST.md",
    "acceptance/THIRD_PARTY_RIGHTS_SOURCE_STATUS_ACCEPTANCE_TEST.md",
    "acceptance/FINAL_DELIVERY_LINK_HASH_VERIFICATION_ACCEPTANCE_TEST.md",
    "PACKAGE_MODE.md",
    "audit/V8_ACCEPTANCE_COVERAGE_EXPANSION_AUDIT.json",
]

REQUIRED_MARKERS = [
    "ACCEPTANCE_COVERAGE_INCOMPLETE",
    "AKZEPTANZTEST_ABDECKUNG_UNVOLLSTAENDIG",
    "PACKAGE_MODE_AMBIGUOUS_OR_FALSELY_CLAIMED",
    "EXTERNAL_DONE_CLAIM_WITHOUT_EXTERNAL_EVIDENCE",
    "SECRET_OR_TOKEN_EMBEDDED_IN_PACKAGE",
    "MANIFEST_SHA256_ZIP_INTEGRITY_NOT_ENFORCED",
    "VERIFIER_RECURSION_OR_SELF_HANG",
    "README_COMMAND_COVERAGE_INCOMPLETE",
    "ERROR_CLASS_FOUND_BUT_NOT_PERSISTED",
    "THIRD_PARTY_RIGHTS_STATUS_UNCLEAR",
    "FINAL_DELIVERY_LINK_HASH_NOT_VERIFIED",
]

def forbidden_patterns():
    return [
        "gh" + "p_" + r"[A-Za-z0-9_]{20,}",
        "github" + "_pat_" + r"[A-Za-z0-9_]{20,}",
        "zenodo" + "_pat_" + r"[A-Za-z0-9_]{10,}",
        "-----BEGIN " + "PRIVATE KEY-----",
        "access" + "_token" + r"\s*=",
    ]

def fail(msg: str) -> int:
    print("FAIL " + msg, file=sys.stderr)
    return 1

def sha256_file(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for c in iter(lambda: f.read(1024 * 1024), b""):
            h.update(c)
    return h.hexdigest()

def files():
    return [p for p in ROOT.rglob("*") if p.is_file() and ".git" not in p.parts and "__pycache__" not in p.parts]

def all_text() -> str:
    chunks = []
    for p in files():
        try:
            chunks.append(p.read_text(encoding="utf-8"))
        except UnicodeDecodeError:
            pass
    return "\n".join(chunks)

def main() -> int:
    for rel in REQUIRED_FILES:
        if not (ROOT / rel).is_file():
            return fail(f"required coverage file missing: {rel}")

    reg = json.loads((ROOT / "acceptance/ACCEPTANCE_COVERAGE_REGISTRY.json").read_text(encoding="utf-8"))
    if len(reg.get("required_acceptance_tests", [])) < 16:
        return fail("coverage registry has too few required tests")

    text = all_text()
    for marker in REQUIRED_MARKERS:
        if marker not in text:
            return fail(f"required marker missing: {marker}")
    for pattern in forbidden_patterns():
        if re.search(pattern, text):
            return fail("forbidden secret-like pattern found")

    for p in ROOT.rglob("*.py"):
        if ".git" in p.parts or "__pycache__" in p.parts:
            continue
        try:
            ast.parse(p.read_text(encoding="utf-8"))
        except SyntaxError as exc:
            return fail(f"Python syntax error in {p.relative_to(ROOT)}: {exc}")

    for rel in ["qikvrt.py", "qikvrt.sh"]:
        p = ROOT / rel
        if p.is_file() and not (p.stat().st_mode & stat.S_IXUSR):
            return fail(f"missing executable bit: {rel}")

    sums = ROOT / "SHA256SUMS.txt"
    manifest = ROOT / "REPOSITORY_FILE_MANIFEST.json"
    if not sums.is_file() or not manifest.is_file():
        return fail("manifest or SHA256SUMS missing")

    sum_map = {}
    for line in sums.read_text(encoding="utf-8").splitlines():
        if line.strip():
            h, path = line.split(maxsplit=1)
            sum_map[path.strip()] = h
    for rel, expected in sum_map.items():
        p = ROOT / rel
        if not p.is_file():
            return fail(f"SHA256SUMS references missing file: {rel}")
        if sha256_file(p) != expected:
            return fail(f"SHA256 mismatch: {rel}")

    paths = {entry.get("path") for entry in json.loads(manifest.read_text(encoding="utf-8")).get("files", [])}
    for rel in REQUIRED_FILES:
        if rel not in paths:
            return fail(f"required coverage file not in manifest: {rel}")

    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    for marker in ["qikvrt.py", "qikvrt.sh", "qikvrt.cmd", "qikvrt.ps1", "verify-license", "verify-coverage"]:
        if marker not in readme:
            return fail(f"README missing command marker: {marker}")

    print("PASS full acceptance coverage verification")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
