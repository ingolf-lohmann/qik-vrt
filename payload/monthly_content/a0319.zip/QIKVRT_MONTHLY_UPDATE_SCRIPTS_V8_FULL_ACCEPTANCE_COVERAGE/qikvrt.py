#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, subprocess, sys

ROOT = pathlib.Path(__file__).resolve().parent

COMMANDS = {
    "verify": ["tools/verify_cross_platform_executability.py"],
    "verify-license": ["tools/verify_license_compliance.py"],
    "verify-coverage": ["tools/verify_acceptance_coverage.py"],
    "verify-update-package": ["tools/verify_update_script_package.py"],
    "verify-zenodo-layer": ["tools/verify_zenodo_fourth_layer.py"],
    "zenodo-plan": ["tools/qikvrt_create_zenodo_monthly_scientific_pdf_plan.py"],
    "github-persist-acceptance": ["tools/persist_acceptance_change_to_github.py"],
    "github-persist-monthly-failure": ["tools/persist_monthly_content_acceptance_failure_to_github.py"],
    "github-persist-zenodo-layer": ["tools/persist_zenodo_fourth_layer_to_github.py"],
    "github-persist-license": ["tools/persist_license_compliance_to_github.py"],
    "github-persist-coverage": ["tools/persist_acceptance_coverage_to_github.py"],
}

def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="QIKVRT monthly update cross-platform launcher.")
    parser.add_argument("command", choices=sorted(COMMANDS.keys()), help="Command to execute.")
    parser.add_argument("args", nargs=argparse.REMAINDER, help="Arguments passed to the command. Use -- before command-specific options.")
    ns = parser.parse_args(argv)
    extra = ns.args[1:] if ns.args and ns.args[0] == "--" else ns.args
    script = ROOT.joinpath(*COMMANDS[ns.command])
    if not script.is_file():
        print(f"FAIL command target missing: {script}", file=sys.stderr)
        return 1
    return subprocess.run([sys.executable, str(script)] + extra, cwd=ROOT).returncode

if __name__ == "__main__":
    raise SystemExit(main())
