@echo off
setlocal
set "SCRIPT_DIR=%~dp0"
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  py -3 "%SCRIPT_DIR%qikvrt.py" %*
  exit /b %ERRORLEVEL%
)
where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  python "%SCRIPT_DIR%qikvrt.py" %*
  exit /b %ERRORLEVEL%
)
echo FAIL Python not found. Install Python 3.10 or newer.
exit /b 127
