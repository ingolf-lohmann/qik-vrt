#!/usr/bin/env python3
from __future__ import annotations
import pathlib, runpy, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
# Delegate by loading the master gate source in-process, not through subprocess recursion.
ns = runpy.run_path(str(ROOT / 'tools' / 'qikvrt_master_acceptance_gate.py'))
raise SystemExit(ns['main']())
