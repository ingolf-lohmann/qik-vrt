#!/usr/bin/env python3
from __future__ import annotations
import ast
import hashlib
import json
import pathlib
import re
import stat
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]

REQUIRED_FILES = [
    'PACKAGE_MODE.md', 'README.md', 'STATUS.md', 'LICENSE_NOTICE.md',
    'REPOSITORY_FILE_MANIFEST.json', 'SHA256SUMS.txt',
    'qikvrt.py', 'qikvrt.sh', 'qikvrt.cmd', 'qikvrt.bat', 'qikvrt.ps1',
    'tools/qikvrt_master_acceptance_gate.py',
    'tools/verify_acceptance_coverage.py',
    'tools/verify_cross_platform_executability.py',
    'tools/verify_license_compliance.py',
    'acceptance/ACCEPTANCE_COVERAGE_REGISTRY.json',
    'acceptance/MASTER_ACCEPTANCE_GATE_NON_RECURSIVE_TEST.md',
    'acceptance/ZIP_EXTRACTION_PERMISSION_STABILITY_TEST.md',
    'acceptance/INTERPRETER_BASED_EXECUTION_PATH_ACCEPTANCE_TEST.md',
    'acceptance/COPYRIGHT_LICENSE_COMPLIANCE_ACCEPTANCE_TEST.md',
    'acceptance/CROSS_PLATFORM_SCRIPT_EXECUTABILITY_ACCEPTANCE_TEST.md',
    'acceptance/ZENODO_MONTHLY_SCIENTIFIC_PDF_CONTENT_ACCEPTANCE_TEST.md',
    'acceptance/MODE_DECLARATION_SCRIPT_ONLY_VS_CONTENT_PACKAGE_TEST.md',
    'acceptance/EXTERNAL_EVIDENCE_REQUIRED_FOR_DONE_TEST.md',
    'acceptance/SECRET_TOKEN_EXCLUSION_ACCEPTANCE_TEST.md',
    'acceptance/MANIFEST_SHA256_ZIP_INTEGRITY_ACCEPTANCE_TEST.md',
    'acceptance/NON_RECURSIVE_VERIFIER_ACCEPTANCE_TEST.md',
    'acceptance/README_COMMAND_COVERAGE_ACCEPTANCE_TEST.md',
    'acceptance/ERROR_CLASS_PERSISTENCE_ACCEPTANCE_TEST.md',
    'acceptance/THIRD_PARTY_RIGHTS_SOURCE_STATUS_ACCEPTANCE_TEST.md',
    'acceptance/FINAL_DELIVERY_LINK_HASH_VERIFICATION_ACCEPTANCE_TEST.md',
]

REQUIRED_MARKERS = [
    'ACCEPTANCE_COVERAGE_INCOMPLETE',
    'COPYRIGHT_AND_LICENSE_COMPLIANCE_NOT_ENFORCED',
    'CROSS_PLATFORM_SCRIPT_NOT_EXECUTABLE',
    'ZENODO_SCIENTIFIC_PDF_CONTENT_CLAIM_NOT_MATERIALIZED',
    'MONTHLY_CONTENT_CLAIMED_BUT_ONLY_UPDATE_SCRIPTS_DELIVERED',
    'FINAL_DELIVERY_CLAIM_WITHOUT_CONFIRMED_ARTIFACT_GENERATION',
    'EXTERNAL_DONE_CLAIM_WITHOUT_EXTERNAL_EVIDENCE',
    'SECRET_OR_TOKEN_EMBEDDED_IN_PACKAGE',
    'MASTER_ACCEPTANCE_GATE_MISSING_OR_RECURSIVE',
    'ZIP_EXECUTABLE_PERMISSION_LOST_AFTER_EXTRACTION',
    'INTERPRETER_EXECUTION_PATH_NOT_DOCUMENTED_OR_VERIFIABLE',
    'Keine Persistenz ohne Lizenz- und Urheberrechtsfreigabe',
    'Dieses Paket ist ein Skript- und Acceptance-Coverage-Paket',
]

def forbidden_patterns():
    return [
        'gh' + 'p_' + r'[A-Za-z0-9_]{20,}',
        'github' + '_pat_' + r'[A-Za-z0-9_]{20,}',
        'zenodo' + '_pat_' + r'[A-Za-z0-9_]{10,}',
        '-----BEGIN ' + 'PRIVATE KEY-----',
        'access' + '_token' + r'\s*=',
    ]

def fail(msg: str) -> int:
    print('FAIL ' + msg, file=sys.stderr)
    return 1

def sha256_file(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for c in iter(lambda: f.read(1024 * 1024), b''):
            h.update(c)
    return h.hexdigest()

def iter_files():
    return [p for p in ROOT.rglob('*') if p.is_file() and '.git' not in p.parts and '__pycache__' not in p.parts]

def all_text() -> str:
    chunks = []
    for p in iter_files():
        try:
            chunks.append(p.read_text(encoding='utf-8'))
        except UnicodeDecodeError:
            pass
    return '\n'.join(chunks)

def main() -> int:
    # Required files
    for rel in REQUIRED_FILES:
        if not (ROOT / rel).is_file():
            return fail(f'required file missing: {rel}')

    text = all_text()
    # Required markers
    for marker in REQUIRED_MARKERS:
        if marker not in text:
            return fail(f'required marker missing: {marker}')

    # No secrets
    for pattern in forbidden_patterns():
        if re.search(pattern, text):
            return fail('forbidden secret-like pattern found')

    # Python syntax, static only
    for p in ROOT.rglob('*.py'):
        if '.git' in p.parts or '__pycache__' in p.parts:
            continue
        try:
            ast.parse(p.read_text(encoding='utf-8'))
        except SyntaxError as exc:
            return fail(f'Python syntax error in {p.relative_to(ROOT)}: {exc}')

    # Interpreter based paths: do not require extracted executable bits, require shebang/docs/wrappers
    qikvrt_py = (ROOT / 'qikvrt.py').read_text(encoding='utf-8')
    qikvrt_sh = (ROOT / 'qikvrt.sh').read_text(encoding='utf-8')
    qikvrt_cmd = (ROOT / 'qikvrt.cmd').read_text(encoding='utf-8')
    qikvrt_ps1 = (ROOT / 'qikvrt.ps1').read_text(encoding='utf-8')
    for marker in ['argparse', 'COMMANDS', 'master-gate']:
        if marker not in qikvrt_py:
            return fail(f'qikvrt.py missing marker: {marker}')
    for marker in ['#!/usr/bin/env bash', 'python3', 'qikvrt.py']:
        if marker not in qikvrt_sh:
            return fail(f'qikvrt.sh missing marker: {marker}')
    for marker in ['exit /b %ERRORLEVEL%', 'qikvrt.py']:
        if marker not in qikvrt_cmd:
            return fail(f'qikvrt.cmd missing marker: {marker}')
    for marker in ['$LASTEXITCODE', 'qikvrt.py']:
        if marker not in qikvrt_ps1:
            return fail(f'qikvrt.ps1 missing marker: {marker}')

    # Manifest/SHA consistency
    sums = ROOT / 'SHA256SUMS.txt'
    manifest = ROOT / 'REPOSITORY_FILE_MANIFEST.json'
    sum_map = {}
    for line in sums.read_text(encoding='utf-8').splitlines():
        if line.strip():
            h, path = line.split(maxsplit=1)
            sum_map[path.strip()] = h
    for rel, expected in sum_map.items():
        p = ROOT / rel
        if not p.is_file():
            return fail(f'SHA256SUMS references missing file: {rel}')
        if sha256_file(p) != expected:
            return fail(f'SHA256 mismatch: {rel}')
    mf = json.loads(manifest.read_text(encoding='utf-8'))
    paths = {entry.get('path') for entry in mf.get('files', [])}
    for rel in REQUIRED_FILES:
        if rel not in paths:
            return fail(f'required file not in manifest: {rel}')

    # Registry coverage
    reg = json.loads((ROOT / 'acceptance/ACCEPTANCE_COVERAGE_REGISTRY.json').read_text(encoding='utf-8'))
    tests = reg.get('required_acceptance_tests', [])
    if len(tests) < 19:
        return fail('coverage registry has too few tests for V9')
    for test in tests:
        found = False
        for p in (ROOT / 'acceptance').glob('*'):
            if p.is_file():
                try:
                    content = p.read_text(encoding='utf-8')
                except Exception:
                    content = ''
                if test in p.name or test in content:
                    found = True
                    break
        if not found:
            return fail(f'registered acceptance test not materialized: {test}')

    # Mode boundary
    mode = (ROOT / 'PACKAGE_MODE.md').read_text(encoding='utf-8')
    if 'script_package_with_acceptance_coverage_and_runtime_content_inventory_tools' not in mode:
        return fail('package mode missing script/Coverage declaration')
    monthly_manifest = ROOT / 'QIKVRT_MONTHLY_ARTIFACT_MANIFEST.json'
    pdf_count = len([p for p in iter_files() if p.suffix.lower() == '.pdf'])
    if not monthly_manifest.exists() and pdf_count == 0:
        # Valid only because package explicitly states it is not a content package.
        if 'kein vollständiges Monatscontent-Paket' not in mode and 'Not a full monthly content package' not in mode:
            return fail('no monthly content present and no explicit non-content boundary')

    # No external DONE without evidence in STATUS/PACKAGE_MODE/README
    if 'GitHub-DONE ist erst zulässig mit echter GitHub-Evidenz' not in text:
        return fail('GitHub DONE status boundary missing')
    if 'Zenodo-DONE ist erst zulässig mit echter DOI/Record-URL-Evidenz' not in text:
        return fail('Zenodo DONE status boundary missing')

    print('PASS QIKVRT master acceptance gate')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
