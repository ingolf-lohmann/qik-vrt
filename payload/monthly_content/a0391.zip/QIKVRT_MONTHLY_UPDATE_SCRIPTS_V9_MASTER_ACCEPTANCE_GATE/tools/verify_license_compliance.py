#!/usr/bin/env python3
from __future__ import annotations
import json, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
REQUIRED_FILES = [
    "LICENSE_NOTICE.md",
    "acceptance/COPYRIGHT_LICENSE_COMPLIANCE_ACCEPTANCE_TEST.md",
    "legal/RIGHTS_AND_LICENSE_POLICY.md",
    "legal/THIRD_PARTY_CONTENT_DECLARATION.json",
    "audit/V6_COPYRIGHT_LICENSE_LAYER_GAP_FINDING.json",
]
REQUIRED_MARKERS = [
    "COPYRIGHT_LICENSE_COMPLIANCE_ACCEPTANCE_TEST",
    "COPYRIGHT_AND_LICENSE_COMPLIANCE_NOT_ENFORCED",
    "URHEBERRECHT_UND_LIZENZBESTIMMUNGEN_NICHT_ERZWUNGEN",
    "Keine Persistenz ohne Lizenz- und Urheberrechtsfreigabe",
    "Ingolf Lohmann",
    "CC BY-NC-ND 4.0",
    "cc-by-nc-nd-4.0",
]
def fail(msg): print("FAIL "+msg, file=sys.stderr); return 1
def read(path): return path.read_text(encoding="utf-8")
def main():
    for rel in REQUIRED_FILES:
        if not (ROOT/rel).is_file(): return fail(f"required license compliance file missing: {rel}")
    combined="\n".join(read(ROOT/rel) for rel in REQUIRED_FILES)
    for marker in REQUIRED_MARKERS:
        if marker not in combined: return fail(f"required license marker missing: {marker}")
    decl=json.loads(read(ROOT/"legal/THIRD_PARTY_CONTENT_DECLARATION.json"))
    if decl.get("if_third_party_content_detected")!="BLOCK_OR_ISOLATE_UNTIL_RIGHTS_STATUS_IS_DOCUMENTED":
        return fail("third-party declaration does not block/isolate unclear third-party content")
    zenodo_scripts=[ROOT/"tools/qikvrt_create_zenodo_monthly_scientific_pdf_plan.py", ROOT/"tools/qikvrt_update_zenodo_scientific_pdfs.py", ROOT/"tools/zenodo_create_individual_deposits.py"]
    any_zenodo=False
    for script in zenodo_scripts:
        if script.is_file():
            any_zenodo=True
            text=read(script)
            for marker in ['"license"', '"creators"', "Lohmann, Ingolf", "--publish"]:
                if marker not in text: return fail(f"Zenodo script missing metadata marker {marker}: {script.relative_to(ROOT)}")
            if "cc-by-nc-nd-4.0" not in text and "DEFAULT_ZENODO_LICENSE" not in text:
                return fail(f"Zenodo script missing license value or constant: {script.relative_to(ROOT)}")
    if not any_zenodo: return fail("no Zenodo planning/upload script found")
    print("PASS copyright and license compliance acceptance")
    return 0
if __name__=="__main__": raise SystemExit(main())
