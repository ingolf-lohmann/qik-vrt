#!/usr/bin/env python3
from __future__ import annotations
import ast, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
REQUIRED = ['qikvrt.py','qikvrt.sh','qikvrt.cmd','qikvrt.bat','qikvrt.ps1','acceptance/CROSS_PLATFORM_SCRIPT_EXECUTABILITY_ACCEPTANCE_TEST.md','acceptance/ZIP_EXTRACTION_PERMISSION_STABILITY_TEST.md','acceptance/INTERPRETER_BASED_EXECUTION_PATH_ACCEPTANCE_TEST.md']
def fail(msg): print('FAIL '+msg, file=sys.stderr); return 1
def main():
    for rel in REQUIRED:
        if not (ROOT/rel).is_file(): return fail(f'required file missing: {rel}')
    for p in ROOT.rglob('*.py'):
        if '__pycache__' not in p.parts:
            ast.parse(p.read_text(encoding='utf-8'))
    checks=[('qikvrt.py',['COMMANDS','master-gate']),('qikvrt.sh',['#!/usr/bin/env bash','python3','qikvrt.py']),('qikvrt.cmd',['exit /b %ERRORLEVEL%','qikvrt.py']),('qikvrt.ps1',['$LASTEXITCODE','qikvrt.py'])]
    for rel, markers in checks:
        txt=(ROOT/rel).read_text(encoding='utf-8')
        for m in markers:
            if m not in txt: return fail(f'{rel} missing marker: {m}')
    print('PASS cross-platform script executability acceptance')
    return 0
if __name__=='__main__': raise SystemExit(main())
