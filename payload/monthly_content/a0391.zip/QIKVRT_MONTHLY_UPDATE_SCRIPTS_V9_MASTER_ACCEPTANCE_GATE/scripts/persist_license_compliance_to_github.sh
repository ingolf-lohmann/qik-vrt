#!/usr/bin/env bash
set -euo pipefail
python3 tools/persist_license_compliance_to_github.py "$@"
