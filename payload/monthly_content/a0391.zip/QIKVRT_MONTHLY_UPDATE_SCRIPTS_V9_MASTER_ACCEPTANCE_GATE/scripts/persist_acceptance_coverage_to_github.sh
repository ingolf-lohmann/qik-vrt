#!/usr/bin/env bash
set -euo pipefail
python3 tools/persist_acceptance_coverage_to_github.py "$@"
