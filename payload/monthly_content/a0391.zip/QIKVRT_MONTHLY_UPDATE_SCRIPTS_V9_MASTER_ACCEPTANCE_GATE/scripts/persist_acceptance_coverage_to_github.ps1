$ErrorActionPreference = "Stop"
python tools\persist_acceptance_coverage_to_github.py @args
