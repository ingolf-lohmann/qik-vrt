$ErrorActionPreference = "Stop"
python tools\persist_license_compliance_to_github.py @args
