# Lizenz- und Urheberrechtshinweis

Urheber und Rechteinhaber: **Ingolf Lohmann**

Sofern nicht ausdrücklich schriftlich anders vereinbart, gilt für die Inhalte dieses Pakets:

**Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International (CC BY-NC-ND 4.0)**

Zenodo-Lizenzkennung:

```text
cc-by-nc-nd-4.0
```

## Nutzungsgrenzen

Namensnennung erforderlich. Keine kommerzielle oder institutionelle Nutzung ohne gesonderte schriftliche Vereinbarung, soweit diese über die lizenzierte Nutzung hinausgeht. Keine Bearbeitung, Ableitung oder abgeleitete Veröffentlichung ohne gesonderte schriftliche Vereinbarung, soweit dies nicht ausdrücklich durch Lizenz oder Sondervereinbarung gedeckt ist. Keine externe Persistenz von Drittmaterial ohne dokumentierten Rechte-/Lizenz-/Quellenstatus.

## Persistenzebenen

Diese Regeln gelten für das Update-Paket, die Repository-Schicht, GitHub, Zenodo und jede weitere Veröffentlichung oder Weitergabe.

## Freigaberegel

Keine Persistenz ohne Lizenz- und Urheberrechtsfreigabe.

q.e.d.  
Ingolf Lohmann
