# Rights and License Policy

Urheber und Rechteinhaber der QIK-VRT-Inhalte dieses Pakets ist, soweit nicht ausdrücklich anders gekennzeichnet: **Ingolf Lohmann**.

Standardlizenz, soweit nicht ausdrücklich schriftlich anders vereinbart:

```text
Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International
CC BY-NC-ND 4.0
Zenodo: cc-by-nc-nd-4.0
```

Drittmaterial darf nur persistiert werden, wenn Quelle, Rechte-/Lizenzstatus und Nutzungsberechtigung dokumentiert sind. Bei ungeklärtem Drittmaterial gilt:

```text
Status = BLOCK/ISOLATE
Keine Veröffentlichung
Keine externe Persistenz
```

GitHub-Persistenz darf nur erfolgen, wenn der Lizenz-Verifier bestanden ist. Zenodo-Persistenz darf nur erfolgen, wenn Creator, Lizenz, Titel, Beschreibung, Einzeldeposit-Regel und explizites Publish-Gate vorhanden sind.

Keine Persistenz ohne Lizenz- und Urheberrechtsfreigabe.

q.e.d.  
Ingolf Lohmann
