#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if command -v python3 >/dev/null 2>&1; then
  PYTHON_BIN="python3"
elif command -v python >/dev/null 2>&1; then
  PYTHON_BIN="python"
else
  echo "FAIL Python not found. Install Python 3.10 or newer." >&2
  exit 127
fi
exec "$PYTHON_BIN" "$SCRIPT_DIR/qikvrt.py" "$@"
