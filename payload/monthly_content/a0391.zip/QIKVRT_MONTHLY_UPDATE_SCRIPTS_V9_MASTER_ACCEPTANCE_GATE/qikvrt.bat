@echo off
call "%~dp0qikvrt.cmd" %*
exit /b %ERRORLEVEL%
