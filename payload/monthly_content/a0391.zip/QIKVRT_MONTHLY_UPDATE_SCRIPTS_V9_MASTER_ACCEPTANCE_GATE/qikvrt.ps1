param(
  [Parameter(ValueFromRemainingArguments=$true)]
  [string[]]$Args
)
$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
try {
    $null = Get-Command py -ErrorAction Stop
    & py -3 "$ScriptDir\qikvrt.py" @Args
    exit $LASTEXITCODE
} catch {
    try {
        $null = Get-Command python -ErrorAction Stop
        & python "$ScriptDir\qikvrt.py" @Args
        exit $LASTEXITCODE
    } catch {
        Write-Error "FAIL Python not found. Install Python 3.10 or newer."
        exit 127
    }
}
