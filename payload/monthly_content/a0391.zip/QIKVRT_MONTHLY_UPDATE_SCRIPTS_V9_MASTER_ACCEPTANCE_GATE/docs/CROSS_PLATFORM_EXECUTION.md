# Cross-Platform-Ausführung

## Linux

```bash
chmod +x qikvrt.sh
./qikvrt.sh verify
./qikvrt.sh zenodo-plan -- --source /pfad/zum/monatscontent
```

## macOS

```bash
chmod +x qikvrt.sh
./qikvrt.sh verify
./qikvrt.sh zenodo-plan -- --source /pfad/zum/monatscontent
```

## Windows CMD

```cmd
qikvrt.cmd verify
qikvrt.cmd zenodo-plan -- --source C:\Pfad\zum\monatscontent
```

## Windows PowerShell

```powershell
.\qikvrt.ps1 verify
.\qikvrt.ps1 zenodo-plan -- --source C:\Pfad\zum\monatscontent
```

## Plattformneutral

```bash
python qikvrt.py verify
```

Alle Wrapper propagieren den Exit-Code des Zielskripts.

q.e.d.  
Ingolf Lohmann
