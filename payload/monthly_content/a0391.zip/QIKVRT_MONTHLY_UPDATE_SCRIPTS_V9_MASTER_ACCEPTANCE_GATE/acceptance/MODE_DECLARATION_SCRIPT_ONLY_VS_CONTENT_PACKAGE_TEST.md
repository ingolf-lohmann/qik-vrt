# MODE_DECLARATION_SCRIPT_ONLY_VS_CONTENT_PACKAGE_TEST

## Fehlerklasse

`PACKAGE_MODE_AMBIGUOUS_OR_FALSELY_CLAIMED`

Deutsch:

`PAKETMODUS_UNKLAR_ODER_FALSCH_BEHAUPTET`

## Regel

Script-only-Pakete dürfen nicht behaupten, den Monatscontent selbst zu enthalten.

q.e.d.  
Ingolf Lohmann
