# FINAL_DELIVERY_LINK_HASH_VERIFICATION_ACCEPTANCE_TEST

## Fehlerklasse

`FINAL_DELIVERY_LINK_HASH_NOT_VERIFIED`

Deutsch:

`FINALE_AUSLIEFERUNG_LINK_HASH_NICHT_GEPRUEFT`

## Regel

Vor finaler Antwort müssen Datei, Sidecar, SHA256 und ZIP-Integrität geprüft sein.

q.e.d.  
Ingolf Lohmann
