# MASTER_ACCEPTANCE_GATE_NON_RECURSIVE_TEST

## Fehlerklasse

`MASTER_ACCEPTANCE_GATE_MISSING_OR_RECURSIVE`

Deutsch:

`MASTER_AKZEPTANZ_GATE_FEHLT_ODER_IST_REKURSIV`

## Regel

Alle aktiven Acceptance-Tests müssen durch einen einzigen, nicht-rekursiven Master-Acceptance-Gate statisch geprüft werden können. Der Master-Gate darf keine eigenen Unterprozesse starten, keine anderen Verifier rekursiv ausführen und keine GitHub-/Zenodo-/Publish-DONE-Aussagen ohne externe Evidenz freigeben.

## Zweck

Die bisherigen Fehler wiederholten sich, weil einzelne Verifier nebeneinander existierten, aber kein einheitlicher letzter Gate-Zustand über alle Regeln entschied.

## Merksatz

Nicht viele Teil-PASS ersetzen den einen letzten Gate-PASS.

q.e.d.  
Ingolf Lohmann
