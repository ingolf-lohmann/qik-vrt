# ACCEPTANCE_COVERAGE_COMPLETE_META_TEST

## Fehlerklasse

`ACCEPTANCE_COVERAGE_INCOMPLETE`

Deutsch:

`AKZEPTANZTEST_ABDECKUNG_UNVOLLSTAENDIG`

## Regel

Einzelne Tests reichen nicht; die Abdeckung selbst muss getestet werden.

q.e.d.  
Ingolf Lohmann
