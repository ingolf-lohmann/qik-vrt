# COPYRIGHT_LICENSE_COMPLIANCE_ACCEPTANCE_TEST

## Fehlerklasse

`COPYRIGHT_AND_LICENSE_COMPLIANCE_NOT_ENFORCED`

Deutsch:

`URHEBERRECHT_UND_LIZENZBESTIMMUNGEN_NICHT_ERZWUNGEN`

## Zweck

Dieser Acceptance-Test erzwingt, dass Urheberrechte und Lizenzbestimmungen für alle Persistenzebenen geprüft werden: Update-Paket, Repository, GitHub und Zenodo.

## Grundregel

Keine Persistenz ohne Lizenz- und Urheberrechtsfreigabe.

## Pflichtbedingungen

Ein QIK-VRT-Paket, ein Repository-PASS, ein GitHub-Push oder ein Zenodo-Deposit ist nur zulässig, wenn `LICENSE_NOTICE.md` vorhanden ist, Urheber/Rechteinhaber benannt sind, Standardlizenz und Nutzungsgrenzen benannt sind, Drittmaterial blockiert oder geklärt ist, GitHub-/Zenodo-Persistenz vorher Verifier ausführt und Zenodo-Metadaten Creator und Lizenz enthalten.

## Standardannahme

```text
Urheber/Rechteinhaber: Ingolf Lohmann
Lizenz: Creative Commons BY-NC-ND 4.0
Zenodo-Lizenzkennung: cc-by-nc-nd-4.0
```

## Merksatz

Keine Persistenz ohne Lizenz- und Urheberrechtsfreigabe.

q.e.d.  
Ingolf Lohmann
