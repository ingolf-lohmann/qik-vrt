# EXTERNAL_EVIDENCE_REQUIRED_FOR_DONE_TEST

## Fehlerklasse

`EXTERNAL_DONE_CLAIM_WITHOUT_EXTERNAL_EVIDENCE`

Deutsch:

`EXTERNES_DONE_OHNE_EXTERNE_EVIDENZ_BEHAUPTET`

## Regel

GitHub-DONE und Zenodo-DONE benötigen echte externe Evidenz.

q.e.d.  
Ingolf Lohmann
