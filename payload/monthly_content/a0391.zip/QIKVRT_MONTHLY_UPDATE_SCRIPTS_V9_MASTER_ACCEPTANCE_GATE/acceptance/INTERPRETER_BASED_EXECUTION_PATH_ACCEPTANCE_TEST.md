# INTERPRETER_BASED_EXECUTION_PATH_ACCEPTANCE_TEST

## Fehlerklasse

`INTERPRETER_EXECUTION_PATH_NOT_DOCUMENTED_OR_VERIFIABLE`

Deutsch:

`INTERPRETER_STARTPFAD_NICHT_DOKUMENTIERT_ODER_PRUEFBAR`

## Regel

Jedes Hauptskript muss über einen dokumentierten Interpreter-Startpfad ausführbar sein, auch wenn das Dateisystem nach dem Entpacken keine Ausführungsbits setzt.

q.e.d.  
Ingolf Lohmann
