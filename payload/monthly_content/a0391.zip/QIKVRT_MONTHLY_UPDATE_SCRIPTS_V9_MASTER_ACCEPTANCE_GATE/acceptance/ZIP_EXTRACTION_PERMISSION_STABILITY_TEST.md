# ZIP_EXTRACTION_PERMISSION_STABILITY_TEST

## Fehlerklasse

`ZIP_EXECUTABLE_PERMISSION_LOST_AFTER_EXTRACTION`

Deutsch:

`ZIP_AUSFUEHRUNGSRECHT_NACH_ENTPACKEN_VERLOREN`

## Regel

Ein Cross-Platform-Paket darf seine Ausführbarkeit nicht allein vom Erhalt Unix-artiger Ausführungsbits durch das Entpackprogramm abhängig machen. Es muss mindestens interpreterbasierte Startpfade bereitstellen:

```text
python qikvrt.py ...
bash qikvrt.sh ...
qikvrt.cmd ...
qikvrt.bat ...
.\qikvrt.ps1 ...
```

Optional vorhandene ZIP-Ausführungsbits sind nützlich, aber nicht die einzige Freigabebedingung.

## Merksatz

ZIP-Rechte sind Komfort; Interpreter-Startpfade sind Pflicht.

q.e.d.  
Ingolf Lohmann
