# NON_RECURSIVE_VERIFIER_ACCEPTANCE_TEST

## Fehlerklasse

`VERIFIER_RECURSION_OR_SELF_HANG`

Deutsch:

`VERIFIER_REKURSION_ODER_SELBSTBLOCKADE`

## Regel

Verifier dürfen sich nicht unkontrolliert rekursiv starten.

q.e.d.  
Ingolf Lohmann
