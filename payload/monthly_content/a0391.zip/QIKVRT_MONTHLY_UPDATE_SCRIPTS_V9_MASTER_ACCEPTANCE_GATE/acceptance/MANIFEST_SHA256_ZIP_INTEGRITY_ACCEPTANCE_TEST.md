# MANIFEST_SHA256_ZIP_INTEGRITY_ACCEPTANCE_TEST

## Fehlerklasse

`MANIFEST_SHA256_ZIP_INTEGRITY_NOT_ENFORCED`

Deutsch:

`MANIFEST_SHA256_ZIP_INTEGRITAET_NICHT_ERZWUNGEN`

## Regel

Jede Pflichtdatei muss Manifest- und SHA256-abgedeckt sein.

q.e.d.  
Ingolf Lohmann
