# README_COMMAND_COVERAGE_ACCEPTANCE_TEST

## Fehlerklasse

`README_COMMAND_COVERAGE_INCOMPLETE`

Deutsch:

`README_STARTBEFEHL_ABDECKUNG_UNVOLLSTAENDIG`

## Regel

README muss Startbefehle für Python, Linux/macOS, Windows CMD und PowerShell enthalten.

q.e.d.  
Ingolf Lohmann
