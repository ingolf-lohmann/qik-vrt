# THIRD_PARTY_RIGHTS_SOURCE_STATUS_ACCEPTANCE_TEST

## Fehlerklasse

`THIRD_PARTY_RIGHTS_STATUS_UNCLEAR`

Deutsch:

`DRITTMATERIAL_RECHTESTATUS_UNKLAR`

## Regel

Drittmaterial darf nicht ohne geklärten Rechte-/Quellenstatus extern persistiert werden.

q.e.d.  
Ingolf Lohmann
