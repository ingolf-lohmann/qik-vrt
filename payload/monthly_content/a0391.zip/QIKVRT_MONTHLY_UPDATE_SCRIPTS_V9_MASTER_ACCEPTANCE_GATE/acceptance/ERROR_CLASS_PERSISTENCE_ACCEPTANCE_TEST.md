# ERROR_CLASS_PERSISTENCE_ACCEPTANCE_TEST

## Fehlerklasse

`ERROR_CLASS_FOUND_BUT_NOT_PERSISTED`

Deutsch:

`FEHLERKLASSE_ERKANNT_ABER_NICHT_PERSISTIERT`

## Regel

Jede erkannte Fehlerklasse muss materialisiert werden.

q.e.d.  
Ingolf Lohmann
