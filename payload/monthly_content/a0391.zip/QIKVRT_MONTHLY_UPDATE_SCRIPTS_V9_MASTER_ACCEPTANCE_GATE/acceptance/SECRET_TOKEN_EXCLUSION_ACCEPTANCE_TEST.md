# SECRET_TOKEN_EXCLUSION_ACCEPTANCE_TEST

## Fehlerklasse

`SECRET_OR_TOKEN_EMBEDDED_IN_PACKAGE`

Deutsch:

`GEHEIMNIS_ODER_TOKEN_IM_PAKET_EINGEBETTET`

## Regel

Tokens dürfen nur über Umgebungsvariablen oder Plattform-Secrets bereitgestellt werden.

q.e.d.  
Ingolf Lohmann
