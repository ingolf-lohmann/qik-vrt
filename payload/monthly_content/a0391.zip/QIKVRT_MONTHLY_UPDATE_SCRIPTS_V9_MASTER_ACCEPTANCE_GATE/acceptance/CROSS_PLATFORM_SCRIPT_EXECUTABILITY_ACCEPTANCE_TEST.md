# CROSS_PLATFORM_SCRIPT_EXECUTABILITY_ACCEPTANCE_TEST

## Fehlerklasse

`CROSS_PLATFORM_SCRIPT_NOT_EXECUTABLE`

Deutsch:

`PLATTFORMUEBERGREIFENDES_SKRIPT_NICHT_AUSFUEHRBAR`

## Zweck

Dieser Acceptance-Test verhindert, dass ein QIK-VRT-Skriptpaket als Windows-, macOS- und Linux-tauglich ausgeliefert wird, obwohl keine funktionsfähigen Startpunkte pro Zielplattform vorhanden sind.

## Pflichtbedingungen

Vor finaler Auslieferung müssen vorhanden und geprüft sein:

1. plattformneutraler Python-CLI-Einstieg,
2. Windows-Start per `.cmd`,
3. Windows-Start per `.bat`,
4. Windows-PowerShell-Start per `.ps1`,
5. Unix-/macOS-Start per `.sh`,
6. Ausführungsbit für `.sh` und Python-CLI im ZIP,
7. Python-Syntaxprüfung aller `.py`-Dateien,
8. Shell-Syntaxprüfung aller `.sh`-Dateien,
9. PowerShell-Syntaxhinweis oder `pwsh`-Parserprüfung, soweit verfügbar,
10. Exit-Code-Propagation in allen Wrappern,
11. README mit konkreten Startbefehlen.

## Merksatz

Ein Skript ist erst plattformtauglich, wenn es pro Zielplattform einen geprüften Startpfad besitzt.

q.e.d.  
Ingolf Lohmann
