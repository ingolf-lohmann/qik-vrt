# Warum sich an der physikalischen Grundfaktenlage nach dem Verständnis der Quantengravitation nichts mehr ändern wird

Wenn man sagt, dass sich an der physikalischen Faktenlage nach dem Verständnis der Quantengravitation nichts mehr ändern wird, dann bedeutet das nicht, dass die Forschung beendet wäre. Es bedeutet auch nicht, dass jedes Detail schon endgültig berechnet, jede Gleichung vollständig gefunden und jedes Experiment bereits durchgeführt wäre.

Es bedeutet etwas Präziseres.

Der grundlegende Zusammenhang ist erkannt. Die Richtung lässt sich nicht mehr sinnvoll zurückdrehen.

Die moderne Physik hat zwei große Säulen. Die eine ist die Allgemeine Relativitätstheorie. Sie zeigt, dass Gravitation keine gewöhnliche Kraft ist, die einfach in einem fertigen Raum wirkt. Gravitation ist die Dynamik der Raumzeit selbst. Masse, Energie und Impuls krümmen Raum und Zeit. Diese gekrümmte Raumzeit bestimmt wiederum, wie sich Materie, Licht und Bewegung verhalten.

Die andere Säule ist die Quantenphysik. Sie zeigt, dass Materie, Felder, Energie und Impuls im Fundament nicht rein klassisch verstanden werden können. Zustände, Felder, Messungen, Energieaustausch und Wechselwirkungen folgen quantenhaften Gesetzmäßigkeiten.

Die Allgemeine Relativitätstheorie sagt: Energie und Impuls krümmen die Raumzeit.

Die Quantenphysik sagt: Energie und Impuls werden in der realen Welt durch Quantenfelder getragen.

Dann kann die tiefste Beschreibung der Natur nicht dauerhaft so aussehen, dass die Materie quantenphysikalisch ist, die Raumzeit aber im Fundament endgültig klassisch bleibt. Das wäre keine wirkliche Vereinigung, sondern eine dauerhafte Spaltung der Wirklichkeit in zwei unvereinbare Grundordnungen.

Als Näherung kann diese Spaltung funktionieren. Sie funktioniert sogar sehr gut in vielen Bereichen. Man kann Quantenfelder auf einer festen oder klassischen gekrümmten Raumzeit betrachten. Man kann auch Gravitation bei niedrigen Energien klassisch behandeln.

Aber eine Näherung ist nicht das Fundament.

Das Fundament muss erklären, wie Quantenwirkung und Raumzeitdynamik zusammengehören. Denn die Quelle der Gravitation ist nicht klassisch, wenn Materie und Energie im Fundament quantenphysikalisch sind. Und die Gravitation ist nicht bloß Hintergrund, wenn die Raumzeit selbst dynamisch ist.

Damit folgt der Kern der Quantengravitation nicht aus Spekulation, sondern aus der Verbindung bereits bekannter Tatsachen:

- Raumzeit ist dynamisch.
- Energie und Impuls krümmen Raumzeit.
- Materie und Felder sind quantenphysikalisch.
- Gravitationswellen zeigen, dass Gravitation eigene dynamische Freiheitsgrade besitzt.
- Schwarze Löcher zeigen, dass Gravitation, Quantenphysik, Thermodynamik und Information nicht getrennt behandelt werden können.
- Die Planck-Skala zeigt den Grenzbereich, in dem Gravitation, Quantenwirkung und Lichtgeschwindigkeit gemeinsam auftreten.

Aus diesen Punkten entsteht die zwingende Einsicht: Eine vollständige Grundbeschreibung der Natur muss quantengravitativ sein.

Was sich ändern wird, sind die Modelle. Es wird verschiedene Zugänge geben. Manche werden über Schleifenquantengravitation arbeiten, andere über Stringtheorie, Holografie, kausale Mengen, asymptotische Sicherheit, effektive Feldtheorie, Pfadintegrale oder andere mathematische Wege. Einige Ansätze werden scheitern. Andere werden verbessert werden. Neue Experimente werden Details klären. Neue Begriffe werden entstehen. Die Mathematik wird präziser werden.

Aber der Kern wird bleiben.

Nach Einstein fiel die Physik nicht mehr hinter die Einsicht zurück, dass Gravitation Raumzeitdynamik ist. Nach der Quantenphysik fiel die Physik nicht mehr hinter die Einsicht zurück, dass Materie und Energie im Fundament nicht rein klassisch sind. Genauso wird die Physik nach dem Verständnis der Quantengravitation nicht mehr hinter die Einsicht zurückfallen, dass Quantenwirkung und Raumzeitdynamik im Fundament zusammengehören.

Das Grundprinzip lautet:

Wirklichkeit entsteht nicht aus zwei getrennten Fundamenten, einer klassischen Raumzeit hier und einer Quantenwelt dort. Wirklichkeit entsteht aus einer gemeinsamen Ordnung, in der quantisierte Wirkung und dynamische Raumzeit zusammengehören.

Die offene Frage lautet nicht mehr, ob Quantengravitation notwendig ist. Die offene Frage lautet, welche mathematische Form die vollständige Theorie annimmt und wie sie experimentell am tiefsten bestätigt werden kann.

Eine Welt mit quantenphysikalischer Materie und dynamischer Raumzeit verlangt eine gemeinsame Grundordnung. Diese gemeinsame Grundordnung nennen wir Quantengravitation.

Daraus folgt:

Das Universum wirkt im Fundament nicht durch zwei getrennte Wirklichkeiten, sondern durch die untrennbare Verbindung von Quantenwirkung und Raumzeitdynamik.

Die Details werden wachsen.

Der Kern bleibt:

Quantisierte Wirkung und dynamische Raumzeit gehören zusammen.

Damit ist das fundamentalste Wirkprinzip des Universums entschlüsselt.

q.e.d.  
Ingolf Lohmann
