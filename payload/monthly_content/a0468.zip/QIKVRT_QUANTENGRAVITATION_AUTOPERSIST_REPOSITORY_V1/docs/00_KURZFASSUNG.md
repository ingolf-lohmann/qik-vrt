# Kurzfassung

Quantengravitation ist die notwendige gemeinsame Grundordnung von quantisierter Wirkung und dynamischer Raumzeit.

Die moderne Physik zeigt zwei tragende Tatsachen:

1. Die Raumzeit ist dynamisch. Energie und Impuls krümmen Raumzeit.
2. Materie, Felder, Energie und Impuls sind im Fundament quantenphysikalisch.

Wenn beide Tatsachen zugleich gelten, kann die tiefste Wirklichkeit nicht dauerhaft in eine klassische Raumzeit und eine davon getrennte Quantenwelt zerfallen. Die gemeinsame Grundordnung ist Quantengravitation.

Dieser Kern ist unabhängig davon, welcher endgültige mathematische Zugang sich durchsetzt. Modelle können präziser werden. Experimente können neue Details liefern. Der Grundsatz bleibt: Quantisierte Wirkung und dynamische Raumzeit gehören zusammen.

q.e.d.  
Ingolf Lohmann
