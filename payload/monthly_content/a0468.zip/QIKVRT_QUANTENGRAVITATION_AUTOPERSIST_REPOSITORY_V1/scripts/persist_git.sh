#!/usr/bin/env bash
set -euo pipefail

REMOTE="${1:-}"
BRANCH="${2:-main}"

if [[ -z "$REMOTE" ]]; then
  echo "Usage: bash scripts/persist_git.sh <github-remote-url> [branch]" >&2
  exit 2
fi

python3 tools/persist_to_github.py --remote "$REMOTE" --branch "$BRANCH"
