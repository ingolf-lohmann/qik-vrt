# Lizenz- und Nutzungsvereinbarung

Urheber und Rechteinhaber: **Ingolf Lohmann**

Sofern nicht ausdrücklich schriftlich anders vereinbart, gilt für die Inhalte dieses Repositories:

**Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International (CC BY-NC-ND 4.0)**

Das bedeutet zusammengefasst:

- Namensnennung erforderlich.
- Keine kommerzielle Nutzung ohne gesonderte schriftliche Vereinbarung.
- Keine Bearbeitung oder abgeleitete Veröffentlichung ohne gesonderte schriftliche Vereinbarung.
- Institutionelle oder kommerzielle Nutzung erfordert eine gesonderte Vereinbarung mit Ingolf Lohmann oder einer von ihm benannten juristischen Person.

## Technische Nutzung

Die mitgelieferten Prüf- und Persistenzskripte dienen dazu, die Repository-Struktur zu prüfen und nach GitHub zu übertragen. Diese technische Ausführung ersetzt keine Lizenzannahme und keine gesonderte Nutzungserlaubnis für kommerzielle oder institutionelle Zwecke.

## Akzeptanz

Wer dieses Repository prüft, ausführt, kopiert, veröffentlicht, spiegelt, integriert oder nach GitHub persistiert, muss die Lizenz- und Nutzungsbedingungen beachten.

q.e.d.  
Ingolf Lohmann
