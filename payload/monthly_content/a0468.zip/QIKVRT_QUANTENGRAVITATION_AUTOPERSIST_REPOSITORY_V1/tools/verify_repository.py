#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]

REQUIRED_FILES = [
    "README.md",
    "LICENSE_NOTICE.md",
    "qikvrt_manifest.json",
    "docs/00_KURZFASSUNG.md",
    "docs/01_ARTIKEL_PHYSIKALISCHE_FAKTENLAGE.md",
    "docs/02_DRITTES_SEMESTER_ZUSAMMENFASSUNG.md",
    "docs/03_FREIGABELOGIK_URFASSUNG.md",
    "docs/04_REPOSITORY_AUTOPERSISTENZ.md",
    "tools/verify_repository.py",
    "tools/persist_to_github.py",
    "scripts/persist_git.sh",
    "scripts/persist_git.ps1",
    ".github/workflows/verify.yml",
]

def token_markers() -> list[str]:
    # Constructed to avoid the scanner matching its own marker definitions.
    return [
        "gh" + "p_",
        "github" + "_pat_",
        "-----BEGIN " + "PRIVATE KEY-----",
        "GITHUB" + "_TOKEN=",
        "password" + "=",
        "passwd" + "=",
    ]

REQUIRED_TEXT = [
    "Ingolf Lohmann",
    "Quantengravitation",
    "Quantenwirkung",
    "dynamische Raumzeit",
    "Ethik-Zustand",
    "HASH_MATCH",
    "TEST_EXISTS",
    "EXIT_ZERO",
    "ERKENNTNIS_OK",
]

def sha256_file(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def fail(msg: str) -> int:
    print(f"FAIL {msg}", file=sys.stderr)
    return 1

def main() -> int:
    missing = [p for p in REQUIRED_FILES if not (ROOT / p).is_file()]
    if missing:
        return fail("missing required files: " + ", ".join(missing))

    try:
        manifest = json.loads((ROOT / "qikvrt_manifest.json").read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(f"manifest json invalid: {exc}")

    if manifest.get("author") != "Ingolf Lohmann":
        return fail("manifest author mismatch")

    if manifest.get("embedded_tokens") is not False:
        return fail("manifest must declare embedded_tokens=false")

    combined_text = ""
    for path in ROOT.rglob("*"):
        if path.is_file() and path.name not in {"SHA256SUMS.txt"} and ".git" not in path.parts:
            try:
                combined_text += "\n" + path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                pass

    for marker in token_markers():
        if marker in combined_text:
            return fail(f"forbidden secret marker found")

    for marker in REQUIRED_TEXT:
        if marker not in combined_text:
            return fail(f"required text marker not found: {marker}")

    sums_path = ROOT / "SHA256SUMS.txt"
    if sums_path.exists():
        bad = []
        for line in sums_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            expected, rel = line.split(maxsplit=1)
            rel = rel.strip().lstrip("*")
            p = ROOT / rel
            if not p.is_file():
                bad.append(f"missing:{rel}")
                continue
            actual = sha256_file(p)
            if actual != expected:
                bad.append(f"hash:{rel}")
        if bad:
            return fail("SHA256SUMS mismatch: " + ", ".join(bad))

    print("PASS QIKVRT repository verification")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
