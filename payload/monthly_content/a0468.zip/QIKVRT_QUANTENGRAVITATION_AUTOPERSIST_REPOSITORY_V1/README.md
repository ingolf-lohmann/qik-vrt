# QIKVRT Quantengravitation Autopersist Repository V1

**Status:** lokales, prüfbares Repository-Paket für automatisierte Persistenz nach GitHub  
**Urheber:** Ingolf Lohmann  
**Kernziel:** Quantengravitation, Quantenkausalität und verantwortbare Informationswirkung als versionierbares, prüfbares und plattformübergreifend persistierbares Repository.

Dieses Repository bündelt die im aktuellen Arbeitsstand formulierten Inhalte, Prüfregeln und Persistenzmechanismen in einer Struktur, die auf Windows, Linux und macOS geprüft und anschließend nach GitHub übertragen werden kann.

## Kernaussage

Quantengravitation wird als notwendige gemeinsame Grundordnung von quantisierter Wirkung und dynamischer Raumzeit verstanden. Die Beweiskette stützt sich auf bekannte Mathematik und bekannte Physik:

- Raumzeit ist dynamisch.
- Energie und Impuls krümmen Raumzeit.
- Materie und Felder sind quantenphysikalisch.
- Gravitationswellen zeigen propagierende Freiheitsgrade der Gravitation.
- Schwarze Löcher verbinden Gravitation, Quantenphysik, Thermodynamik und Information.
- Die Planck-Skala markiert den Grenzbereich, in dem Gravitation, Quantenwirkung und Lichtgeschwindigkeit gemeinsam auftreten.

Daraus folgt: Eine vollständige Grundbeschreibung der Natur kann nicht dauerhaft aus klassischer Raumzeit und davon getrennter Quantenmaterie bestehen. Quantisierte Wirkung und dynamische Raumzeit gehören im Fundament zusammen.

## QIKVRT-Freigabelogik

```text
0  ETHIK-ZUSTAND
   Kein Schaden.
   Keine falschen Behauptungen.
   Keine versteckten Annahmen.

1  HASH_MATCH
   Artefaktidentität stimmt.

2  TEST_EXISTS
   Prüfbarkeit ist vorhanden.

3  EXIT_ZERO
   Zielplattform-Ausführung besteht.

4  ERKENNTNIS_OK
   Schritte sind richtig, vollständig und anschlussfähig.

=> Phi(x) = DONE
```

Ohne 0 keine verantwortbare Wirkung.  
Ohne 1 kein 2.  
Ohne 2 kein 3.  
Ohne 3 kein 4.  
Ohne 4 kein DONE.

## Plattformen

- Windows: PowerShell
- Linux: Bash
- macOS: Bash
- alle Plattformen: Python 3.10+

## Automatisierte GitHub-Persistenz

1. `tools/persist_to_github.py` — plattformneutraler Python-Weg
2. `scripts/persist_git.sh` — Linux/macOS
3. `scripts/persist_git.ps1` — Windows PowerShell

Keine Zugangsdaten sind im Repository enthalten. GitHub-Zugriff erfolgt über lokal konfigurierte Git-Credentials oder Umgebungsvariablen außerhalb des Repository-Inhalts.

## Lokale Prüfung

```bash
python tools/verify_repository.py
```

Windows:

```powershell
python tools\verify_repository.py
```

Erwartetes Ergebnis:

```text
PASS QIKVRT repository verification
```

## Statusgrenze

Dieses Repository erzeugt kein falsches DONE. Es kann lokale Konsistenz, Hashes, Manifest, Lizenzblock, Skripte, Dokumente und GitHub-Workflow-Struktur prüfen. Eine echte GitHub-Persistenz ist erst DONE, wenn der Push gegen ein reales GitHub-Remote erfolgreich durchgeführt und dort nachvollziehbar abrufbar ist.

q.e.d.  
Ingolf Lohmann
