$ErrorActionPreference = "Stop"
python tools\zenodo_create_individual_deposits.py @args
