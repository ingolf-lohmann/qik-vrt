#!/usr/bin/env bash
set -euo pipefail
python3 tools/zenodo_create_individual_deposits.py "$@"
