# Lizenz- und Nutzungsvereinbarung

Urheber und Rechteinhaber: **Ingolf Lohmann**

Sofern nicht ausdrücklich schriftlich anders vereinbart, gilt für die Inhalte dieses Pakets:

**Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International (CC BY-NC-ND 4.0)**

Die Zenodo-Skripte dienen ausschließlich der technischen Deposit-Erzeugung, Dateiübertragung, Metadatenübergabe und optionalen Veröffentlichung. Eine Veröffentlichung auf Zenodo ersetzt keine gesonderten Nutzungsrechte für Dritte.

q.e.d.  
Ingolf Lohmann
