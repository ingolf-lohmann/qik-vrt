#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
REQUIRED_FILES = ["README.md","LICENSE_NOTICE.md","zenodo_deposit_plan.json","acceptance/ZENODO_THREE_PDF_INDIVIDUAL_DEPOSIT_ACCEPTANCE_TEST.md","tools/verify_zenodo_package.py","tools/zenodo_create_individual_deposits.py","scripts/zenodo_upload_individual_pdfs.sh","scripts/zenodo_upload_individual_pdfs.ps1",".github/workflows/verify.yml","REPOSITORY_FILE_MANIFEST.json","SHA256SUMS.txt"]
FORBIDDEN_MARKERS = ["gh"+"p_","github"+"_pat_","zenodo"+"_pat_","-----BEGIN "+"PRIVATE KEY-----","access"+"_"+"token=","Authorization: "+"Bearer "]
REQUIRED_TEXT_MARKERS = ["ZENODO_THREE_PDF_INDIVIDUAL_DEPOSIT_ACCEPTANCE_TEST","ZENODO_INDIVIDUAL_PDF_DEPOSITS_NOT_SEPARATED","ZENODO_PUBLICATION_WITHOUT_EXPLICIT_PUBLISH_FLAG","Ingolf Lohmann"]
def fail(msg): print(f"FAIL {msg}", file=sys.stderr); return 1
def sha256_file(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for c in iter(lambda:f.read(1024*1024), b""): h.update(c)
    return h.hexdigest()
def all_files(): return [p for p in ROOT.rglob("*") if p.is_file() and ".git" not in p.parts]
def load_sums():
    sums={}
    for line in (ROOT/"SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
        if line.strip():
            expected,path=line.split(maxsplit=1); sums[path.strip().lstrip("*")]=expected
    return sums
def main():
    missing=[p for p in REQUIRED_FILES if not (ROOT/p).is_file()]
    if missing: return fail("missing required files: "+", ".join(missing))
    combined=""
    for p in all_files():
        if p.name=="SHA256SUMS.txt": continue
        try: combined += "\n"+p.read_text(encoding="utf-8")
        except UnicodeDecodeError: pass
    for marker in FORBIDDEN_MARKERS:
        if marker in combined: return fail("forbidden token or secret marker found")
    for marker in REQUIRED_TEXT_MARKERS:
        if marker not in combined: return fail(f"required text marker not found: {marker}")
    try: plan=json.loads((ROOT/"zenodo_deposit_plan.json").read_text(encoding="utf-8"))
    except Exception as exc: return fail(f"deposit plan invalid: {exc}")
    deposits=plan.get("deposits",[])
    if len(deposits)!=3: return fail(f"expected exactly 3 deposit entries, found {len(deposits)}")
    pdf_paths=[]; metadata_paths=[]; titles=set()
    for deposit in deposits:
        pdf_path=deposit.get("pdf_path"); metadata_path=deposit.get("metadata_path"); title=deposit.get("title")
        if not pdf_path or not metadata_path or not title: return fail("deposit entry missing pdf_path, metadata_path or title")
        if deposit.get("expected_zenodo_files_per_deposit") != 1: return fail("deposit does not declare exactly one expected Zenodo file")
        p=ROOT/pdf_path; m=ROOT/metadata_path
        if not p.is_file(): return fail(f"PDF missing: {pdf_path}")
        if p.suffix.lower()!=".pdf": return fail(f"referenced artifact is not PDF: {pdf_path}")
        if p.stat().st_size <= 0: return fail(f"PDF is empty: {pdf_path}")
        if not m.is_file(): return fail(f"metadata missing: {metadata_path}")
        md=json.loads(m.read_text(encoding="utf-8"))
        if md.get("metadata",{}).get("title") != title: return fail(f"metadata title mismatch for {metadata_path}")
        if deposit.get("sha256") != sha256_file(p): return fail(f"PDF hash mismatch in deposit plan: {pdf_path}")
        pdf_paths.append(pdf_path); metadata_paths.append(metadata_path); titles.add(title)
    if len(set(pdf_paths)) != 3: return fail("PDF paths are not unique")
    if len(set(metadata_paths)) != 3: return fail("metadata paths are not unique")
    if len(titles) != 3: return fail("deposit titles are not unique")
    sums=load_sums(); required=set(REQUIRED_FILES+pdf_paths+metadata_paths)
    for path,expected in sums.items():
        p=ROOT/path
        if not p.is_file(): return fail(f"SHA256SUMS covers missing file: {path}")
        if sha256_file(p)!=expected: return fail(f"SHA256SUMS mismatch: {path}")
    for path in required:
        if path!="SHA256SUMS.txt" and path not in sums: return fail(f"required file not covered by SHA256SUMS: {path}")
    manifest=json.loads((ROOT/"REPOSITORY_FILE_MANIFEST.json").read_text(encoding="utf-8"))
    manifest_paths={entry.get("path") for entry in manifest.get("files",[])}
    for path in required:
        if path!="REPOSITORY_FILE_MANIFEST.json" and path not in manifest_paths: return fail(f"required file not in file manifest: {path}")
    print("PASS Zenodo individual PDF deposit package verification")
    return 0
if __name__=="__main__": raise SystemExit(main())
