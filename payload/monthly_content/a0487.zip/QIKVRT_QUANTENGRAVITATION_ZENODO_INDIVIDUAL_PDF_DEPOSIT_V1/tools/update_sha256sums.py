#!/usr/bin/env python3
from __future__ import annotations
import hashlib, pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
def sha(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for c in iter(lambda:f.read(1024*1024), b""): h.update(c)
    return h.hexdigest()
def main():
    files=[p for p in ROOT.rglob("*") if p.is_file() and ".git" not in p.parts and p.name!="SHA256SUMS.txt"]
    lines=[f"{sha(p)}  {p.relative_to(ROOT).as_posix()}" for p in sorted(files,key=lambda p:p.relative_to(ROOT).as_posix())]
    (ROOT/"SHA256SUMS.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(f"Wrote SHA256SUMS.txt with {len(lines)} entries")
    return 0
if __name__=="__main__": raise SystemExit(main())
