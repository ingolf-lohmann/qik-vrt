#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, pathlib, sys, urllib.error, urllib.parse, urllib.request
ROOT=pathlib.Path(__file__).resolve().parents[1]
ZENODO_API="https://zenodo.org/api"
ZENODO_SANDBOX_API="https://sandbox.zenodo.org/api"
def fail(msg): print(f"FAIL {msg}", file=sys.stderr); return 1
def auth_headers(token): return {"Authorization": "Bearer"+" "+token}
def request_json(method,url,token,payload=None):
    data=None; headers=auth_headers(token)
    if payload is not None:
        data=json.dumps(payload).encode("utf-8"); headers["Content-Type"]="application/json"
    req=urllib.request.Request(url,data=data,headers=headers,method=method)
    try:
        with urllib.request.urlopen(req,timeout=120) as resp:
            raw=resp.read().decode("utf-8"); return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        body=exc.read().decode("utf-8",errors="replace")
        raise RuntimeError(f"HTTP {exc.code} {url}\n{body}") from exc
def upload_file(bucket_url,token,path):
    url=bucket_url.rstrip("/")+"/"+urllib.parse.quote(path.name)
    req=urllib.request.Request(url,data=path.read_bytes(),headers=auth_headers(token),method="PUT")
    try:
        with urllib.request.urlopen(req,timeout=300) as resp:
            raw=resp.read().decode("utf-8"); return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        body=exc.read().decode("utf-8",errors="replace")
        raise RuntimeError(f"HTTP {exc.code} {url}\n{body}") from exc
def main():
    parser=argparse.ArgumentParser(description="Create three separate Zenodo deposits, one PDF per deposit.")
    parser.add_argument("--plan",default="zenodo_deposit_plan.json")
    parser.add_argument("--token-env",default="ZENODO_TOKEN")
    parser.add_argument("--sandbox",action="store_true")
    parser.add_argument("--publish",action="store_true")
    parser.add_argument("--dry-run",action="store_true")
    parser.add_argument("--output",default="zenodo_upload_result.json")
    args=parser.parse_args()
    verify_rc=os.system(f'"{sys.executable}" "{ROOT/"tools"/"verify_zenodo_package.py"}"')
    if verify_rc!=0: return fail("local package verification failed; refusing Zenodo upload")
    plan=json.loads((ROOT/args.plan).read_text(encoding="utf-8"))
    api=ZENODO_SANDBOX_API if args.sandbox else ZENODO_API
    token=os.environ.get(args.token_env,"")
    if args.dry_run:
        print("DRY-RUN: no Zenodo request will be sent.")
        for d in plan["deposits"]:
            print(f"WOULD CREATE individual deposit: {d['title']}")
            print(f"  PDF: {d['pdf_path']}")
            print(f"  METADATA: {d['metadata_path']}")
        return 0
    if not token: return fail(f"missing token environment variable: {args.token_env}")
    results={"api":api,"sandbox":args.sandbox,"published":args.publish,"deposits":[]}
    for d in plan["deposits"]:
        pdf_path=ROOT/d["pdf_path"]; metadata_path=ROOT/d["metadata_path"]
        metadata_payload=json.loads(metadata_path.read_text(encoding="utf-8"))
        created=request_json("POST",api+"/deposit/depositions",token,{})
        dep_id=created["id"]; bucket=created["links"]["bucket"]
        uploaded=upload_file(bucket,token,pdf_path)
        updated=request_json("PUT",api+f"/deposit/depositions/{dep_id}",token,metadata_payload)
        record={"local_deposit_id":d["deposit_id"],"deposition_id":dep_id,"title":d["title"],"pdf_path":d["pdf_path"],"metadata_path":d["metadata_path"],"bucket_file_response":uploaded,"deposition_links":updated.get("links",{})}
        if args.publish:
            published=request_json("POST",api+f"/deposit/depositions/{dep_id}/actions/publish",token,None)
            record["published_response"]=published
            record["record_url"]=published.get("links",{}).get("html")
            record["doi"]=published.get("doi")
        results["deposits"].append(record)
    out=ROOT/args.output
    out.write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"PASS Zenodo individual deposit operation completed. Result written to {out}")
    return 0
if __name__=="__main__": raise SystemExit(main())
