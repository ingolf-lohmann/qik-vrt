# QIKVRT Quantengravitation — Zenodo Individual PDF Deposit Package V1

**Urheber:** Ingolf Lohmann  
**Ziel:** Drei PDFs zur Quantengravitation einzeln auf Zenodo hochladen, jeweils als eigener Zenodo-Record mit eigenem Metadatensatz.

## Grundsatz

Dieses Paket ist ausdrücklich für **drei getrennte Zenodo-Deposits** gebaut:

1. PDF 1 → eigener Zenodo-Record
2. PDF 2 → eigener Zenodo-Record
3. PDF 3 → eigener Zenodo-Record

Nicht zulässig ist ein Sammeldeposit, wenn die Vorgabe lautet, alle drei PDFs einzeln hochzuladen.

## Sicherheit

Keine Zugangsdaten sind enthalten.

Der Zenodo-Token muss lokal als Umgebungsvariable gesetzt werden:

```bash
export ZENODO_TOKEN="..."
```

Windows PowerShell:

```powershell
$env:ZENODO_TOKEN="..."
```

## Test ohne Veröffentlichung

```bash
python tools/zenodo_create_individual_deposits.py --sandbox --dry-run
```

## Entwürfe auf Zenodo-Sandbox erzeugen

```bash
python tools/zenodo_create_individual_deposits.py --sandbox
```

## Entwürfe auf Zenodo erzeugen

```bash
python tools/zenodo_create_individual_deposits.py
```

## Veröffentlichung

Veröffentlichung ist absichtlich gesperrt, solange nicht explizit `--publish` gesetzt wird:

```bash
python tools/zenodo_create_individual_deposits.py --publish
```

## Lokale Prüfung

```bash
python tools/verify_zenodo_package.py
```

Erwartetes Ergebnis:

```text
PASS Zenodo individual PDF deposit package verification
```

q.e.d.  
Ingolf Lohmann
