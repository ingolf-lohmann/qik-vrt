# ZENODO_THREE_PDF_INDIVIDUAL_DEPOSIT_ACCEPTANCE_TEST

## Zweck

Dieser Acceptance-Test verhindert, dass drei separat zu veröffentlichende PDFs versehentlich als ein Sammeldeposit, als bloße Verweise oder als unvollständige Artefakte behandelt werden.

## Fehlerklassen

- `ZENODO_INDIVIDUAL_PDF_DEPOSITS_NOT_SEPARATED`
- `CLAIMED_ZENODO_ARTIFACT_NOT_INCLUDED`
- `ZENODO_TOKEN_EMBEDDED_IN_REPOSITORY`
- `ZENODO_PUBLICATION_WITHOUT_EXPLICIT_PUBLISH_FLAG`

## Regel

Drei PDFs zur Quantengravitation müssen als drei getrennte Zenodo-Deposits geführt werden.

Für jedes PDF gilt:

```text
PDF vorhanden
=> PDF im Deposit-Plan geführt
=> eigener Metadatensatz vorhanden
=> genau ein PDF pro Deposit geplant
=> SHA256 im Plan fixiert
=> Upload-Skript erzwingt Trennung
=> Veröffentlichung nur mit explizitem --publish
```

## Merksatz

Drei PDFs bedeuten drei Zenodo-Records, nicht ein Sammeldeposit.

q.e.d.  
Ingolf Lohmann
