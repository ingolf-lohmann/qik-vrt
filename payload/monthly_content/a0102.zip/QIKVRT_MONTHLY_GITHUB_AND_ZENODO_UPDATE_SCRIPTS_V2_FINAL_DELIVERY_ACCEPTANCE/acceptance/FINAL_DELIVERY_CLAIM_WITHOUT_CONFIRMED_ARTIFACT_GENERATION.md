# FINAL_DELIVERY_CLAIM_WITHOUT_CONFIRMED_ARTIFACT_GENERATION

## Fehlerklasse

`FINAL_DELIVERY_CLAIM_WITHOUT_CONFIRMED_ARTIFACT_GENERATION`

Deutsch:

`AUSLIEFERUNGSBEHAUPTUNG_OHNE_BESTAETIGTE_ARTEFAKTGENERIERUNG`

## Zweck

Diese Fehlerklasse verhindert, dass ein Artefakt als erzeugt, geprüft, gehasht oder auslieferbar behauptet wird, wenn die konkrete Dateiexistenz, ZIP-Integrität, Sidecar-Existenz, SHA256-Konsistenz und Verifier-Ausgabe nicht unmittelbar bestätigt wurden.

## Regel

Eine finale Auslieferungsbehauptung ist nur zulässig, wenn alle folgenden Bedingungen erfüllt sind:

1. Die ZIP-Datei existiert physisch.
2. Die Sidecar-Datei existiert physisch.
3. Die ZIP-Datei besteht einen Integritätstest.
4. Die SHA256 der ZIP-Datei stimmt mit der Sidecar-Datei überein.
5. Der interne Verifier des Pakets läuft erfolgreich.
6. Der finale Download-Link zeigt auf die tatsächlich geprüfte Datei.
7. Ein Runtime-Reset, Toolfehler oder unterbrochener Build erzeugt automatisch CONTINUE/BLOCK, nicht PASS.

## Merksatz

Keine finale Artefaktbehauptung ohne bestätigte Datei, Hash, Verifikation und Link.

q.e.d.  
Ingolf Lohmann
