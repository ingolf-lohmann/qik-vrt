# Status

```text
LOCAL_SCRIPT_PACKAGE_READY_FOR_MONTHLY_UPDATE_USE
```

Zeitraum-Voreinstellung:

```text
2026-05-20 bis 2026-06-20
```

Acceptance-Tests:

```text
MONTHLY_GITHUB_FULL_ARTIFACT_UPDATE_ACCEPTANCE_TEST
ZENODO_SCIENTIFIC_PDF_INDIVIDUAL_DEPOSIT_ACCEPTANCE_TEST
NO_EMBEDDED_SECRET_ACCEPTANCE_TEST
```

Fehlerklassen:

```text
MONTHLY_UPDATE_SOURCE_NOT_INVENTORIZED
MONTHLY_UPDATE_REQUIRED_ARTIFACT_NOT_HASHED
MONTHLY_UPDATE_GITHUB_PUSH_WITHOUT_ACCEPTANCE_PASS
ZENODO_SCIENTIFIC_PDF_NOT_INDIVIDUALIZED
ZENODO_PUBLICATION_WITHOUT_EXPLICIT_PUBLISH_FLAG
EMBEDDED_SECRET_IN_UPDATE_PACKAGE
```

## V2 Final Delivery Acceptance

Aktive zusätzliche Fehlerklasse:

```text
FINAL_DELIVERY_CLAIM_WITHOUT_CONFIRMED_ARTIFACT_GENERATION
```

Keine finale Auslieferung ohne bestätigte Datei, Hash, Verifikation und Link.

## V3 Repository + GitHub Persistence Requirement

Aktiver zusätzlicher Acceptance-Test:

```text
REPOSITORY_AND_GITHUB_PERSISTENCE_OF_ACCEPTANCE_CHANGES_TEST
```

Neue Anschlussfehlerklasse:

```text
ACCEPTANCE_CHANGE_NOT_PERSISTED_TO_REPOSITORY_AND_GITHUB
```

Statusgrenze:

Lokal wurde die Regel im Paket materialisiert und verifiziert.  
Externes GitHub-DONE darf erst behauptet werden, wenn `tools/persist_acceptance_change_to_github.py` gegen ein reales GitHub-Remote erfolgreich gepusht hat und der Remote-Zustand nachvollziehbar ist.

q.e.d.  
Ingolf Lohmann

## V4 Monatscontent-Failure

Status:

```text
ACCEPTANCE_TEST_FAILED_FOR_V3_MONTHLY_CONTENT_CLAIM
```

Persistiert in Repository-Schicht:

```text
acceptance/MONTHLY_CONTENT_CLAIMED_BUT_ONLY_UPDATE_SCRIPTS_DELIVERED.md
audit/V3_MONTHLY_CONTENT_ACCEPTANCE_FAILURE_REPORT.json
tools/verify_monthly_content_claim.py
```

GitHub-Persistenzschicht:

```text
tools/persist_monthly_content_acceptance_failure_to_github.py
```

Statusgrenze:

Externes GitHub-DONE darf erst nach realem Push gegen ein echtes Remote behauptet werden.

q.e.d.  
Ingolf Lohmann

## V5 Zenodo Fourth Layer

Status:

```text
ZENODO_FOURTH_PERSISTENCE_LAYER_MATERIALIZED
```

Enthalten:

```text
acceptance/ZENODO_MONTHLY_SCIENTIFIC_PDF_CONTENT_ACCEPTANCE_TEST.md
audit/V4_ZENODO_FOURTH_LAYER_ACCEPTANCE_FINDING.json
tools/verify_zenodo_fourth_layer.py
tools/qikvrt_create_zenodo_monthly_scientific_pdf_plan.py
tools/persist_zenodo_fourth_layer_to_github.py
```

Statusgrenze:

Zenodo-DONE darf erst behauptet werden, wenn pro wissenschaftlichem PDF ein echter Zenodo-Record mit DOI/Record-URL existiert.

q.e.d.  
Ingolf Lohmann

## V6 Cross-Platform Executability

Status:

```text
CROSS_PLATFORM_EXECUTABILITY_ACCEPTANCE_MATERIALIZED
```

Lokaler Prüfstatus:

```text
Python syntax: PASS
Shell syntax: PASS
Unix executable bits: PASS
Windows wrapper structure: PASS
Python CLI help: PASS
```

Statusgrenze:

Echter Windows- und macOS-Runtime-DONE ist erst nach Ausführung auf diesen Zielplattformen zulässig.

q.e.d.  
Ingolf Lohmann
