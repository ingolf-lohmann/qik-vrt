#!/usr/bin/env python3
from __future__ import annotations
import ast, pathlib, shutil, stat, subprocess, sys

ROOT = pathlib.Path(__file__).resolve().parents[1]

REQUIRED = [
    "qikvrt.py", "qikvrt.sh", "qikvrt.cmd", "qikvrt.bat", "qikvrt.ps1",
    "acceptance/CROSS_PLATFORM_SCRIPT_EXECUTABILITY_ACCEPTANCE_TEST.md",
    "audit/V5_CROSS_PLATFORM_EXECUTABILITY_FAILURE.json",
    "docs/CROSS_PLATFORM_EXECUTION.md",
]

def fail(msg: str) -> int:
    print("FAIL " + msg, file=sys.stderr)
    return 1

def check_required() -> tuple[bool, str]:
    for rel in REQUIRED:
        if not (ROOT / rel).is_file():
            return False, f"required file missing: {rel}"
    text = (ROOT / "acceptance/CROSS_PLATFORM_SCRIPT_EXECUTABILITY_ACCEPTANCE_TEST.md").read_text(encoding="utf-8")
    for marker in ["CROSS_PLATFORM_SCRIPT_NOT_EXECUTABLE", "PLATTFORMUEBERGREIFENDES_SKRIPT_NICHT_AUSFUEHRBAR"]:
        if marker not in text:
            return False, f"required marker missing: {marker}"
    return True, "required launchers and markers present"

def check_python_syntax() -> tuple[bool, str]:
    for path in ROOT.rglob("*.py"):
        if ".git" in path.parts or "__pycache__" in path.parts:
            continue
        try:
            ast.parse(path.read_text(encoding="utf-8"))
        except SyntaxError as exc:
            return False, f"Python syntax error in {path.relative_to(ROOT)}: {exc}"
    return True, "Python syntax ok"

def check_shell() -> tuple[bool, str]:
    for path in ROOT.rglob("*.sh"):
        if ".git" in path.parts:
            continue
        if not (path.stat().st_mode & stat.S_IXUSR):
            return False, f"missing executable bit: {path.relative_to(ROOT)}"
        if shutil.which("bash"):
            r = subprocess.run(["bash", "-n", str(path)], cwd=ROOT, capture_output=True, text=True, timeout=5)
            if r.returncode != 0:
                return False, f"bash syntax failed for {path.relative_to(ROOT)}: {r.stderr}"
    return True, "shell syntax and executable bits ok"

def check_windows_wrappers() -> tuple[bool, str]:
    cmd = (ROOT / "qikvrt.cmd").read_text(encoding="utf-8")
    bat = (ROOT / "qikvrt.bat").read_text(encoding="utf-8")
    ps1 = (ROOT / "qikvrt.ps1").read_text(encoding="utf-8")
    for marker in ["exit /b %ERRORLEVEL%", "python", "qikvrt.py"]:
        if marker not in cmd:
            return False, f"qikvrt.cmd missing marker: {marker}"
    if "exit /b %ERRORLEVEL%" not in bat:
        return False, "qikvrt.bat does not propagate exit code"
    for marker in ["$LASTEXITCODE", "qikvrt.py", "exit 127"]:
        if marker not in ps1:
            return False, f"qikvrt.ps1 missing marker: {marker}"
    return True, "Windows wrappers structurally ok"

def check_cli_help() -> tuple[bool, str]:
    r = subprocess.run([sys.executable, str(ROOT / "qikvrt.py"), "--help"], cwd=ROOT, capture_output=True, text=True, timeout=10)
    if r.returncode != 0:
        return False, "qikvrt.py --help failed"
    if "QIKVRT monthly update cross-platform launcher" not in r.stdout:
        return False, "qikvrt.py help text missing expected title"
    return True, "Python CLI help ok"

def main() -> int:
    for check in [check_required, check_python_syntax, check_shell, check_windows_wrappers, check_cli_help]:
        ok, msg = check()
        if not ok:
            return fail(msg)
        print("PASS", msg)
    print("PASS cross-platform script executability acceptance")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
