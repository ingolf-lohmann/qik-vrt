#!/usr/bin/env python3
from __future__ import annotations

import argparse
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]

def run(cmd: list[str]) -> None:
    print("+ " + " ".join(cmd))
    subprocess.run(cmd, cwd=ROOT, check=True)

def main() -> int:
    parser = argparse.ArgumentParser(description="Verify and persist this repository to GitHub.")
    parser.add_argument("--remote", required=True, help="GitHub remote URL")
    parser.add_argument("--branch", default="main", help="Target branch")
    parser.add_argument("--message", default="QIKVRT V2 full content autopersist", help="Commit message")
    parser.add_argument("--no-push", action="store_true", help="Prepare commit but do not push")
    args = parser.parse_args()

    run([sys.executable, "tools/update_sha256sums.py"])
    run([sys.executable, "tools/verify_repository.py"])

    if not (ROOT / ".git").exists():
        run(["git", "init"])

    run(["git", "checkout", "-B", args.branch])

    remotes = subprocess.run(["git", "remote"], cwd=ROOT, text=True, capture_output=True, check=True).stdout.split()
    if "origin" in remotes:
        run(["git", "remote", "set-url", "origin", args.remote])
    else:
        run(["git", "remote", "add", "origin", args.remote])

    run(["git", "add", "."])
    status = subprocess.run(["git", "status", "--porcelain"], cwd=ROOT, text=True, capture_output=True, check=True).stdout.strip()
    if status:
        run(["git", "commit", "-m", args.message])
    else:
        print("No changes to commit.")

    if args.no_push:
        print("Prepared locally. Push skipped because --no-push was set.")
        return 0

    run(["git", "push", "-u", "origin", args.branch])
    print("PASS GitHub persistence command completed")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
