#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]

REQUIRED_FILES = [
    "README.md",
    "LICENSE_NOTICE.md",
    "qikvrt_manifest.json",
    "docs/00_REPAIR_NOTE_V2.md",
    "docs/01_ARTIKEL_PHYSIKALISCHE_FAKTENLAGE.md",
    "docs/02_DRITTES_SEMESTER_ZUSAMMENFASSUNG.md",
    "docs/03_FREIGABELOGIK_URFASSUNG.md",
    "docs/04_AUTOPERSISTENZ.md",
    "curriculum/semester2/quantengravitation_bekannte_mathematik_physik_semester2_v5.tex",
    "curriculum/semester2/quantengravitation_bekannte_mathematik_physik_semester2_v5.pdf",
    "curriculum/semester3/quantengravitation_semester3_abschluss_beweis_v3.tex",
    "curriculum/semester3/quantengravitation_semester3_abschluss_beweis_v3.pdf",
    "archive/qik_vrt_quantenkausalitaet_rechnerarchitektur_semester2_v3.tex",
    "archive/qik_vrt_quantenkausalitaet_rechnerarchitektur_semester2_v3.pdf",
    "archive/qik_vrt_quantengravitation_semester2_beweisskript_v4.tex",
    "archive/qik_vrt_quantengravitation_semester2_beweisskript_v4.pdf",
    "tools/verify_repository.py",
    "tools/update_sha256sums.py",
    "tools/persist_to_github.py",
    "scripts/persist_git.sh",
    "scripts/persist_git.ps1",
    ".github/workflows/verify.yml",
]

MIN_SIZE = {
    "curriculum/semester2/quantengravitation_bekannte_mathematik_physik_semester2_v5.pdf": 30000,
    "curriculum/semester3/quantengravitation_semester3_abschluss_beweis_v3.pdf": 100000,
    "curriculum/semester2/quantengravitation_bekannte_mathematik_physik_semester2_v5.tex": 30000,
    "curriculum/semester3/quantengravitation_semester3_abschluss_beweis_v3.tex": 30000,
}

REQUIRED_TEXT = [
    "Ingolf Lohmann",
    "Quantengravitation",
    "Quantenwirkung",
    "dynamische Raumzeit",
    "Ethik-Zustand",
    "HASH_MATCH",
    "TEST_EXISTS",
    "EXIT_ZERO",
    "ERKENNTNIS_OK",
    "REPOSITORY_STRUCTURE_PASSED_BUT_FULL_CONTENT_NOT_INCLUDED",
]

def forbidden_markers() -> list[str]:
    return [
        "gh" + "p_",
        "github" + "_pat_",
        "-----BEGIN " + "PRIVATE KEY-----",
        "GITHUB" + "_TOKEN=",
        "password" + "=",
        "passwd" + "=",
    ]

def sha256_file(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def fail(msg: str) -> int:
    print(f"FAIL {msg}", file=sys.stderr)
    return 1

def main() -> int:
    missing = [p for p in REQUIRED_FILES if not (ROOT / p).is_file()]
    if missing:
        return fail("missing required files: " + ", ".join(missing))

    small = []
    for rel, min_size in MIN_SIZE.items():
        size = (ROOT / rel).stat().st_size
        if size < min_size:
            small.append(f"{rel}:{size}< {min_size}")
    if small:
        return fail("full content files too small: " + ", ".join(small))

    try:
        manifest = json.loads((ROOT / "qikvrt_manifest.json").read_text(encoding="utf-8"))
    except Exception as exc:
        return fail(f"manifest json invalid: {exc}")

    if manifest.get("version") != "2.0":
        return fail("manifest version must be 2.0")
    if manifest.get("author") != "Ingolf Lohmann":
        return fail("manifest author mismatch")
    if manifest.get("embedded_credentials") is not False:
        return fail("manifest must declare embedded_credentials=false")

    combined_text = ""
    for path in ROOT.rglob("*"):
        if path.is_file() and path.name not in {"SHA256SUMS.txt"} and ".git" not in path.parts and path.suffix.lower() not in {".pdf", ".zip"}:
            try:
                combined_text += "\n" + path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                pass

    for marker in forbidden_markers():
        if marker in combined_text:
            return fail("forbidden secret marker found")

    for marker in REQUIRED_TEXT:
        if marker not in combined_text:
            return fail(f"required text marker not found: {marker}")

    sums_path = ROOT / "SHA256SUMS.txt"
    if sums_path.exists():
        bad = []
        for line in sums_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            expected, rel = line.split(maxsplit=1)
            rel = rel.strip().lstrip("*")
            p = ROOT / rel
            if not p.is_file():
                bad.append(f"missing:{rel}")
                continue
            actual = sha256_file(p)
            if actual != expected:
                bad.append(f"hash:{rel}")
        if bad:
            return fail("SHA256SUMS mismatch: " + ", ".join(bad))

    print("PASS QIKVRT V2 full content repository verification")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
