# Lizenz- und Nutzungsvereinbarung

Urheber und Rechteinhaber: **Ingolf Lohmann**

Sofern nicht ausdrücklich schriftlich anders vereinbart, gilt für die Inhalte dieses Repositories:

**Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International (CC BY-NC-ND 4.0)**

Zusammenfassung:

- Namensnennung erforderlich.
- Keine kommerzielle Nutzung ohne gesonderte schriftliche Vereinbarung.
- Keine Bearbeitung oder abgeleitete Veröffentlichung ohne gesonderte schriftliche Vereinbarung.
- Institutionelle oder kommerzielle Nutzung erfordert eine gesonderte Vereinbarung mit Ingolf Lohmann oder einer von ihm benannten juristischen Person.

Die technischen Prüf- und Persistenzskripte dienen der lokalen Prüfung und GitHub-Persistenz. Ihre Ausführung ersetzt keine Lizenzannahme und keine gesonderte Nutzungserlaubnis für kommerzielle oder institutionelle Zwecke.

q.e.d.  
Ingolf Lohmann
