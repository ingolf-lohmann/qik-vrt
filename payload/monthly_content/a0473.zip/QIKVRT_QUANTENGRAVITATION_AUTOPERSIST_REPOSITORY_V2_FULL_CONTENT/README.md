# QIKVRT Quantengravitation Autopersist Repository V2 Full Content

**Urheber:** Ingolf Lohmann  
**Repository-Status:** vollständigeres Reparaturpaket nach V1-Inhaltslücke  
**Ziel:** Alle in diesem Arbeitsstand relevanten Inhalte, Skripte, PDF-Fassungen, LaTeX-Quellen, Prüfregeln und GitHub-Persistenzmechanismen in einem plattformübergreifend verifizierbaren Repository bündeln.

## Warum V2

V1 enthielt nur die Repository-Struktur und kurze Textauszüge. V2 erzwingt zusätzlich die vollständigen Semester-Artefakte als Pflichtdateien:

- Zweites Semester: mathematisch-physikalisches Skript ohne QIKVRT-/Metaebene
- Drittes Semester: Abschluss-Beweisskript ohne Sprachmischung und ohne unnötige Wiederholungen
- PDF- und LaTeX-Fassung der zentralen Skripte
- archivierte technische Vorfassungen mit QIKVRT-Rechnerarchitekturbezug
- Artikel, Zusammenfassungen, Lizenz, Manifest, Verifier, SHA256SUMS und GitHub-Autopersistenz

## Zentrale physikalische Aussage

Quantengravitation ist die notwendige gemeinsame Grundordnung von quantisierter Wirkung und dynamischer Raumzeit.

Eine Welt mit quantenphysikalischer Materie und dynamischer Raumzeit kann im Fundament nicht dauerhaft aus einer klassischen Raumzeit und davon getrennter Quantenmaterie bestehen. Quantisierte Wirkung und dynamische Raumzeit gehören zusammen.

## Zentrale QIKVRT-Freigabelogik

```text
0  ETHIK-ZUSTAND
   Kein Schaden.
   Keine falschen Behauptungen.
   Keine versteckten Annahmen.

1  HASH_MATCH
   Artefaktidentität stimmt.

2  TEST_EXISTS
   Prüfbarkeit ist vorhanden.

3  EXIT_ZERO
   Zielplattform-Ausführung besteht.

4  ERKENNTNIS_OK
   Schritte sind richtig, vollständig und anschlussfähig.

=> Phi(x) = DONE
```

## Inhalt

```text
curriculum/semester2/   finales Zweitsemester-Skript als .tex und .pdf
curriculum/semester3/   finales Drittsemester-Abschlussskript als .tex und .pdf
archive/                technische Vorfassungen mit QIKVRT-Architekturbezug
docs/                   Artikel, Zusammenfassungen, Freigabelogik, Autopersistenz
tools/                  Verifier, Hash-Erzeugung, GitHub-Persistenz
scripts/                Bash- und PowerShell-Wrapper
.github/workflows/      plattformübergreifende GitHub-Actions-Prüfung
```

## Lokale Prüfung

```bash
python tools/verify_repository.py
```

Erwartung:

```text
PASS QIKVRT V2 full content repository verification
```

## GitHub-Persistenz

Plattformneutral:

```bash
python tools/persist_to_github.py --remote <github-remote-url> --branch main
```

Linux/macOS:

```bash
bash scripts/persist_git.sh <github-remote-url> main
```

Windows:

```powershell
.\scripts\persist_git.ps1 -Remote "<github-remote-url>" -Branch "main"
```

Keine Zugangsdaten sind im Repository enthalten. Authentifizierung muss lokal oder über sichere Umgebungsmechanismen erfolgen.

## Statusgrenze

Lokale Verifikation = lokale Konsistenz.  
ZIP mit SHA256 = transportfähiges Artefakt.  
GitHub-Push = reale Persistenz.  
GitHub-Actions-Matrix = reproduzierbare Prüfung auf Windows, Linux und macOS.

Kein GitHub-DONE ohne realen Push und erfolgreichen Workflow-Lauf.

q.e.d.  
Ingolf Lohmann
