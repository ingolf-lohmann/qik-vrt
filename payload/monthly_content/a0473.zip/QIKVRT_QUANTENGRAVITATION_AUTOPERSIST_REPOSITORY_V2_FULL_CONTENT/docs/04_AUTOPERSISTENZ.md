# Automatisierte Persistenz nach GitHub

Dieses Repository ist so angelegt, dass es plattformübergreifend geprüft und anschließend nach GitHub persistiert werden kann.

## Grundsatz

Keine eingebetteten Geheimnisse. Keine Zugangsdaten im Repository. Keine Scheinfreigabe.

## Voraussetzungen

- Git installiert
- Python 3.10 oder neuer
- GitHub-Repository vorhanden oder durch den Nutzer angelegt
- Schreibrecht auf das Ziel-Repository
- Authentifizierung über lokales Git-Credential-System oder Umgebungsvariablen außerhalb des Repository-Inhalts

## Persistenzwege

Plattformneutral:

```bash
python tools/persist_to_github.py --remote <github-remote-url> --branch main
```

Linux/macOS:

```bash
bash scripts/persist_git.sh <github-remote-url> main
```

Windows:

```powershell
.\scripts\persist_git.ps1 -Remote "<github-remote-url>" -Branch "main"
```

## Statusgrenze

Lokale Prüfung beweist lokale Konsistenz.  
GitHub-Push beweist erfolgreiche Übertragung.  
GitHub-Actions-Lauf beweist reproduzierbare Prüfung auf Zielplattformen.  
Ein öffentlich überprüfbarer Commit belegt externe Persistenz.

q.e.d.  
Ingolf Lohmann
