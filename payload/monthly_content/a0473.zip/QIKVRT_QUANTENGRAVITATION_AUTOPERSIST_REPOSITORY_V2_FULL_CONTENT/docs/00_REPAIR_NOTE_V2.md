# Reparaturnotiz V2

V1 war technisch prüfbar, aber inhaltlich unvollständig. Das ZIP enthielt nur 19 Dateien und kurze Textauszüge. Die vollständigen Semester-Skripte und PDF-/LaTeX-Artefakte waren nicht enthalten.

V2 korrigiert diese Inhaltslücke durch Pflichtaufnahme der vollständigen relevanten Artefakte:

- finales Zweitsemester-Skript als PDF und LaTeX
- finales Drittsemester-Abschlussskript als PDF und LaTeX
- archivierte technische Vorfassungen
- Artikel und Zusammenfassungen
- Manifest, Dateimanifest, SHA256SUMS
- plattformübergreifender Verifier
- GitHub-Actions-Matrix
- Bash-/PowerShell-/Python-Persistenzpfad

Neue Fehlerklasse:

`REPOSITORY_STRUCTURE_PASSED_BUT_FULL_CONTENT_NOT_INCLUDED`

Korrekturregel:

Ein Repository-Paket, das „all das inkludierend“ beansprucht, muss die vollständigen Inhaltsartefakte selbst enthalten und darf sich nicht nur auf Zusammenfassungen, Strukturdateien oder kurze Auszüge stützen.

q.e.d.  
Ingolf Lohmann
