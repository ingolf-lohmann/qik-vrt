param(
  [Parameter(Mandatory=$true)]
  [string]$Remote,
  [Parameter(Mandatory=$false)]
  [string]$Branch = "main"
)
$ErrorActionPreference = "Stop"
python tools\persist_to_github.py --remote $Remote --branch $Branch
