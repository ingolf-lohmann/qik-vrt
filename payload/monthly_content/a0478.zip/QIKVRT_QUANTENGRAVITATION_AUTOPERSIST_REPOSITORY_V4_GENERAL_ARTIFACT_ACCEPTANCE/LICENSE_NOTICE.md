# Lizenz- und Nutzungsvereinbarung

Urheber und Rechteinhaber: **Ingolf Lohmann**

Sofern nicht ausdrücklich schriftlich anders vereinbart, gilt für die Inhalte dieses Repositories:

**Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International (CC BY-NC-ND 4.0)**

Das bedeutet zusammengefasst: Namensnennung erforderlich, keine kommerzielle Nutzung ohne gesonderte schriftliche Vereinbarung, keine Bearbeitung oder abgeleitete Veröffentlichung ohne gesonderte schriftliche Vereinbarung. Institutionelle oder kommerzielle Nutzung erfordert eine gesonderte Vereinbarung mit Ingolf Lohmann oder einer von ihm benannten juristischen Person.

Die technischen Prüf- und Persistenzskripte dienen der Verifikation, Paketierung und GitHub-Persistenz. Diese technische Ausführung ersetzt keine Lizenzannahme und keine gesonderte Nutzungserlaubnis.

q.e.d.  
Ingolf Lohmann
