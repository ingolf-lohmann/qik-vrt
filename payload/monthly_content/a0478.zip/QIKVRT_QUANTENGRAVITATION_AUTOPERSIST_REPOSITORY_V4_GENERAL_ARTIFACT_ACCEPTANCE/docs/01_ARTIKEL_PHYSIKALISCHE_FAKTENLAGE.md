# Warum sich an der physikalischen Grundfaktenlage nach dem Verständnis der Quantengravitation nichts mehr ändern wird

Wenn man sagt, dass sich an der physikalischen Faktenlage nach dem Verständnis der Quantengravitation nichts mehr ändern wird, bedeutet das nicht, dass Forschung beendet wäre. Es bedeutet nicht, dass jedes Detail schon endgültig berechnet, jede Gleichung vollständig gefunden und jedes Experiment durchgeführt wäre.

Es bedeutet: Der grundlegende Zusammenhang ist erkannt. Die Richtung lässt sich nicht mehr sinnvoll zurückdrehen.

Die moderne Physik hat zwei große Säulen. Die Allgemeine Relativitätstheorie zeigt, dass Gravitation keine gewöhnliche Kraft ist, die einfach in einem fertigen Raum wirkt. Gravitation ist die Dynamik der Raumzeit selbst. Masse, Energie und Impuls krümmen Raum und Zeit. Diese gekrümmte Raumzeit bestimmt wiederum, wie sich Materie, Licht und Bewegung verhalten.

Die Quantenphysik zeigt, dass Materie, Felder, Energie und Impuls im Fundament nicht rein klassisch verstanden werden können. Zustände, Felder, Messungen, Energieaustausch und Wechselwirkungen folgen quantenhaften Gesetzmäßigkeiten.

Die Allgemeine Relativitätstheorie sagt: Energie und Impuls krümmen Raumzeit. Die Quantenphysik sagt: Energie und Impuls werden in der realen Welt durch Quantenfelder getragen.

Dann kann die tiefste Beschreibung der Natur nicht dauerhaft so aussehen, dass die Materie quantenphysikalisch ist, die Raumzeit aber im Fundament endgültig klassisch bleibt. Das wäre keine wirkliche Vereinigung, sondern eine dauerhafte Spaltung der Wirklichkeit in zwei unvereinbare Grundordnungen.

Als Näherung kann diese Spaltung funktionieren. Man kann Quantenfelder auf einer festen oder klassischen gekrümmten Raumzeit betrachten. Man kann Gravitation bei niedrigen Energien klassisch behandeln. Aber eine Näherung ist nicht das Fundament.

Das Fundament muss erklären, wie Quantenwirkung und Raumzeitdynamik zusammengehören. Denn die Quelle der Gravitation ist nicht klassisch, wenn Materie und Energie im Fundament quantenphysikalisch sind. Und Gravitation ist nicht bloß Hintergrund, wenn Raumzeit selbst dynamisch ist.

Damit folgt der Kern der Quantengravitation aus der Verbindung bekannter Tatsachen: Raumzeit ist dynamisch, Energie und Impuls krümmen Raumzeit, Materie und Felder sind quantenphysikalisch, Gravitationswellen zeigen eigene dynamische Freiheitsgrade der Gravitation, schwarze Löcher verbinden Gravitation, Quantenphysik, Thermodynamik und Information, und die Planck-Skala zeigt den Grenzbereich gemeinsamer Beschreibung.

Aus diesen Punkten entsteht die zwingende Einsicht: Eine vollständige Grundbeschreibung der Natur muss quantengravitativ sein.

Was sich ändern wird, sind Modelle, mathematische Zugänge, experimentelle Details und Begriffe. Es wird unterschiedliche Wege geben. Einige Ansätze werden scheitern, andere werden präziser werden.

Aber der Kern bleibt.

Nach Einstein fiel die Physik nicht mehr hinter die Einsicht zurück, dass Gravitation Raumzeitdynamik ist. Nach der Quantenphysik fiel die Physik nicht mehr hinter die Einsicht zurück, dass Materie und Energie im Fundament nicht rein klassisch sind. Ebenso wird die Physik nach dem Verständnis der Quantengravitation nicht mehr hinter die Einsicht zurückfallen, dass Quantenwirkung und Raumzeitdynamik im Fundament zusammengehören.

Das Grundprinzip lautet: Wirklichkeit entsteht nicht aus zwei getrennten Fundamenten, einer klassischen Raumzeit hier und einer Quantenwelt dort. Wirklichkeit entsteht aus einer gemeinsamen Ordnung, in der quantisierte Wirkung und dynamische Raumzeit zusammengehören.

Die offene Frage lautet nicht mehr, ob Quantengravitation notwendig ist. Die offene Frage lautet, welche mathematische Form die vollständige Theorie annimmt und wie sie experimentell am tiefsten bestätigt werden kann.

Eine Welt mit quantenphysikalischer Materie und dynamischer Raumzeit verlangt eine gemeinsame Grundordnung. Diese gemeinsame Grundordnung nennen wir Quantengravitation.

Der Kern bleibt: Quantisierte Wirkung und dynamische Raumzeit gehören zusammen.

Damit ist das fundamentalste Wirkprinzip des Universums entschlüsselt.

q.e.d.  
Ingolf Lohmann
