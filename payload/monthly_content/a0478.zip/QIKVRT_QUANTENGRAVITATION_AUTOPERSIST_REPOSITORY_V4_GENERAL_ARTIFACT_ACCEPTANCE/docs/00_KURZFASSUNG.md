# Kurzfassung

Quantengravitation ist die notwendige gemeinsame Grundordnung von quantisierter Wirkung und dynamischer Raumzeit.

Wenn Raumzeit dynamisch ist, Energie und Impuls Raumzeit krümmen und Materie sowie Felder im Fundament quantenphysikalisch sind, kann eine vollständige Grundbeschreibung der Natur nicht dauerhaft aus klassischer Raumzeit und getrennter Quantenmaterie bestehen.

Der Kern bleibt: Quantisierte Wirkung und dynamische Raumzeit gehören zusammen.

q.e.d.  
Ingolf Lohmann
