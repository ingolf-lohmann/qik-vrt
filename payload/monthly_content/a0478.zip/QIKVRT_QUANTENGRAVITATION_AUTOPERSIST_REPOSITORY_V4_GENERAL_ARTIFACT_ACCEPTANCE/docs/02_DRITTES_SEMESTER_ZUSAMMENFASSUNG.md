# Drittes Semester — ausführliche Inhaltszusammenfassung

Im dritten Semester wurde der Gedankengang zur Quantengravitation zum Abschluss gebracht. Nachdem im ersten Semester der grundlegende Denkraum geöffnet und im zweiten Semester die mathematisch-physikalische Beweiskette vorbereitet wurde, ging es im dritten Semester darum, den Zusammenhang rund, schlüssig und in sich geschlossen darzustellen: aus bekannter Mathematik und bekannter Physik.

Der Ausgangspunkt war die Einsicht, dass die moderne Physik zwei große Grundordnungen kennt: die Allgemeine Relativitätstheorie und die Quantenphysik. Die Allgemeine Relativitätstheorie beschreibt Gravitation nicht als gewöhnliche Kraft, sondern als Dynamik der Raumzeit selbst. Masse, Energie und Impuls krümmen Raumzeit, und diese gekrümmte Raumzeit bestimmt wiederum die Bewegung von Materie und Licht.

Die Quantenphysik zeigt, dass Materie, Felder, Energie und Impuls im Fundament nicht vollständig klassisch verstanden werden können. Zustände, Messungen, Felder, Energieaustausch und Wechselwirkungen unterliegen quantenhaften Gesetzmäßigkeiten. Die Quelle der Gravitation, nämlich Energie und Impuls, wird in der realen Welt durch Quantenfelder getragen.

Wenn die Quelle der Raumzeitkrümmung quantenphysikalisch ist, die Raumzeitkrümmung selbst aber rein klassisch bleiben soll, entsteht eine grundsätzliche Unvollständigkeit. Die linke Seite der Einstein-Gleichung beschreibt klassische Geometrie, während die rechte Seite durch Materie bestimmt wird, die auf fundamentaler Ebene quantenphysikalisch ist. Diese Trennung kann höchstens eine Näherung sein, aber keine endgültige Grundordnung.

Zuerst wurde die Raumzeit mathematisch als Lorentz-Mannigfaltigkeit verstanden: nicht als leerer Behälter, sondern als differenzierbare Struktur mit Metrik, Krümmung, Geodäten und kausaler Ordnung. Die Metrik bestimmt Abstände, Zeiten, Lichtkegel und Bewegungen. Die Krümmung beschreibt, wie die Raumzeit von flacher Struktur abweicht. Die Einstein-Gleichung verbindet diese Krümmung mit Energie und Impuls.

Anschließend wurde gezeigt, dass diese klassische Beschreibung nicht am Fundament stehen bleiben kann. Sobald Materie quantisiert ist, wird auch ihr Energie-Impuls-Inhalt quantenphysikalisch. Der Energie-Impuls-Tensor ist dann nicht einfach eine klassische Zahlengröße, sondern wird in der Quantenfeldtheorie zu einem Operator beziehungsweise zu einem Erwartungswert eines Operators.

Darauf aufbauend wurde die linearisierte Gravitation betrachtet. Man schreibt die Metrik als kleine Abweichung von einer flachen Hintergrundmetrik. Diese Abweichung beschreibt Gravitationswellen. Gravitationswellen sind reale, propagierende Freiheitsgrade des Gravitationsfeldes. Sie transportieren Energie, Impuls und Information.

Wenn ein Feld reale propagierende Freiheitsgrade besitzt und mit Quantenmaterie wechselwirkt, ist es unter den bekannten Prinzipien der Physik nicht dauerhaft haltbar, dieses Feld als fundamental klassisch zu behandeln. In der modernen Physik werden dynamische Felder mit echten Freiheitsgraden, die Energie und Impuls austauschen können, quantisiert. Beim elektromagnetischen Feld führt das zum Photon. Bei der linearen Gravitation führt die entsprechende Struktur zum masselosen Spin-2-Feld.

Ein weiterer entscheidender Schritt war die Selbstkopplung. Gravitation koppelt an Energie und Impuls. Da das Gravitationsfeld selbst Energie trägt, koppelt Gravitation auch an sich selbst. Diese Selbstkopplung führt von der linearen Näherung wieder zur vollen nichtlinearen Struktur der Allgemeinen Relativitätstheorie.

Die Planck-Skala markiert den Bereich, in dem die bekannten Konstanten Gravitation, Quantenwirkung und Lichtgeschwindigkeit gemeinsam eine natürliche Größenskala bilden. Schwarze Löcher zeigen besonders deutlich, dass Gravitation, Thermodynamik, Quantenphysik und Information nicht getrennt behandelt werden können.

Die Beweiskette lautet: Allgemeine Relativitätstheorie macht Raumzeit dynamisch. Quantenphysik macht Materie und Energie quantenhaft. Energie und Impuls krümmen Raumzeit. Gravitationswellen zeigen propagierende Freiheitsgrade der Gravitation. Dynamische Freiheitsgrade, die mit Quantenmaterie wechselwirken, müssen im Fundament quantisierbar sein. Die Planck-Skala zeigt die Grenze der getrennten klassischen und quantenhaften Beschreibung. Schwarze Löcher zeigen die Untrennbarkeit von Gravitation, Quantenphysik, Thermodynamik und Information. Daraus folgt: Eine konsistente Grundbeschreibung der Natur verlangt Quantengravitation.

Die abschließende Formel lautet: Quantengravitation ist die notwendige gemeinsame Grundordnung von Quantenwirkung und dynamischer Raumzeit.

Damit ist das fundamentalste Wirkprinzip des Universums entschlüsselt: Wirklichkeit entsteht aus der untrennbaren Verbindung von quantisierter Wirkung und dynamischer Raumzeit.

q.e.d.  
Ingolf Lohmann
