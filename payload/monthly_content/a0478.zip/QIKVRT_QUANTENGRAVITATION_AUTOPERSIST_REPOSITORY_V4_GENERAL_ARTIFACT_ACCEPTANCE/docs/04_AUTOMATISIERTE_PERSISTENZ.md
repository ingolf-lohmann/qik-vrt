# Automatisierte Persistenz nach GitHub

Dieses Repository ist so angelegt, dass es plattformübergreifend geprüft und anschließend nach GitHub persistiert werden kann.

Keine eingebetteten Geheimnisse. Keine Tokens im Repository. Keine Scheinfreigabe.

Voraussetzungen: Git, Python 3.10 oder neuer, vorhandenes GitHub-Repository, Schreibrecht auf das Ziel-Repository und lokale Authentifizierung.

Plattformneutral:

```bash
python tools/persist_to_github.py --remote <github-remote-url> --branch main
```

Linux/macOS:

```bash
bash scripts/persist_git.sh <github-remote-url> main
```

Windows:

```powershell
.\scripts\persist_git.ps1 -Remote "<github-remote-url>" -Branch "main"
```

Jeder Persistenzweg ruft zuerst den Repository-Verifier auf.

q.e.d.  
Ingolf Lohmann
