#!/usr/bin/env python3
from __future__ import annotations
import fnmatch, hashlib, json, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
BASE_REQUIRED_FILES = [
    "README.md","LICENSE_NOTICE.md","STATUS.md","qikvrt_manifest.json","REPOSITORY_FILE_MANIFEST.json","SHA256SUMS.txt",
    "docs/00_KURZFASSUNG.md","docs/01_ARTIKEL_PHYSIKALISCHE_FAKTENLAGE.md","docs/02_DRITTES_SEMESTER_ZUSAMMENFASSUNG.md","docs/03_FREIGABELOGIK_URFASSUNG.md","docs/04_AUTOMATISIERTE_PERSISTENZ.md",
    "tools/verify_repository.py","tools/update_sha256sums.py","tools/persist_to_github.py","scripts/persist_git.sh","scripts/persist_git.ps1",".github/workflows/verify.yml",
    "acceptance/GENERAL_FULL_ARTIFACT_INCLUSION_ACCEPTANCE_TEST.md","acceptance/artifact_inventory.json"]
REQUIRED_TEXT = ["Ingolf Lohmann","Quantengravitation","Quantenwirkung","dynamische Raumzeit","Ethik-Zustand","HASH_MATCH","TEST_EXISTS","EXIT_ZERO","ERKENNTNIS_OK","GENERAL_FULL_ARTIFACT_INCLUSION_ACCEPTANCE_TEST","CLAIMED_OR_REQUIRED_ARTIFACT_NOT_FULLY_INCLUDED"]
def fail(msg): print(f"FAIL {msg}", file=sys.stderr); return 1
def rel(p): return p.relative_to(ROOT).as_posix()
def read(p): return p.read_text(encoding="utf-8")
def files(): return [p for p in ROOT.rglob("*") if p.is_file() and ".git" not in p.parts]
def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for c in iter(lambda:f.read(1024*1024), b""): h.update(c)
    return h.hexdigest()
def token_markers(): return ["gh"+"p_","github"+"_pat_","-----BEGIN "+"PRIVATE KEY-----","GITHUB"+"_TOKEN=","password"+"=","passwd"+"="]
def load_sums():
    d={}
    for line in read(ROOT/"SHA256SUMS.txt").splitlines():
        if line.strip():
            s,p=line.split(maxsplit=1); d[p.strip().lstrip("*")]=s
    return d
def match_any(path, patterns): return any(fnmatch.fnmatch(path, pat) for pat in patterns)
def main():
    missing=[p for p in BASE_REQUIRED_FILES if not (ROOT/p).is_file()]
    if missing: return fail("missing required files: "+", ".join(missing))
    try: manifest=json.loads(read(ROOT/"qikvrt_manifest.json"))
    except Exception as e: return fail(f"manifest json invalid: {e}")
    if manifest.get("author")!="Ingolf Lohmann": return fail("manifest author mismatch")
    if manifest.get("embedded_tokens") is not False: return fail("manifest must declare embedded_tokens=false")
    combined=""
    for p in files():
        if p.name=="SHA256SUMS.txt": continue
        try: combined += "\n"+read(p)
        except UnicodeDecodeError: pass
    for m in token_markers():
        if m in combined: return fail("forbidden secret marker found")
    for m in REQUIRED_TEXT:
        if m not in combined: return fail(f"required text marker not found: {m}")
    inv=json.loads(read(ROOT/"acceptance/artifact_inventory.json"))
    declared=inv.get("declared_artifacts",[])
    if not declared: return fail("artifact inventory has no declared artifacts")
    required=set(BASE_REQUIRED_FILES); seen=set()
    for a in declared:
        path=a.get("path")
        if not path: return fail("artifact with missing path in inventory")
        p=ROOT/path
        if not p.is_file(): return fail(f"declared artifact missing: {path}")
        seen.add(path)
        if a.get("required") is True: required.add(path)
        mb=a.get("min_bytes")
        if isinstance(mb,int) and p.stat().st_size<mb: return fail(f"declared artifact below min_bytes: {path}")
    for p in files():
        r=rel(p)
        if r in {"SHA256SUMS.txt","REPOSITORY_FILE_MANIFEST.json"}: required.add(r); continue
        if r not in seen: return fail(f"repository file not declared in artifact inventory: {r}")
    repo_paths=[rel(p) for p in files()]
    for cls in inv.get("artifact_classes",[]):
        if not cls.get("required_for_pass",False): continue
        pats=[]
        if "glob" in cls: pats.append(cls["glob"])
        pats += cls.get("globs",[])
        matched=[p for p in repo_paths if match_any(p,pats)]
        large=[p for p in matched if (ROOT/p).stat().st_size >= int(cls.get("min_bytes_each",0))]
        if len(large)<int(cls.get("min_count",0)): return fail(f"artifact class {cls.get('class_id')} failed")
        required.update(large)
    fm=json.loads(read(ROOT/"REPOSITORY_FILE_MANIFEST.json"))
    fmpaths={e.get("path") for e in fm.get("files",[])}
    for p in required:
        if p!="REPOSITORY_FILE_MANIFEST.json" and p not in fmpaths: return fail(f"file manifest does not include required artifact: {p}")
    sums=load_sums()
    for p,s in sums.items():
        fp=ROOT/p
        if not fp.is_file(): return fail(f"SHA256SUMS covers missing file: {p}")
        if sha(fp)!=s: return fail(f"SHA256SUMS mismatch: {p}")
    for p in required:
        if p!="SHA256SUMS.txt" and p not in sums: return fail(f"SHA256SUMS does not cover required artifact: {p}")
    print("PASS QIKVRT V4 general artifact acceptance repository verification")
    return 0
if __name__=="__main__": raise SystemExit(main())
