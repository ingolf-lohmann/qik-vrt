# QIKVRT Quantengravitation Autopersist Repository V4

**Urheber:** Ingolf Lohmann  
**Status:** vollständiges Artefakt-Repository mit allgemeinem Artefakt-Acceptance-Test  
**Ziel:** Inhalte, Skripte, Nachweise und Automatisierung so bündeln, dass das Repository plattformübergreifend geprüft und nach GitHub persistiert werden kann.

## Kern

Quantengravitation wird als notwendige gemeinsame Grundordnung von quantisierter Wirkung und dynamischer Raumzeit verstanden.

Die tragenden physikalischen Punkte sind: Raumzeit ist dynamisch, Energie und Impuls krümmen Raumzeit, Materie und Felder sind quantenphysikalisch, Gravitation besitzt propagierende Freiheitsgrade, schwarze Löcher verbinden Gravitation, Quantenphysik, Thermodynamik und Information, und die Planck-Skala markiert den Grenzbereich gemeinsamer Beschreibung.

Daraus folgt: Eine vollständige Grundbeschreibung der Natur kann nicht dauerhaft aus klassischer Raumzeit und getrennter Quantenmaterie bestehen. Quantisierte Wirkung und dynamische Raumzeit gehören im Fundament zusammen.

## Allgemeiner Artefakt-Acceptance-Test

Dieses Repository enthält nicht nur eine Struktur, sondern einen allgemeinen Acceptance-Test für jegliche Artefakte:

```text
GENERAL_FULL_ARTIFACT_INCLUSION_ACCEPTANCE_TEST
```

Fehlerklasse:

```text
CLAIMED_OR_REQUIRED_ARTIFACT_NOT_FULLY_INCLUDED
```

Die Regel gilt allgemein für PDF, LaTeX, Markdown, DOCX, PPTX, XLSX, ZIP, JSON, Quellcode, Skripte, Reports, Audits, Manifeste, Bilder, Daten, Modelle, Build-Artefakte und Nachweisdateien.

Merksatz:

```text
Struktur-PASS ohne vollständige Artefakte ist kein Repository-PASS.
```

## Lokale Prüfung

```bash
python tools/verify_repository.py
```

Erwartetes Ergebnis:

```text
PASS QIKVRT V4 general artifact acceptance repository verification
```

## Persistenz nach GitHub

```bash
python tools/persist_to_github.py --remote <github-remote-url> --branch main
```

Keine Zugangsdaten sind im Repository enthalten. Authentifizierung erfolgt lokal oder über sichere Umgebungsmechanismen außerhalb des Repository-Inhalts.

q.e.d.  
Ingolf Lohmann


## V4.1-Präzisierung

Die Vollständigkeitsprüfung ist allgemein für jegliche Artefakte formuliert. Sie erzwingt nicht nur konkrete Semesterdateien, sondern jedes behauptete, erforderliche oder release-relevante Artefakt über Inventar, Pflichtstatus, Manifest und SHA256SUMS.
