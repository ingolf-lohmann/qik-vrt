# GENERAL_FULL_ARTIFACT_INCLUSION_ACCEPTANCE_TEST

## Fehlerklasse

`CLAIMED_OR_REQUIRED_ARTIFACT_NOT_FULLY_INCLUDED`

## Zweck

Dieser Acceptance-Test verhindert, dass ein Repository einen PASS-, READY- oder DONE-Status erhält, obwohl nur Struktur, Kurztexte, Platzhalter, Auszüge oder Verifier enthalten sind, aber die eigentlichen Artefakte fehlen.

Die Regel gilt allgemein für jegliche Artefakte: PDF, LaTeX, Markdown, DOCX, PPTX, XLSX, ZIP, JSON, Quellcode, Skripte, Reports, Audits, Manifeste, Bilder, Daten, Modelle, Build-Artefakte und Nachweisdateien.

## Grundregel

Ein Artefakt gilt nur dann als enthalten, wenn sein vollständiger Artefaktkörper im Repository vorhanden ist, im Artefaktinventar steht, durch SHA256SUMS abgedeckt wird, vom Verifier geprüft wird und seine Rolle im Repository nachvollziehbar ist.

## Acceptance-Kriterien

Ein Repository-PASS ist nur zulässig, wenn alle deklarierten Pflichtartefakte physisch vorhanden sind, plausible Mindestgröße besitzen, in `artifact_inventory.json` geführt werden, in `SHA256SUMS.txt` abgedeckt werden, im Repository-Dateimanifest geführt werden und vom Verifier erzwungen werden.

## Merksatz

Struktur-PASS ohne vollständige Artefakte ist kein Repository-PASS.

q.e.d.  
Ingolf Lohmann


## Präzisierung V4.1

Der Test ist allgemein für jegliche Artefakte formuliert. Darum darf die Mindestgröße nicht blind aus einem Dateityp abgeleitet werden. Ein PDF kann kurz und dennoch vollständig sein; ein JSON kann klein und dennoch vollständig sein. Entscheidend ist:

- Das Artefakt ist als Pflichtartefakt deklariert.
- Der vollständige Artefaktkörper liegt physisch vor.
- Das Artefakt steht im Artefaktinventar.
- Das Artefakt ist durch SHA256SUMS abgedeckt, soweit es nicht selbst die Hashliste ist.
- Das Artefakt ist im Dateimanifest geführt, soweit es nicht selbst das Dateimanifest ist.
- Der Verifier erzwingt diese Bedingungen.

Für konkrete Artefaktfamilien können strengere Mindestgrößen oder Inhaltsmarker ergänzt werden. Die allgemeine Regel bleibt artefaktklassenübergreifend.
