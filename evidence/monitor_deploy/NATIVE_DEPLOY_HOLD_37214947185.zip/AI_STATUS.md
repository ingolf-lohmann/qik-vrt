# Exact existing Mesh monitor deployment

HOLD_RAILWAY_SERVER_CREDENTIAL_UNAVAILABLE

{
  "PREDECESSOR_EVIDENCE_TRANSFER": false,
  "effect_ack_done": false,
  "executor_head": "af44ec730bbc533b8fc4141251c604a71312a08b",
  "executor_ref": "candidate/mesh-monitor-mirror-20261004-29a55ae4",
  "mutation_count": 0,
  "public_url": "https://mesh-monitor-production.up.railway.app",
  "schema": "qikvrt-monitor-deployment-receipt/v1",
  "service_id": "dc3773e0-d057-4779-b9c1-9ca0f2074f69",
  "source_head": "674aa35ec0659119a19cda66b88f32050e34f105",
  "source_repository": "ingolf-lohmann/qik-vrt",
  "source_tree": "5100b66a299ded9ecb64622d2d36a5a77ef1f85d",
  "state": "HOLD_RAILWAY_SERVER_CREDENTIAL_UNAVAILABLE"
}
