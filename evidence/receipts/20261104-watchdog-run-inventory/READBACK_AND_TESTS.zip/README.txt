Watchdog source repair: bounded run inventory and job readback.

Read VALIDATION.json for exact source hashes and evidence limits.
Historical run 41759139590 was not rerun; its 213/100 failure remains separate.
The recorded current 356-run history was replayed through the repaired collector.
It reaches analysis with 13 job requests and correctly retains the actual gate failure.
Local make test completed with exit code 0. These tests do not establish deployment.
