# PR #646 – Produktions-Gate für raumzeitterminal.de

Prüfung am 31. Oktober 2026, ca. 03:35–03:42 Uhr Europe/Paris (CET).
Auftrag: frische GitHub-Nachweise und Main zurücklesen; erstes offenes Produktions-Gate und kleinsten zulässigen Verifikationsschritt bestimmen.

## Ergebnis

Das aktuell unmittelbar beobachtete native Zulassungsgate ist **ADMITTED_MESH_RUNTIME_ENDPOINT**.
Der authentifizierte bestehende Terminaladapter meldet operator_authorized=true, native_available=false und ready=false.
Kein beobachteter Endpunkt weist den gemeinsamen Mesh-Kontext nach. Das ist kein Beweis, dass nirgends eine Runtime existiert.

Der erste belegte Anschlussfehler im bestehenden GitHub-Hostpfad liegt **vor dem authentifizierten GET /v1.45/info**:
Die tatsächliche Zustellung der fünf geschützten Originalmaterialien an den consuming job ist nicht nachgewiesen.
Der aktuelle Main-Lauf belegt für seinen damaligen Ausführungszeitpunkt fünf leere Eingaben.
Ein heutiger globaler Credential-Mangel, eine verlorene Anmeldung oder ein bestimmter Fehler der SSO-Provisionierung ist damit nicht bewiesen.

## Exakte Gegenstände

| Gegenstand | HEAD | TREE | Status |
| --- | --- | --- | --- |
| Main | 5a42baf45748e4407a8fa16aef287a77873e788d | 3f6e816b6b496eeb9ce8777d8fb93d95717be9ae | Merge #644; am Ende erneut unverändert gelesen |
| PR #646 | ca3ffb0df80ed11e0dc28b73ee2c0dba53cd1e5a | 0d524178794f90af4bbfdae0cbcc5669f1bc1205 | offen, kein Draft, mergeable=true; nicht integriert |

PR #646: https://github.com/ingolf-lohmann/qik-vrt/pull/646
Main: https://github.com/ingolf-lohmann/qik-vrt/commit/5a42baf45748e4407a8fa16aef287a77873e788d
PR-Commit: https://github.com/ingolf-lohmann/qik-vrt/commit/ca3ffb0df80ed11e0dc28b73ee2c0dba53cd1e5a

## Getrennte Nachweise

| Ebene | Tatsächlich zurückgelesener Befund | Grenze |
| --- | --- | --- |
| Lokale Lean-/Manuskriptkorrektheit | PR/Commit dokumentieren 16 kernelgeprüfte neue Theoreme und lokale Prüfergebnisse. In dieser Sitzung keine Lean-Neuberechnung. | Modell-/Quelldokumentation ist keine Produktionsabnahme. |
| Native PR-CI | Push 41100054467, PR 41100064667 sowie Manuskript Push 41100054498 / PR 41100064765 melden success am HEAD ca3ffb0d… | Der Text „native CI required“ ist für diese einzelnen Läufe überholt. Keine globale Grünmeldung. |
| TEMDD/Integration | 41100064794 ist cancelled; technischer Review 5716528772 ist CHANGES_REQUESTED am exakten PR-HEAD/TREE. Einzelne Jobschritte sind success, die Run-Conclusion bleibt cancelled. | Ursache des Abbruchs nicht abschließend untersucht; keine automatische Wiederholung, kein Merge aus mergeable=true. |
| Main-CI | 41058939212 insgesamt failure; test, Linux S1 und Browserjobs success; Hostjob failure, Domainabnahme skipped. | CI-/Container-Smoke ist keine Abnahme des Originalhosts. |
| Native Zulassung | Bestehender authentifizierter Adapter: operator_authorized=true, ready=false, Gate ADMITTED_MESH_RUNTIME_ENDPOINT. | Site-lokale Identität beweist keine Originalruntime-SSO-Identität. Keine native Eingabe oder Ausführung. |
| Originalmaterial/Host | Job 124080484199 erhält fünf leere Eingaben und endet vor dem Identitäts-GET. | Historischer Jobzustand, kein heutiger Secret-Inventarnachweis. Keine Host-Identität, Paket-, Restart- oder Toggle-Abnahme. |
| Exakte Domain | Neuer GET ohne Redirect am 2026-10-31T02:38:53.088Z: HTTP 525. | Keine erfolgreiche TLS-/Terminalauslieferung und keine bewiesene TLS-Ursache. |
| Zenodo | PR hält neue wissenschaftliche Archivierung und öffentlichen Byte-/DOI-Nachweis offen. | Kein neuer Live-Zenodo-Readback in dieser Sitzung. Keine Veröffentlichung bestätigt oder ausgeschlossen. |
| EFFECT_ACK_DONE | Keine neue produktive Abschlussquittung; Adapter und öffentlicher Snapshot false. | Frühere scoped completion receipts aus STATUS.md übertragen sich nicht auf diesen Produktionsauftrag. |

PR-CI: https://github.com/ingolf-lohmann/qik-vrt/actions/runs/41100064667
Push-CI: https://github.com/ingolf-lohmann/qik-vrt/actions/runs/41100054467
Manuskript: https://github.com/ingolf-lohmann/qik-vrt/actions/runs/41100064765
TEMDD: https://github.com/ingolf-lohmann/qik-vrt/actions/runs/41100064794
Review: https://github.com/ingolf-lohmann/qik-vrt/pull/646#pullrequestreview-5716528772
Main-Hostjob: https://github.com/ingolf-lohmann/qik-vrt/actions/runs/41058939212/job/124080484199

## Host-Artefakt: tatsächliche Bytes

Run 41058939212, Job 124080484199, Artefakt 12978239063:
https://github.com/ingolf-lohmann/qik-vrt/actions/runs/41058939212/artifacts/12978239063

ZIP: 514 Bytes.
SHA-256: 58f3509b5b5571cfa0ce0c73412a5770089f2d8833b729484d2ab6b3c4904d8b.
Download gegen den GitHub-Artefaktdigest unabhängig gehasht.
Einziger ZIP-Eintrag: host-material-delivery.json.

Die Quittung bindet exakt Main-HEAD/TREE und environment=qikvrt-production.
state=HOLD_PROTECTED_INPUT_DELIVERY; scope=JOB_INPUT_PRESENCE_ONLY.
Alle fünf Präsenzwerte sind false:
QIKVRT_HOST_BINDING, QIKVRT_HOST_BINDING_SHA256, QIKVRT_HOST_CA, QIKVRT_HOST_CERT, QIKVRT_HOST_KEY.
job_credential_delivery_verified=false; host_identity_verified=false; effect_ack_done=false.

Das Workflow-Mapping verwendet zwei Environment-Variablen
QIKVRT_LINUX_HOST_BINDING_JSON / QIKVRT_LINUX_HOST_BINDING_SHA256 und drei Environment-Secrets
QIKVRT_LINUX_HOST_CA / QIKVRT_LINUX_HOST_CERT / QIKVRT_LINUX_HOST_KEY.
Das Log nennt Secret source: Actions. Das beweist keine bestimmte vorgelagerte Fehlerursache.

## Öffentlicher frischer Readback

Snapshot e658640f-ca1d-4087-9e5d-d020db92a6ca.
Abgeschlossen: 2026-10-31T02:38:53.911Z = 03:38:53 CET.
12807 UTF-8-Bytes.
SHA-256: 62d6ee9e7f41641e4734f03ccaa0789f9a7fdedb264b9c20e6ee06949d0d5281.
Bestehender unabhängiger Readback meldet byte_verified=true; anschließend hier erneut über exakte snapshot_json-Bytes gehasht.
https://qikvrt-scheibenhard.ingolf-lohmann.chatgpt.site/api/readback?id=e658640f-ca1d-4087-9e5d-d020db92a6ca

Authority-HEAD/TREE stimmen mit dem GitHub-Connector überein.
Runtime im öffentlichen Node-Verzeichnis: NOT_ADVERTISED / UNKNOWN.
Keine Übertragung eines alten Mirror-404 auf den heutigen globalen Mirrorzustand:
Der Snapshot hält den Zugriffsbefund vom 9. Oktober als HISTORICAL_ACCESS_BLOCK fest und hat ihn nicht erneut angefragt.

## Kleinster zulässiger nächster Verifikationsschritt

**Genau einen lesenden, an den exakten aktuellen Main gebundenen Originalruntime-/SSO-Binder-Readback über den bestehenden Originalpfad durchführen.**

Vorbedingung für die native Ausführung ist eine material geänderte, unabhängig nachgewiesene Bindung an den vorhandenen Originalruntime mit gemeinsamem mesh_id=qik-vrt / scope=MESH. Der gegenwärtige ready=false-Befund lässt prepare/commit nicht zu.

Am Originalprozess den vorhandenen Prüfer
tools/qikvrt_authority_credentials.py::production_environment(..., write=False)
unter der tatsächlich ursprünglichen live beobachteten SSO-Sitzung und geschützter Authority-Berechtigung verwenden.
Die Prüfung bleibt schreibfrei; die vorhandene Funktion liefert state=READBACK_ONLY und mutation_count=0.

Die nicht geheimen Ergebnisse müssen insbesondere getrennt zeigen:
- expected_main_sha und source_tree identisch zum frisch beobachteten Main;
- implementation_source_verified=true für die saubere Originalruntime;
- protected_material_available und protected_material_reason;
- bei gewählter Datei-Quelle: Prüfung des bestehenden privaten Deskriptors über QIKVRT_PRODUCTION_MATERIAL_SOURCE und den unabhängig freigegebenen SHA256-Pin, ohne Pfade oder Material zu veröffentlichen;
- binding_sha256 sowie vorhandene Variablen-Gleichheit; Secret-Metadaten bleiben ausdrücklich kein Wert-/Zustellbeleg;
- prior_attempt_state aus dem Originaljournal, damit ein unklarer früherer Effekt ausschließlich zurückgelesen wird.

Dieser Readback grenzt die Ursache ein. Er beweist noch keine Zustellung an den consuming job.
Erst bei kausal reparierter Originalbindung darf die bestehende geschützte Übergabe einmal ausgeführt und deren tatsächliche fünf Job-Eingaben unabhängig geprüft werden.
Danach folgt als eigener Gate der vorhandene mTLS GET /v1.45/info, gebunden an HEAD/TREE, Manifest, Image, Binding und Checker; erst ein frischer gültiger Host-Identitätsbeleg öffnet weitere zulässige Hostschritte.
Paketprüfung, Neustart/Toggle, exakte Domain-Terminalabnahme, Zenodo und produktives EFFECT_ACK_DONE behalten jeweils ihre eigene Abnahme.

Implementierte bestehende Prüffunktion:
https://github.com/ingolf-lohmann/qik-vrt/blob/5a42baf45748e4407a8fa16aef287a77873e788d/tools/qikvrt_authority_credentials.py#L368
Originalmaterial-Vertrag:
https://github.com/ingolf-lohmann/qik-vrt/blob/5a42baf45748e4407a8fa16aef287a77873e788d/state/work_units/QIKVRT_PRODUCTION_ORIGINAL_MATERIAL_SOURCE_20261029.json
Hostworkflow:
https://github.com/ingolf-lohmann/qik-vrt/blob/5a42baf45748e4407a8fa16aef287a77873e788d/.github/workflows/qikvrt_ci.yml#L1673

## Durchgeführte und unterlassene Effekte

Durchgeführt: GitHub-GETs, Download/Hashprüfung des bestehenden nicht geheimen Host-Artefakts,
bestehender Zulassungsabruf, öffentliche Beobachtung samt ihrer bestehenden Persistenz und unabhängiger Byteprüfung, Sicherung dieses Prüfprotokolls.
Keine Repository-Quellen geändert, kein PR gemergt, kein Workflow redispatched, keine geschützten Eingaben geschrieben oder exportiert,
kein native prepare/commit, kein Hostaufruf, Neustart, Toggle oder Zenodo-Schreibvorgang.

## Grenzen der eigenen Nachweiskette

Die beigefügten JSON-Dateien behalten die verfügbaren ursprünglichen GitHub-Ergebnisse einschließlich Fehlern. Dieses Paket behauptet kein lückenloses Mitschnittprotokoll jedes internen Toolaufrufs.
Zwei Workflow-spezifische Collection-URLs wurden vom Connector als INVALID_ARGUMENT abgewiesen.
Die unterstützte actions/runs-Collection mit event-/head_sha-Filtern lieferte die benötigten Main-Läufe ohne Providerwechsel.
Der erste lokale Aufruf des originalen Preflight-Prüfers konnte wegen der noch nicht lokal gelesenen Originalabhängigkeit tools.qikvrt_subprocess nicht starten.
Nach Lesen genau dieser Main-Datei waren die verwendeten deklarierten Action-Prüfungen gültig.
Policy-SHA256: 6e8af800d796d8eebeec9dbbf0c91e8eed2995e02ba0469bcdff43f2189b9ad8.
Der Preflight prüft deklarierte Metadaten, keine tatsächlichen Credentials oder Produktionseffekte.
Temporäre Download-URLs und private Caller-Identität sind aus dem abzugebenden Paket ausgeschlossen.

Menschlicher Auftrag, Ziel und Freigaben: Ingolf Lohmann.
Prüfung, Abgleich und Formulierung dieses Protokolls: OpenAI Codex.

## Ablagegrenze

Die neue öffentliche Beobachtung wurde im bestehenden Journal persistiert und unabhängig bytegeprüft.
Die anschließende dauerhafte Ablage dieses gesamten Prüfarchivs wurde vor der Speicheraktion mit library_storage_limit_exceeded abgewiesen.
Kein erfolgreicher Library-Save, keine neue Library-Identität und keine Löschung bestehender Dateien werden behauptet.
Das Prüfarchiv bleibt als Sitzungsdownload vorhanden. Die Speicherstörung betrifft diese Ablage, nicht die unabhängig geprüften GitHub-Ergebnisse oder den persistierten öffentlichen Snapshot.
Ohne materiell geänderten Speicherzustand erfolgt kein unveränderter Upload-Retry.

