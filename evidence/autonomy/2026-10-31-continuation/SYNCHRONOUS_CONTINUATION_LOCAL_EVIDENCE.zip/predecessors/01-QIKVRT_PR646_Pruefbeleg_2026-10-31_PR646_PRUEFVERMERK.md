# Prüfvermerk: QIK-VRT PR #646

Stand: 31. Oktober 2026 (Europe/Paris). Letzte API-Rücklesung: 2026-10-31T02:38:27.498Z.
Auftrag: aktuellen exakten Kandidaten prüfen und den kleinsten zulässigen nächsten Repository-Schritt eingrenzen.
In dieser Prüfung wurden keine Repository-Refs, Reviews, Workflows oder Zenodo-Inhalte verändert.

## Exakte Bindung

- Repository: ingolf-lohmann/qik-vrt
- PR: https://github.com/ingolf-lohmann/qik-vrt/pull/646
- HEAD: ca3ffb0df80ed11e0dc28b73ee2c0dba53cd1e5a
- TREE: 0d524178794f90af4bbfdae0cbcc5669f1bc1205
- Einziger Parent: 4b18b2c93fe628e4a5fcb3cf1f03dbba29e36df8
- Main: 5a42baf45748e4407a8fa16aef287a77873e788d
- Main-TREE: 3f6e816b6b496eeb9ce8777d8fb93d95717be9ae
- PR: offen, kein Draft, nicht gemergt; mergeable=true, mergeable_state=unstable.
- Der ausgewiesene synthetische merge_commit_sha eines offenen PR ist kein vollzogener Merge.

## Lokale Lean- und Manuskriptbefunde

Der eingecheckte LOCAL_KERNEL_RECEIPT.json dokumentiert 16 Theoreme, davon 11 axiomfrei und fünf nur mit propext und Quot.sound. Zwei frische Kernelobjekte sind laut Receipt bytegleich; drei falsche Negativkontrollen wurden verworfen. Dies wurde in diesem Review nicht erneut lokal kompiliert.
Der PR dokumentiert volle lokale make-test-Korrektheit mit Exit 0. Die historischen Markdown-/PDF-Artikel sind zwischen dem aktuellen Main und dem Kandidaten anhand identischer Git-Blob-IDs bestätigt; ihre Werte stehen in HISTORICAL_ARTICLE_EQUALITY.json.
Die formalen Sätze beweisen die modellierten Verträge unter ihren Voraussetzungen; sie ersetzen keinen realen Transfer-, Publikations- oder Betriebsnachweis.

## Neue native CI ist inzwischen vorhanden

Erfolgreiche exakte Kandidatenläufe:

- Push-CI: https://github.com/ingolf-lohmann/qik-vrt/actions/runs/41100054467
- PR-CI: https://github.com/ingolf-lohmann/qik-vrt/actions/runs/41100064667
- Manuskript-PR-CI: https://github.com/ingolf-lohmann/qik-vrt/actions/runs/41100064765
- Manuskript-Push-CI: https://github.com/ingolf-lohmann/qik-vrt/actions/runs/41100054498

Linux-S1, Chromium und WebKit sind in den beiden Hauptläufen erfolgreich. Das unabhängige Push-Testjoblog bindet TESTED_SUBJECT ausdrücklich an HEAD ca3ffb0df80ed11e0dc28b73ee2c0dba53cd1e5a und TREE 0d524178794f90af4bbfdae0cbcc5669f1bc1205.
Die neue Manuskriptstufe „Check finite recovery and shared evidence contracts“ und die Seed-/Negativkontrollstufe haben im nativen Job 124215652020 conclusion=success.
Frühere CI-Erfolge auf dem Parent werden hierfür nicht übertragen.

## Erster offener Integrationsnachweis

Der einschlägige Lauf „QIKVRT productive TEMDD S1 carrier“ 41100064794, Attempt 1, und Job 124215652007 stehen bei GitHub auf conclusion=cancelled:

https://github.com/ingolf-lohmann/qik-vrt/actions/runs/41100064794

Alle dort aufgelisteten Schritte, Tests und der Artefakt-Upload sind laut Schrittstatus bzw. vollständigem Joblog erfolgreich. Das Artefakt 12997329082 ist vorhanden und nicht abgelaufen; SHA-256 laut GitHub: 95267edbe45f48c6d518b5ba8e448b8a8faa76af90ed1cc20f3da01e85954d64.
Das hebt den gespeicherten cancelled-Zustand nicht auf. Die Abbruchursache lässt sich aus dem ausgelesenen Joblog nicht bestimmen. Ein Quellcodefehler, Timeout oder Concurrency-Konflikt ist damit nicht bewiesen.
Der zusätzliche Annotations-GET ist vom Connector als unzulässiger Endpunkt mit HTTP 400 zurückgewiesen worden. Dies ist eine Beobachtungsgrenze.

Die technische Review 5716528772 ist am exakten HEAD/TREE CHANGES_REQUESTED und nennt genau diesen abgebrochenen Lauf:

https://github.com/ingolf-lohmann/qik-vrt/pull/646#pullrequestreview-5716528772

Der Commitstatus „QIKVRT requested review disposition“ ist failure. Der aktuelle Code-Owner-Status „QIKVRT required code-owner review“ ist dagegen success / OWNER_PRINCIPAL_REVIEW_CURRENT. Das dazugehörige Owner-Ereignis ist COMMENTED mit dem dokumentierten APPROVE-Entscheid am aktuellen HEAD, kein unabhängiges GitHub-APPROVED.
Merge-Bereitschaft ist deshalb nicht nachgewiesen; eine bestehende Owner-Freigabe ersetzt das adverse technische Gate nicht.

## Kleinster zulässiger nächster Repository-Schritt

Den bestehenden TEMDD-Lauf anhand seines Logs, Artefakts und des Plattform-Abbruchzustands kausal aufklären. Sobald die Abbruchursache behoben oder ein einmaliger Wiederanlauf begründet ist, ausschließlich den bestehenden nativen TEMDD-Job/Lauf am unveränderten, unmittelbar neu rückgelesenen HEAD ca3ffb0df80ed11e0dc28b73ee2c0dba53cd1e5a wiederholen. Keine neue Pipeline, kein Leercommit und kein manuelles Umfärben oder Verwerfen der Review ist aus dem Befund begründet.
Nach einem terminal erfolgreichen neuen Lauf die bestehende technische Review-Auswertung für PR 646 neu durchführen und deren Status unabhängig rücklesen. Die vorhandene Workflow-Route ist qikvrt_requested_review_executor.yml (workflow_dispatch input pr=646).
Erst bei aktuellen nicht-adversen Gates und neu beobachtetem Main/HEAD/TREE kann die bestehende bedingte Merge-Freigabe angewendet werden. Ein tatsächlicher Merge benötigt danach eigene Main-/Tree-/Eltern- und Main-CI-Rücklesungen.

## Zenodo getrennt

Das REVISION_MANIFEST.json am Kandidaten lautet AUTHOR_REVIEW_DRAFT_ZENODO_ARCHIVE_PENDING.
Die eingesehenen Artikel- und PR-Nachweise liefern keinen an diese neuen Artikelbytes gebundenen öffentlichen Zenodo-Record mit DOI und bytegenauem Rückdownload. Eine tatsächliche Veröffentlichung wurde nicht durch eine aktuelle Zenodo-Abfrage ausgeschlossen; sie ist hier nicht nachgewiesen.
Ein Revision-Manifest ist kein produktiver v2-Publikationsvertrag. Der vorhandene Publikationspfad verlangt insbesondere kandidatengebundene Claim-/Proof- und Quellenbindung, einen sichtbaren Änderungshinweis sowie den v2-Vorab-Rückgabe-Receipt und die exakte Upload-Entscheidung vor einer Mutation. Vorherige Reservoirs und Tokens sind weder neue Veröffentlichung noch ein Nachweis globaler Credential-Abwesenheit.
Der kleinste nachgelagerte Publikationsvorbereitungsschritt ist die vorhandene v2-Kette für genau die eingefrorenen Revisionsbytes zu vervollständigen bzw. vorhandene Bindungen rückzulesen. Ein Upload wird durch dieses Review nicht ausgelöst.
Die Zenodo-Abnahme benötigt den tatsächlichen publizierten Record/DOI, dessen exakte Dateien und öffentlichen bytegleichen Rückdownload; für Authority-/Mirror-Gleichheit sind zusätzliche eigene Nachweise nötig.

## Betriebsgrenze und Evidenzumfang

Die produktiven Originalhost-, OCI- und exakten Domainjobs sind in den Kandidaten-CI-Läufen übersprungen. Der erneut gelesene Main-Nachweis für raumzeitterminal.de ist historisch (26. Oktober) und trägt exact_domain_client_acceptance=false sowie effect_ack_done=false. Dieses Review liefert keine neue Host-, Domain- oder Produktionsabnahme.
GITHUB_READBACK.json enthält die vollständig erhaltenen relevanten API-Ergebnisse einschließlich der beiden abgerufenen vollständigen Joblogs. Es ist kein lückenloser Mitschnitt sämtlicher lokalen Hilfsoperationen. Frühere einzelne Abruf-Zeitstempel wurden nicht separat erfasst; GitHub-Zeitstempel und die abschließende Rücklesungszeit sind erhalten.

## Verfügbarkeit des Prüfbelegs

Die dauerhafte Ablage wurde mit library_storage_limit_exceeded zurückgewiesen. Der lokale, geprüfte Download bleibt erhalten. Es wurden keine Dateien gelöscht; ohne geänderte Speicherkapazität wird kein identischer Speicherungsversuch wiederholt. Das vollständige Fehlerergebnis steht in SAVE_STATUS.json.
