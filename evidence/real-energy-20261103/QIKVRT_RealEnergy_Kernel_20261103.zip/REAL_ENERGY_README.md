# Reale Energiegrößen — lokaler Kernel-Nachweis vom 3. November 2026

Fortsetzung von e001/e002, e006 und PRE-T01..T05. Anforderungen/Freigabe: Ingolf Lohmann. Ausarbeitung und Prüfung: OpenAI Codex.

Die unveränderte Quelle PlanckRealEnergyDomain.lean aus Checkpoint 0b4c4fc7 v2 wurde mit Original Lean4.19.0 und dem vorhandenen mathlib-Pin c44e0c8ee63ca166450922a373c7409c5d26b00b tatsächlich kompiliert. Ihr SHA-256 bleibt b98e619efab8c6289824c892c4cd5b3e8bcfecead278855f8cc45a6620c7d2ce. PRE-T01..T05 sind damit lokal kernelgeprüft.

Das additive RealErasureBudget-Modul beweist drei weitere Sätze über ℝ:
1. Aus cost>0 und cost*I<=W<=E folgt I<=E/cost.
2. Aus 0<=ΔE<E_P und E_P>0 folgt 0<=ΔE/E_P<1.
3. Der erste Satz spezialisiert sich auf den ausdrücklich vorausgesetzten verfügbaren Arbeitsbetrag E_P.

Die Bedeutung von cost als Landauer-Kosten und die tatsächliche Energiezuführung bleiben physikalische Prämissen. Eine neue Naturgesetz-, Mess-, SI-, Runtime- oder Raumzeitentstehungsbehauptung wird daraus nicht abgeleitet.

Alle acht Sätze wurden im separaten Axiomaudit gefunden. Ihre Standardaxiome sind propext, Classical.choice und Quot.sound; keine Projektaxiome oder Beweisplatzhalter wurden eingeführt. Vier unzulässige Aussagen (Nullkonstante, negative Differenz, überschrittenes Arbeitsbudget und eingeschlossene obere Intervallgrenze) wurden mit echten Lean-Diagnosen auf False zurückgewiesen. Die alten 14 Std-Sätze und deren neun Tests wurden nicht wiederholt.

## Originale Werkzeuge und Reparaturen

Das offizielle Lean-Archiv hat SHA256 6fe3ce97a58f44e2b3567d455b994eacec5bfe9ae7774f2a573444480ba813fe. Die ursprüngliche proc_self_compat.c (SHA256 522eec0ce74508a910e582ee38d822011bcf5323be4cabbd1631276cc91b2226) wird ausschließlich zur vorhandenen lokalen Prozesspfad-Kompatibilität verwendet. Der Lean-Kern bleibt unverändert.

Der mathlib-Cache-Helfer wurde aus dem gepinnten Original gebaut. Namespace-bedingte tar-Eigentümerfehler wurden mit den nativen tar-Optionen --no-same-owner/--no-same-permissions repariert. Der erste leantar-Reparaturversuch führte dessen ursprünglichen abschließenden Umbenennungsschritt noch nicht aus; das wurde am Original Cache.IO-Code erkannt und vervollständigt. Frühere Fehler bleiben in den Logs erhalten. Anschließend wurden 1332 Cachedateien erfolgreich über den originalen öffentlichen Azure-GET-Pfad geladen. Kein Cache-Upload und keine R2-Aktion.

## Native Aufnahme bleibt separat

Der vorhandene .github/workflows/qikvrt_manuscript_proof.yml bindet das bestehende formalization/QIKVRT_Formalization_v2.0-Paket. Dessen exakter Main-Lock hat weiterhin packages=[] und Lean4.19.0. BATCH_01B_PLAN.md (Blob346a8c4fad200bae8065fc6ed492204bcb8dfc38) erlaubt den mathlib-Nachfolger erst mit gebundenen Modulrevisionen und gelocktem Manifest.

Hier wurden der mathlib-Commit, dessen unverändertes Originalmanifest und die Quell-/Binärhashes tatsächlich gebunden. Die lokale Prüfung ist noch keine Aufnahme in den Std-only-Verbraucher. Der nächste Schritt ist eine getrennte, gelockte Aufnahme desselben geprüften Moduls in den bestehenden wissenschaftlichen Kandidaten mit eigenem Satzinventar und Axiomaudit. Keine ungeprüfte Veränderung des bestehenden Std-only-Pakets, kein CI-Dispatch, kein Main-/Review-/Publikationsabschluss und kein siebenfacher unabhängiger Checker-PASS.

Die ursprünglichen e001/e002-Belege, das verlorene vollständige November-2-Prüfarchiv, alle Publisher-/Quota-, Originalhost-/SSO-/Mirror- und R2-Pflichten bleiben erhalten. Das neue Paket ersetzt diese offenen Pflichten nicht.

