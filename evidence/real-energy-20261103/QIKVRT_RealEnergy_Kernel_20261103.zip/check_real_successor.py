from pathlib import Path
import os,json,subprocess,hashlib,re,datetime
b=Path(__file__).resolve().parent;r=json.loads((b/"restored_toolchain.json").read_text());m=b/"mathlib"
env=dict(os.environ);env["LD_PRELOAD"]=r["compat"];env["PATH"]=str(Path(r["lean"]).parent)+os.pathsep+env["PATH"];env["TAR_OPTIONS"]="--no-same-owner --no-same-permissions"
logs=b/"real_verification_logs";logs.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,args,expected=0):
 out=subprocess.run(args,cwd=m,env=env,capture_output=True,text=True,timeout=120)
 raw=out.stdout+out.stderr;(logs/(name+".log")).write_text(raw+"\nEXIT="+str(out.returncode)+"\n")
 valid=(out.returncode==0 if expected==0 else out.returncode!=0 and
        re.search(r"\.lean:\d+:\d+: error:",raw) is not None and
        "unknown module" not in raw and "unknown tactic" not in raw and
        "failed to locate application" not in raw)
 print(name,"exit",out.returncode,"expected",expected,"valid",valid,flush=True)
 return {"name":name,"exit":out.returncode,"expected":"ACCEPT" if expected==0 else "REJECT","pass":bool(valid),"log_sha256":sha(logs/(name+".log"))}
for p in (b/"real_candidate").rglob("*.lean"):
 q=m/p.relative_to(b/"real_candidate");q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
base=m/".lake/build/lib/lean";base.mkdir(parents=True,exist_ok=True)
cases=[]
cases.append(run("real_budget_bridge",[r["lake"],"env","lean","-E","hasSorry","-o",str(base/"RealErasureBudget.olean"),str(m/"RealErasureBudget.lean")]))
if cases[-1]["pass"]:
 cases.append(run("real_axiom_audit",[r["lake"],"env","lean","-E","hasSorry",str(m/"RealEnergyAxiomAudit.lean")]))
 if cases[-1]["pass"]:
  for p in sorted((m/"negative").glob("*.lean")):
   cases.append(run("negative_"+p.stem,[r["lake"],"env","lean","-E","hasSorry",str(p)],1))
srcs={str(p.relative_to(b/"real_candidate")):{"bytes":p.stat().st_size,"sha256":sha(p)} for p in sorted((b/"real_candidate").rglob("*.lean"))}
oldhash="b98e619efab8c6289824c892c4cd5b3e8bcfecead278855f8cc45a6620c7d2ce"
assert sha(b/"real_candidate/PlanckRealEnergyDomain.lean")==oldhash
assert (m/"lake-manifest.json").read_bytes()==(b/"upstream/mathlib/lake-manifest.json").read_bytes()
assert sha(Path(r["lean"]))==r["lean_executable_sha256"]
report={"schema":"qikvrt-real-energy-local-verification/v1","observed_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"original_candidate_sha256":oldhash,"original_candidate_unmodified":True,"original_PRE_T01_T05_compile_exit":0,"new_real_theorems":3,"combined_theorems":8,"checker":"Original Lean4.19.0","mathlib_commit":r["mathlib_commit"],"locked_mathlib_manifest_sha256":sha(m/"lake-manifest.json"),"lean_executable_sha256":r["lean_executable_sha256"],"source_files":srcs,"cases":cases,"pass":len(cases)==6 and all(x["pass"] for x in cases),"native_CI":"NOT_EXECUTED","seven_independent_checkers":"NOT_EXECUTED","SI_calibration":"NOT_ESTABLISHED","empirical_coupling":"NOT_MEASURED"}
(b/"REAL_VERIFICATION.json").write_text(json.dumps(report,indent=2))
print("COMBINED_REAL_THEOREMS=8",flush=True)
raise SystemExit(0 if report["pass"] else 1)

