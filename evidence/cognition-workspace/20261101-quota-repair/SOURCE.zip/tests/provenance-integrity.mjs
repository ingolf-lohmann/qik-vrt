// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Copyright 2026 Ingolf Lohmann. Implementation: OpenAI Codex.
import assert from 'node:assert/strict';
import { readFile, mkdtemp, rm } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';

const sha = b => createHash('sha256').update(b).digest('hex');
const manifest = JSON.parse(await readFile('public/.well-known/qikvrt-provenance.json', 'utf8'));
assert.equal(manifest.files.length, 38);
for(const path of ['app/journal/page.tsx','app/api/v1/shared/route.ts','app/mcp/route.ts','db/schema.ts','lib/authority-source.ts','tests/authority-source.mjs']) assert.ok(manifest.files.some(f=>f.path===path),path);
for (const file of manifest.files) {
  const bytes = await readFile((file.kind === 'static_asset' ? 'public/' : '') + file.path);
  assert.equal(bytes.length, file.bytes, file.path);
  assert.equal(sha(bytes), file.sha256, file.path);
  const container = await readFile('public' + file.container.path);
  assert.equal(container.length, file.container.bytes, file.container.path);
  assert.equal(sha(container), file.container.sha256, file.container.path);
}
assert.equal(manifest.scope.root_html, 'DYNAMIC_NOT_BYTE_FROZEN');
assert.equal(manifest.scope.personal_signature, 'UNVERIFIED');
assert.equal(manifest.scope.native_eap_channel, false);
assert.equal(manifest.scope.productive_effect_ack_done, false);
assert.equal(manifest.standpoint.personal_authentication, false);

// Exercise the actual Worker-response wrapper, including body/status preservation.
const require = createRequire(import.meta.url);
const wrangler = createRequire(require.resolve('wrangler'));
const { build } = wrangler('esbuild');
const temp = await mkdtemp(join(tmpdir(), 'qikvrt-headers-'));
try {
  const output = join(temp, 'headers.mjs');
  await build({entryPoints:['lib/security-headers.ts'],outfile:output,bundle:true,format:'esm',platform:'node',logLevel:'silent'});
  const { withSecurityHeaders } = await import(pathToFileURL(output));
  const response = withSecurityHeaders(new Response('retained body', {status:403,headers:{'Cache-Control':'no-store'}}));
  assert.equal(response.status, 403);
  assert.equal(await response.text(), 'retained body');
  assert.equal(response.headers.get('Cache-Control'), 'no-store');
  assert.equal(response.headers.get('X-Content-Type-Options'), 'nosniff');
  assert.match(response.headers.get('Content-Security-Policy'), /connect-src 'self'/);
  assert.match(response.headers.get('Content-Security-Policy'), /object-src 'none'/);
  const rules = await readFile('public/_headers', 'utf8');
  assert.ok(rules.includes(response.headers.get('Content-Security-Policy')), 'Static assets and Worker use the same policy');
  console.log(JSON.stringify({passed:true,files:manifest.files.length,scope:'local exact bytes, explicit claim boundaries and actual response wrapper; no deployed-header proof'}));
} finally { await rm(temp, {recursive:true,force:true}); }
