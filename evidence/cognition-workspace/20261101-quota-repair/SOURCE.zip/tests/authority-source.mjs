// Real Workerd/D1, synthetic provider. No live GitHub, peers or product effect.
import { createRequire } from 'node:module';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import assert from 'node:assert/strict';
const r = createRequire(import.meta.url), w = createRequire(r.resolve('wrangler'));
const { build } = w('esbuild'), { Miniflare } = w('miniflare');
const temp = await mkdtemp(join(tmpdir(), 'qikvrt-source-'));
const scriptPath = join(temp, 'worker.mjs');
await build({entryPoints:['tests/authority-source-worker.ts'],outfile:scriptPath,bundle:true,format:'esm',platform:'browser',external:['cloudflare:workers'],logLevel:'silent'});
const api='https://api.github.com/repos/ingolf-lohmann/qik-vrt/';
const keys='https://token.actions.githubusercontent.com/.well-known/jwks';
const head='a'.repeat(40), commit=api+'git/commits/'+head;
const source=api+'contents/state/autonomy/WORKFLOW_EXECUTOR_MESH_CONTRACT_V1.json?ref='+head;
const main=api+'git/ref/heads/main', run=api+'actions/runs/71';
let calls=[], reply=()=>Response.json({original:'public-source'}), mf, checks=0;
function check(label){checks++; console.log('PASS '+checks+' '+label);}
function start(){return new Miniflare({modules:true,modulesRoot:temp,scriptPath,compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:['DB'],d1Persist:join(temp,'d1'),cf:false,
 outboundService:async req=>{calls.push({url:req.url,headers:[...req.headers]});return reply(req);}});}
async function call(url){return mf.dispatchFetch('https://fixture.test/?source='+encodeURIComponent(url),{redirect:'manual',headers:{Cookie:'__Host-QIKVRT-Workflow-Identity=synthetic-secret',Authorization:'Bearer synthetic-secret'}});}
async function clear(){const db=await mf.getD1Database('DB');await db.prepare('DELETE FROM cognition_authority_source_cache').run();calls=[];}
try{
 mf=start();
 for(const url of [keys,commit,source]){
  const a=await call(url),b=await call(url);assert.equal(a.status,200);assert.deepEqual(await a.json(),await b.json());
  assert.equal(calls.filter(x=>x.url===url).length,1);
 }check('Original public bytes reused for bounded key/immutable source reads');
 for(const url of [main,run]){await call(url);await call(url);assert.equal(calls.filter(x=>x.url===url).length,2);}
 check('Both Main fences and executing run always make separate fresh requests');
 assert(calls.every(x=>x.headers.every(([k])=>!['cookie','authorization'].includes(k.toLowerCase()))));check('Incoming cookies and Authorization never reach public provider');
 await clear();
 await Promise.all(Array.from({length:12},()=>call(commit)));assert.equal(calls.length,1);check('Concurrent immutable reads share one provider request');
 await clear();
 reply=()=>Response.json({message:'private-denial-never-persist'}, {status:403,headers:{'x-ratelimit-remaining':'0','x-ratelimit-reset':String(Math.ceil(Date.now()/1000)+600)}});
 await call(main);let b=await call(run);assert.equal(b.status,403);assert.equal(calls.length,1);assert.equal(b.headers.get('x-qikvrt-source-request'),'SUPPRESSED_QUOTA_COOLDOWN');
 assert.equal(await b.text(),'');check('One primary quota denial suppresses other GitHub resource calls');
 await mf.dispose();mf=start();calls=[];b=await call(main);assert.equal(b.status,403);assert.equal(calls.length,0);check('D1 quota boundary survives actual isolate disposal and recreation');
 const db=await mf.getD1Database('DB');let rows=(await db.prepare('SELECT * FROM cognition_authority_source_cache').all()).results;
 assert(!JSON.stringify(rows).includes('synthetic-secret'));assert(!JSON.stringify(rows).includes('private-denial-never-persist'));check('Persistence excludes incoming credentials and denial body');
 await db.prepare('UPDATE cognition_authority_source_cache SET until_at = 1').run();reply=()=>Response.json({fresh:true});await call(main);assert.equal(calls.length,1);check('Expired cooldown admits one new observation, without automatic retry');
 await clear();reply=()=>Response.json({denied:true},{status:403});await call(main);await call(run);assert.equal(calls.length,2);check('Unknown 403 is not mislabeled as quota exhaustion');
 await clear();reply=()=>Response.json({denied:true},{status:429,headers:{'retry-after':'120'}});await call(main);await call(run);assert.equal(calls.length,1);check('Secondary 429 honors provider retry boundary');
 await clear();reply=()=>Response.json({public:true},{headers:{'x-ratelimit-remaining':'0','x-ratelimit-reset':String(Math.ceil(Date.now()/1000)+600)}});assert.equal((await call(main)).status,200);assert.equal((await call(run)).status,403);assert.equal(calls.length,1);check('Last successful quota-consuming response preserves result and stops next request');
 await clear();reply=()=>Response.redirect('https://foreign.test/no-follow',302);assert.equal((await call(commit)).status,302);assert.equal(calls.length,1);check('Redirects remain unfollowed and uncached');
 await clear();reply=()=>new Response('x'.repeat(1048577));assert.equal((await call(commit)).status,503);check('Oversized immutable response rejected before caching');
 await clear();for(const url of ['https://foreign.test/',api+'contents/private',api+'git/commits/'+head+'?x=1'])assert.equal((await call(url)).status,503);assert.equal(calls.length,0);check('Only fixed existing public read resources are callable');
 console.log(JSON.stringify({checks,passed:true,scope:'actual Workerd/D1 with synthetic provider; no live quota recovery or productive effect'}));
}finally{await mf?.dispose();await rm(temp,{recursive:true,force:true});}
