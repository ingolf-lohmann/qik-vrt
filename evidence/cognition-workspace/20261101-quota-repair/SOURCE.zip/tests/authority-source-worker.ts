// Test-only transport access. Never part of the production route inventory.
import { authoritySourceFetch } from "../lib/authority-source";
export default { async fetch(request: Request) {
  try { return await authoritySourceFetch(new URL(request.url).searchParams.get("source")!); }
  catch { return new Response("closed", { status: 503 }); }
} };
