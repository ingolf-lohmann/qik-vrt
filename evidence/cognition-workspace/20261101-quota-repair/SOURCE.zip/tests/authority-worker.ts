// Test-only service fixture. Production routes always authenticate real OIDC.
import { env } from "cloudflare:workers";
import original from "./api-worker";
import { admittedTask, acceptTask } from "../lib/authority-intake";
import { authenticateAuthority, authorityReadbackDiagnostics, AuthorityError, type AuthorityIdentity } from "../lib/authority-identity";
import { authoritySourceFetch } from "../lib/authority-source";
import { body, failure, json } from "../lib/workspace";
import { GET as originalAuthorityGet } from "../app/api/v1/authority/tasks/[id]/route";
export default { async fetch(request: Request) {
  const url = new URL(request.url);
  if (url.pathname.startsWith("/api/v1/authority/tasks/")) return originalAuthorityGet(request, { params: Promise.resolve({ id: url.pathname.split("/").at(-1)! }) });
  if (url.pathname === "/qa/readback") return json(await authorityReadbackDiagnostics());
  if (url.pathname === "/qa/authenticate" || url.pathname === "/qa/authenticate-governed") {
    try { return json(await authenticateAuthority(request, url.pathname.endsWith("-governed") ? authoritySourceFetch : fetch)); }
    catch (error) { return error instanceof AuthorityError ? json({ error: { code: error.code } }, error.status) : failure(error); }
  }
  if (!url.pathname.startsWith("/qa/authority/")) return original.fetch(request);
  try {
    const identity = JSON.parse((env as unknown as { QA_IDENTITY: string }).QA_IDENTITY) as AuthorityIdentity;
    return json(request.method === "POST" ? await acceptTask(identity, await body(request)) : await admittedTask(identity, url.pathname.split("/").at(-1)!));
  } catch (error) { return error instanceof AuthorityError ? json({ error: { code: error.code } }, error.status) : failure(error); }
} };
