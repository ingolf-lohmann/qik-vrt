// Isolated crypto and original admission logic with synthetic GitHub responses.
// No production issuer, member or workflow activation is asserted by these tests.
import {createRequire} from 'node:module';
import {mkdtemp,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const r=createRequire(import.meta.url), w=createRequire(r.resolve('wrangler'));
const {build}=w('esbuild'), {Miniflare}=w('miniflare');
const temp=await mkdtemp(join(tmpdir(),'qikvrt-authority-identity-'));
const target=join(temp,'identity.mjs');
await build({entryPoints:['lib/authority-identity.ts'],outfile:target,bundle:true,format:'esm',platform:'node',target:'es2022',logLevel:'silent'});
const mod=await import(pathToFileURL(target));
let checks=0;
function check(ok,label){assert.ok(ok,label);checks++;console.log(`PASS ${checks} ${label}`);}
const encoder=new TextEncoder(), b64=value=>Buffer.from(value).toString('base64url');
const key=await crypto.subtle.generateKey({name:'RSASSA-PKCS1-v1_5',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['sign','verify']);
const jwk={...await crypto.subtle.exportKey('jwk',key.publicKey),kid:'test-key',alg:'RS256',use:'sig'};
const now=Math.floor(Date.now()/1000), head='a'.repeat(40), tree='b'.repeat(40);
const claims={iss:'https://token.actions.githubusercontent.com',aud:mod.AUDIENCE,sub:`repo:${mod.AUTHORITY}:ref:refs/heads/main`,
 iat:now,nbf:now-1,exp:now+300,repository:mod.AUTHORITY,repository_id:'1273784147',repository_owner_id:'294949349',
 ref:'refs/heads/main',workflow_ref:`${mod.AUTHORITY}/${mod.WORKFLOW}@refs/heads/main`,workflow_sha:head,sha:head,
 run_id:'71',run_attempt:'1',event_name:'push'};
const contract={authority:{repository:mod.AUTHORITY},workspace_task_intake:{schema:'qikvrt-workspace-task-intake/v1',enabled:true,
 origin:mod.ORIGIN,audience:mod.AUDIENCE,workflow:mod.WORKFLOW,scope:'VERSIONED_TASK_COORDINATION_ONLY',identity_header:mod.WORKFLOW_IDENTITY_HEADER,identity_cookie:mod.WORKFLOW_IDENTITY_COOKIE,
 productive_effect_authorized:false,effect_ack_done:false,allowed_events:['push'],work_items:[{id:'b50951b4-1194-431b-aa43-d81d262a19d3',min_version:1}]}};
async function token(changed={},header={alg:'RS256',typ:'JWT',kid:'test-key'}){
 const input=`${b64(JSON.stringify(header))}.${b64(JSON.stringify({...claims,...changed}))}`;
 return `${input}.${b64(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',key.privateKey,encoder.encode(input)))}`;
}
const identityHeaders=t=>({[mod.WORKFLOW_IDENTITY_HEADER]:`${mod.WORKFLOW_IDENTITY_COOKIE}=${t}`});
const request=t=>new Request(`${mod.ORIGIN}/api/v1/authority/tasks/test`,{headers:identityHeaders(t)});
function provider({changedRun={},changedContract,drift=false,unavailable=false,corruptBlob=false}={}){
 let refReads=0;
 return async url=>{
  if(unavailable)throw new Error('provider unavailable');
  if(url==='https://token.actions.githubusercontent.com/.well-known/jwks')return Response.json({keys:[jwk]});
  if(url.endsWith('/git/ref/heads/main'))return Response.json({ref:'refs/heads/main',object:{type:'commit',sha:drift&&++refReads>1?'f'.repeat(40):head}});
  if(url.endsWith(`/git/commits/${head}`))return Response.json({sha:head,tree:{sha:tree}});
  if(url.endsWith('/actions/runs/71'))return Response.json({id:71,run_attempt:1,head_sha:head,path:mod.WORKFLOW,head_branch:'main',event:'push',status:'in_progress',repository:{full_name:mod.AUTHORITY,id:1273784147},head_repository:{full_name:mod.AUTHORITY},...changedRun});
  if(url.endsWith(`${mod.CONTRACT}?ref=${head}`)){
   const raw=Buffer.from(JSON.stringify(changedContract??contract));
   const blob=Buffer.from(await crypto.subtle.digest('SHA-1',Buffer.concat([Buffer.from(`blob ${raw.length}\0`),raw]))).toString('hex');
   return Response.json({path:mod.CONTRACT,type:'file',encoding:'base64',content:raw.toString('base64'),size:raw.length,sha:corruptBlob?'0'.repeat(40):blob});
  }
  throw new Error(`unexpected provider request ${url}`);
 };
}
try{
 const accepted=await mod.authenticateAuthority(request(await token()),provider(),now);
 check(accepted.run_id===71&&accepted.head===head&&accepted.tree===tree&&accepted.scope==='VERSIONED_TASK_COORDINATION_ONLY','Actual RS256 verification binds run, HEAD, TREE and narrow scope');
 for(const changes of [{aud:'foreign'},{iss:'https://foreign.test'},{exp:now-1},{iat:now-1000,nbf:now-1000},
  {sub:'repo:foreign/repo:ref:refs/heads/main'},{repository:'foreign/repo'},{repository_id:'1'},
  {repository_owner_id:'1'},{ref:'refs/heads/foreign'},{sha:'f'.repeat(40)},
  {workflow_ref:`${mod.AUTHORITY}/foreign.yml@refs/heads/main`},{workflow_sha:'f'.repeat(40)},
  {run_attempt:'2'},{run_id:'999'},{event_name:'schedule'}]){
  const signed=await token(changes);
  await assert.rejects(()=>mod.authenticateAuthority(request(signed),provider(),now));
  check(true,`Signed foreign, stale or replayed claims rejected: ${Object.keys(changes).join(',')}`);
 }
 for(const options of [{changedRun:{status:'completed'}},{changedRun:{head_sha:'f'.repeat(40)}},
  {changedRun:{head_repository:{full_name:'foreign/repo'}}},{changedRun:{path:'foreign.yml'}},
  {changedRun:{run_attempt:2}},{drift:true},{unavailable:true},{corruptBlob:true},
  {changedContract:{...contract,workspace_task_intake:{...contract.workspace_task_intake,enabled:false}}},
  {changedContract:{...contract,workspace_task_intake:{...contract.workspace_task_intake,productive_effect_authorized:true}}}]){
  const signed=await token();
  await assert.rejects(()=>mod.authenticateAuthority(request(signed),provider(options),now));
  check(true,`Unavailable, changed or unadmitted native readback rejected: ${JSON.stringify(options)}`);
 }
 for(const header of [{alg:'none',typ:'JWT',kid:'test-key'},{alg:'RS256',typ:'JWT',kid:'test-key',jku:'https://foreign.test/keys'},
  {alg:'RS256',typ:'JWT',kid:'test-key',crit:['custom']}]){
  const signed=await token({},header);
  await assert.rejects(()=>mod.authenticateAuthority(request(signed),provider(),now));
  check(true,'Untrusted JWT algorithms or key sources rejected');
 }
 const signed=await token(), split=signed.split('.');split[2]=b64(new Uint8Array(256));
 await assert.rejects(()=>mod.authenticateAuthority(request(split.join('.')),provider(),now));
 check(true,'Real cryptographic signature corruption rejected');
 await assert.rejects(()=>mod.authenticateAuthority(new Request(mod.ORIGIN),provider(),now));
 check(true,'Missing machine identity never inherits visitor or owner identity');
 const platformOnly=await token();
 await assert.rejects(()=>mod.authenticateAuthority(new Request(mod.ORIGIN,{headers:{authorization:`Bearer ${platformOnly}`}}),provider(),now));
 check(true,'Platform Authorization alone cannot impersonate the explicit workload header');
 await assert.rejects(()=>mod.authenticateAuthority(new Request(mod.ORIGIN,{headers:{'X-QIKVRT-Workflow-Identity':`Bearer ${platformOnly}`}}),provider(),now));
 check(true,'Former unredacted credential header is no longer accepted');
 await assert.rejects(()=>mod.authenticateAuthority(new Request(mod.ORIGIN,{headers:{Cookie:`${mod.WORKFLOW_IDENTITY_COOKIE}=${platformOnly}; ${mod.WORKFLOW_IDENTITY_COOKIE}=${platformOnly}`}}),provider(),now));
 check(true,'Duplicate workload cookies cannot choose an ambiguous identity');
 check(await mod.digest(mod.wire({title:'Prüfung äöü',version:1}))==='ede9478089679cdf55c683f20ff545dae31cc008a17c6caf71b16368d087dbde','Canonical UTF-8 hashing matches independently computed Python fixture');
 const worker=join(temp,'worker.mjs');
 await build({entryPoints:['tests/authority-worker.ts'],outfile:worker,bundle:true,format:'esm',platform:'browser',target:'es2022',external:['cloudflare:workers'],logLevel:'silent'});
 let upstream=provider(), requests=[];
 const mf=new Miniflare({modules:true,modulesRoot:temp,scriptPath:worker,compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:['DB'],bindings:{QIKVRT_WORKSPACE_MEMBERS:JSON.stringify({'qa-owner@example.test':'owner','qa-editor@example.test':'editor'})},cf:false,
  outboundService:async req=>{assert.equal(req.headers.has('cookie'),false,'Workload credential must not reach a public upstream');assert.equal(req.headers.has('authorization'),false,'Visitor/platform credential must not reach a public upstream');requests.push(req.url);return upstream(req.url);}});
 try {
  const call=()=>mf.dispatchFetch('https://fixture.test/qa/authenticate',{headers:identityHeaders(platformOnly)});
  const native=await call(), value=await native.json();
  assert.equal(native.status,200,`Real Workerd default fetch must reach the synthetic issuer: ${JSON.stringify(value)}`);
  check(value.head===head&&value.tree===tree&&value.run_id===71&&requests.length===6,'Actual Workerd default fetch completes signature and independent Authority readbacks');
  const governedCall=()=>mf.dispatchFetch('https://fixture.test/qa/authenticate-governed',{headers:{Cookie:`${mod.WORKFLOW_IDENTITY_COOKIE}=${platformOnly}`}});
  requests=[];assert.equal((await governedCall()).status,200);assert.equal(requests.length,6);
  requests=[];assert.equal((await governedCall()).status,200);assert.equal(requests.length,3);
  check(true,'Real signature/admission passes while warm immutable reads halve upstream calls from six to three');
  requests=[];upstream=provider({drift:true});assert.equal((await governedCall()).status,409);
  check(requests.length===3,'Warm source cache retains both Main fences and rejects an intervening Main change');
  requests=[];upstream=provider({changedRun:{status:'completed'}});assert.equal((await governedCall()).status,403);
  check(requests.some(url=>url.endsWith('/actions/runs/71')),'Warm source cache still rejects a no-longer-executing workflow run');
  requests=[];upstream=async()=>Response.redirect('https://foreign.test/must-not-be-followed',302);
  const redirect=await call();
  check(redirect.status===503&&requests.length===1&&requests[0].startsWith(claims.iss),'Actual Workerd rejects an upstream redirect without following it');
  requests=[];upstream=async()=>Response.json({private_message:'must-not-be-exported'},{status:403});
  const unavailable=await call(), denial=await unavailable.json();
  check(unavailable.status===503&&requests.length===1&&JSON.stringify(denial)==='{"error":{"code":"AUTHORITY_READBACK_UNAVAILABLE"}}','Actual Workerd preserves closed failure on an unavailable issuer without response disclosure');
  requests=[];upstream=async url=>url.startsWith(claims.iss)?Response.json({keys:[jwk]}):Response.json({private_message:'must-not-be-exported'},{status:403,headers:{'x-ratelimit-remaining':'0','x-ratelimit-reset':'1793527200'}});
  const diagnostic=await mf.dispatchFetch('https://fixture.test/qa/readback'), observed=await diagnostic.json();
  check(observed.observations[0].status===200&&observed.observations[1].status===403&&observed.observations[1].resource==='MAIN_REF'&&observed.observations[1].rate_limit_remaining===0&&!JSON.stringify(observed).includes('private_message'),'Actual Workerd readback diagnostic distinguishes issuer from public API denial with numeric quota only');
  const contextCall=who=>mf.dispatchFetch('https://fixture.test/mcp',{method:'POST',headers:{'content-type':'application/json',...(who?{'oai-authenticated-user-id':who,'oai-authenticated-user-email':`${who}@example.test`}:{})},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/call',params:{name:'get_context',arguments:{}}})});
  for(const who of [undefined,'qa-editor']) {
   requests=[];const response=await contextCall(who), value=await response.json();
   check(requests.length===0&&!JSON.parse(value.result.content[0].text).authority_readback,'Anonymous and ordinary member context never triggers owner-only source diagnostics');
  }
  requests=[];const owner=await contextCall('qa-owner'), context=await owner.json();
  check(requests.length===1&&JSON.parse(context.result.content[0].text).authority_readback.authentication_verified===false,'Existing authenticated owner context reuses public keys and returns bounded read-only diagnostics without a workload grant');
  requests=[];const nativeDenied=await mf.dispatchFetch('https://fixture.test/api/v1/authority/tasks/b50951b4-1194-431b-aa43-d81d262a19d3',{headers:identityHeaders(platformOnly)}), nativeFailure=await nativeDenied.json();
  check(nativeDenied.status===503&&nativeFailure.error.code==='AUTHORITY_READBACK_UNAVAILABLE'&&nativeFailure.error.readback.resource==='MAIN_REF'&&nativeFailure.error.readback.status===403&&nativeFailure.error.readback.rate_limit_remaining===0&&!JSON.stringify(nativeFailure).includes('private_message'),'Original workflow route carries only bounded public upstream denial evidence after real signature verification');
 } finally { await mf.dispose(); }
 console.log(JSON.stringify({checks,passed:true,scope:'isolated actual crypto with synthetic provider, not live GitHub or productive task acceptance'}));
}finally{await rm(temp,{recursive:true,force:true});}
