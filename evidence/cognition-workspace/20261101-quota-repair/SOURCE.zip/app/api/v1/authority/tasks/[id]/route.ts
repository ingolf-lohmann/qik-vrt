import { authenticateAuthority, AuthorityError } from "../../../../../../lib/authority-identity";
import { authoritySourceFetch } from "../../../../../../lib/authority-source";
import { admittedTask } from "../../../../../../lib/authority-intake";
import { failure, json } from "../../../../../../lib/workspace";
export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  try { return json(await admittedTask(await authenticateAuthority(request, authoritySourceFetch), (await context.params).id)); }
  catch (error) { return error instanceof AuthorityError ? json({ error: { code: error.code, ...(error.readback ? { readback: error.readback } : {}) } }, error.status) : failure(error); }
}
