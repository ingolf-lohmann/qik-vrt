import { authenticateAuthority, AuthorityError } from "../../../../../lib/authority-identity";
import { authoritySourceFetch } from "../../../../../lib/authority-source";
import { acceptTask } from "../../../../../lib/authority-intake";
import { body, failure, json, validateOrigin } from "../../../../../lib/workspace";
export async function POST(request: Request) {
  try { validateOrigin(request); return json(await acceptTask(await authenticateAuthority(request, authoritySourceFetch), await body(request)), 201); }
  catch (error) { return error instanceof AuthorityError ? json({ error: { code: error.code, ...(error.readback ? { readback: error.readback } : {}) } }, error.status) : failure(error); }
}
