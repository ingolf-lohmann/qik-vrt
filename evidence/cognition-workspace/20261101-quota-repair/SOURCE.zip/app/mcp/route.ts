import { actor, viewer, body, createTask, readTask, readWorkspace, updateTask, getContext, validateOrigin, ApiError } from "../../lib/workspace";
import { authorityReadbackDiagnostics } from "../../lib/authority-identity";
import { authoritySourceFetch } from "../../lib/authority-source";
const tools = [
  { name: "get_context", description: "Read QIK-VRT provenance, evidence boundaries and reading order. Historical imports are not live evidence.", inputSchema: { type: "object", properties: {}, additionalProperties: false }, annotations: { readOnlyHint: true } },
  { name: "list_tasks", description: "Read the common tasks and journal as an authenticated admitted workspace member, plus own personal tasks. The same protected records are at /api/v1/shared (up to 250; totalTasks and truncated disclose completeness).", inputSchema: { type: "object", properties: {}, additionalProperties: false }, annotations: { readOnlyHint: true } },
  { name: "get_task", description: "Read an admitted shared task or own personal task by exact ID. Authentication and workspace membership are required.", inputSchema: { type: "object", properties: { id: { type: "string" } }, required: ["id"], additionalProperties: false }, annotations: { readOnlyHint: true } },
  { name: "create_task", description: "Create a task for admitted members of the common workspace (select visibility=private for author-only data). Requires authenticated owner/editor membership. This records intent, not native execution. cognition is self-declared. Reuse requestId for an idempotent retry of an identical request.", inputSchema: { type: "object", properties: { requestId: { type: "string", format: "uuid" }, title: { type: "string", minLength: 1, maxLength: 160 }, description: { type: "string", maxLength: 4000 }, priority: { type: "string", enum: ["low", "medium", "high"] }, cognition: { type: "string", enum: ["natural", "artificial"], default: "artificial" }, visibility: { type: "string", enum: ["private", "shared"], default: "shared" } }, required: ["title"], additionalProperties: false }, annotations: { readOnlyHint: false, destructiveHint: false } },
  { name: "update_task", description: "Update an admitted common task or own personal task with its current version; concurrent changes are rejected. Only its author may change visibility. shared means admitted members only, never public publication. Completion is a workspace declaration, not a verified production effect.", inputSchema: { type: "object", properties: { id: { type: "string" }, version: { type: "integer", minimum: 1 }, status: { type: "string", enum: ["open", "active", "done"] }, title: { type: "string", minLength: 1, maxLength: 160 }, description: { type: "string", maxLength: 4000 }, priority: { type: "string", enum: ["low", "medium", "high"] }, visibility: { type: "string", enum: ["private", "shared"] } }, required: ["id", "version"], additionalProperties: false }, annotations: { readOnlyHint: false, destructiveHint: false } },
];
export async function POST(request: Request) {
  let id: unknown = null;
  try {
    validateOrigin(request); const rpc = await body(request);
    if (!rpc || rpc.jsonrpc !== "2.0" || typeof rpc.method !== "string") throw new ApiError(400, "Invalid JSON-RPC request");
    id = rpc.id ?? null; let result: unknown;
    if (rpc.method === "server/discover") result = { supportedVersions: ["2026-07-28"], capabilities: { tools: {} }, serverInfo: { name: "qikvrt-cognition-workspace", version: "1.2.0" } };
    else if (rpc.method === "initialize") result = { protocolVersion: "2026-07-28", capabilities: { tools: {} }, serverInfo: { name: "qikvrt-cognition-workspace", version: "1.2.0" } };
    else if (rpc.method === "notifications/initialized") return new Response(null, { status: 202 });
    else if (rpc.method === "tools/list") result = { tools };
    else if (rpc.method === "tools/call") {
      const name = rpc.params?.name; const args = rpc.params?.arguments ?? {};
      try {
        let value: unknown;
        if (name === "get_context") {
          value = getContext();
          let owner = false;
          try { owner = viewer(request).role === "owner"; } catch { /* Public static context remains available. */ }
          if (owner) value = { ...getContext(), authority_readback: await authorityReadbackDiagnostics(authoritySourceFetch) };
        }
        else if (name === "list_tasks") value = await readWorkspace(viewer(request));
        else if (name === "get_task") value = await readTask(viewer(request), String(args.id ?? ""));
        else if (name === "create_task") value = await createTask(actor(request), { ...args, cognition: args.cognition ?? "artificial" }, "mcp");
        else if (name === "update_task") { const { id: taskId, ...changes } = args; value = await updateTask(actor(request), String(taskId ?? ""), changes, "mcp"); }
        else throw new ApiError(400, "Unknown tool");
        result = { content: [{ type: "text", text: JSON.stringify(value) }], isError: false };
      } catch (e) { result = { content: [{ type: "text", text: e instanceof Error ? e.message : "Tool unavailable" }], isError: true }; }
    } else return Response.json({ jsonrpc: "2.0", id, error: { code: -32601, message: "Method not found" } });
    return Response.json({ jsonrpc: "2.0", id, result }, { headers: { "Cache-Control": "no-store" } });
  } catch (e) { return Response.json({ jsonrpc: "2.0", id, error: { code: -32600, message: e instanceof Error ? e.message : "Invalid request" } }, { status: e instanceof ApiError ? e.status : 400 }); }
}
