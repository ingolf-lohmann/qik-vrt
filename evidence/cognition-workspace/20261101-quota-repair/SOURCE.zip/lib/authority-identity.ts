// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Copyright 2026 Ingolf Lohmann. Implementation: OpenAI Codex.
// Service identity only: no visitor identity, OAuth session or production grant.
export const AUTHORITY = "ingolf-lohmann/qik-vrt";
export const WORKFLOW = ".github/workflows/qikvrt_workflow_executor.yml";
export const CONTRACT = "state/autonomy/WORKFLOW_EXECUTOR_MESH_CONTRACT_V1.json";
export const ORIGIN = "https://qikvrt-cognition-workspace.ingolf-lohmann.chatgpt.site";
export const AUDIENCE = `${ORIGIN}/api/v1/authority`;
// A service-only cookie field, never set by this app or exposed to browsers.
// The platform's observed invocation-log surface redacts Cookie; it did not
// redact the former custom credential header. This is still GitHub OIDC.
export const WORKFLOW_IDENTITY_HEADER = "Cookie";
export const WORKFLOW_IDENTITY_COOKIE = "__Host-QIKVRT-Workflow-Identity";
const issuer = "https://token.actions.githubusercontent.com";
const api = `https://api.github.com/repos/${AUTHORITY}/`;
const sha = /^[a-f0-9]{40}$/;
type ObjectValue = Record<string, unknown>;
type ReadbackFailure = { resource: string; reason: "REQUEST_FAILED" | "HTTP_DENIAL"; status: number; rate_limit_remaining?: number; rate_limit_reset?: number; request_attempted?: false };
export class AuthorityError extends Error {
  constructor(public status: number, public code: string, public readback?: ReadbackFailure) { super(code); }
}
function requireThat(ok: unknown, code: string, status = 403): asserts ok {
  if (!ok) throw new AuthorityError(status, code);
}
export function object(value: unknown): ObjectValue {
  requireThat(value !== null && typeof value === "object" && !Array.isArray(value), "INVALID_RESPONSE", 503);
  return value as ObjectValue;
}
export function wire(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(wire).join(",")}]`;
  if (value !== null && typeof value === "object") {
    const obj = value as ObjectValue;
    return `{${Object.keys(obj).sort().map(key => `${JSON.stringify(key)}:${wire(obj[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}
export async function digest(value: string) {
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)))].map(v => v.toString(16).padStart(2, "0")).join("");
}
function decode(value: string) {
  requireThat(/^[A-Za-z0-9_-]+$/.test(value), "INVALID_RUN_TOKEN", 401);
  return Uint8Array.from(atob(value.replaceAll("-", "+").replaceAll("_", "/") + "=".repeat((4 - value.length % 4) % 4)), c => c.charCodeAt(0));
}
function unavailable(url: string, response?: Response): AuthorityError {
  const resource = url.startsWith(issuer + "/") ? "OIDC_KEYS" : url.includes("/git/ref/heads/main") ? "MAIN_REF" : url.includes("/git/commits/") ? "COMMIT" : url.includes("/actions/runs/") ? "WORKFLOW_RUN" : "SOURCE_CONTRACT";
  const detail: ReadbackFailure = { resource, reason: response ? "HTTP_DENIAL" : "REQUEST_FAILED", status: response?.status ?? 0 };
  if (response?.headers.get("x-qikvrt-source-request") === "SUPPRESSED_QUOTA_COOLDOWN") detail.request_attempted = false;
  for (const [header, field] of [["x-ratelimit-remaining", "rate_limit_remaining"], ["x-ratelimit-reset", "rate_limit_reset"]] as const) {
    const value = response?.headers.get(header);
    if (value && /^[0-9]{1,12}$/.test(value)) detail[field] = Number(value);
  }
  // Fixed public source labels and numeric status/quota only. No token,
  // exception message, response body, task, request URL or caller identity.
  console.warn("QIKVRT_AUTHORITY_READBACK", JSON.stringify(detail));
  return new AuthorityError(503, "AUTHORITY_READBACK_UNAVAILABLE", detail);
}
async function get(url: string, fetcher: typeof fetch, observe?: (response: Response) => void): Promise<ObjectValue> {
  let response: Response;
  // Workerd supports manual redirects; its unsupported error mode throws
  // before sending. Every redirect is still rejected by the 200 guard below.
  try { response = await fetcher(url, { redirect: "manual", cache: "no-store", signal: AbortSignal.timeout(15000), headers: { Accept: "application/json", "User-Agent": "QIKVRT-workspace-authority-intake", "X-GitHub-Api-Version": "2022-11-28" } }); }
  catch { throw unavailable(url); }
  observe?.(response);
  if (response.status !== 200 || response.redirected) throw unavailable(url, response);
  const reader = response.body?.getReader();
  requireThat(reader, "AUTHORITY_READBACK_UNAVAILABLE", 503);
  let size = 0; const chunks: Uint8Array[] = [];
  while (true) {
    const part = await reader.read(); if (part.done) break;
    size += part.value.length;
    if (size > 1048576) { await reader.cancel(); throw new AuthorityError(503, "AUTHORITY_READBACK_TOO_LARGE"); }
    chunks.push(part.value);
  }
  const bytes = new Uint8Array(size); let at = 0;
  for (const chunk of chunks) { bytes.set(chunk, at); at += chunk.length; }
  try { return object(JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes))); }
  catch { throw new AuthorityError(503, "AUTHORITY_READBACK_INVALID"); }
}
export async function authorityReadbackDiagnostics(fetcher: typeof fetch = fetch) {
  const observations = [];
  for (const [resource, url] of [["OIDC_KEYS", `${issuer}/.well-known/jwks`], ["MAIN_REF", `${api}git/ref/heads/main`]]) {
    try {
      let reused = false;
      await get(url, fetcher, response => { reused = response.headers.get("x-qikvrt-source-request") === "REUSED_PUBLIC_SOURCE"; });
      observations.push({ resource, status: 200, ...(reused ? { request_attempted: false, evidence: "REUSED_PUBLIC_SOURCE" } : {}) });
    }
    catch (error) { observations.push(error instanceof AuthorityError ? { resource, code: error.code, ...error.readback } : { resource, code: "AUTHORITY_READBACK_UNAVAILABLE" }); }
  }
  return { scope: "OWNER_READ_ONLY_PUBLIC_SOURCE_DIAGNOSTICS", authentication_verified: false, observed_at: new Date().toISOString(), observations };
}
export type AuthorityIdentity = {
  repository: string; run_id: number; run_attempt: number; head: string; tree: string;
  workflow: string; workflow_sha: string; event: string; contract_sha256: string;
  scope: "VERSIONED_TASK_COORDINATION_ONLY";
  work_items: { id: string; min_version: number }[];
};
export async function authenticateAuthority(request: Request, fetcher: typeof fetch = fetch, now = Math.floor(Date.now() / 1000)): Promise<AuthorityIdentity> {
  const cookies = request.headers.get(WORKFLOW_IDENTITY_HEADER) ?? "";
  requireThat(cookies.length <= 32768, "INVALID_RUN_TOKEN", 401);
  const credentials = cookies.split(";").map(value => value.trim()).filter(value => value.startsWith(WORKFLOW_IDENTITY_COOKIE + "="));
  requireThat(credentials.length === 1, "RUN_TOKEN_REQUIRED", 401);
  const token = credentials[0].slice(WORKFLOW_IDENTITY_COOKIE.length + 1);
  requireThat(token.length > 0 && token.length <= 24000, "INVALID_RUN_TOKEN", 401);
  const parts = token.split(".");
  requireThat(parts.length === 3, "INVALID_RUN_TOKEN", 401);
  let header: ObjectValue, claims: ObjectValue;
  try {
    header = object(JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(decode(parts[0]))));
    claims = object(JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(decode(parts[1]))));
  } catch { throw new AuthorityError(401, "INVALID_RUN_TOKEN"); }
  requireThat(header.alg === "RS256" && header.typ === "JWT" && typeof header.kid === "string" && !header.crit && !header.jku && !header.jwk && !header.x5u, "INVALID_RUN_TOKEN", 401);
  const keys = (await get(`${issuer}/.well-known/jwks`, fetcher)).keys;
  requireThat(Array.isArray(keys) && keys.length <= 20, "OIDC_KEYS_UNAVAILABLE", 503);
  const matches = keys.filter(key => key?.kid === header.kid && key?.kty === "RSA" && key?.use === "sig" && key?.alg === "RS256");
  requireThat(matches.length === 1, "OIDC_KEY_UNVERIFIED", 401);
  try {
    const key = await crypto.subtle.importKey("jwk", matches[0], { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]);
    requireThat(await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, decode(parts[2]), new TextEncoder().encode(`${parts[0]}.${parts[1]}`)), "INVALID_RUN_SIGNATURE", 401);
  } catch { throw new AuthorityError(401, "INVALID_RUN_SIGNATURE"); }
  requireThat(claims.iss === issuer && claims.aud === AUDIENCE && claims.sub === `repo:${AUTHORITY}:ref:refs/heads/main`, "WRONG_RUN_IDENTITY");
  requireThat([claims.iat, claims.nbf, claims.exp].every(Number.isInteger)
    && Number(claims.nbf) <= now + 30 && Number(claims.iat) <= now + 30
    && Number(claims.exp) > now && Number(claims.iat) >= now - 600
    && Number(claims.exp) > Number(claims.iat) && Number(claims.exp) - Number(claims.iat) <= 600, "STALE_RUN_TOKEN", 401);
  requireThat(claims.repository === AUTHORITY && claims.repository_id === "1273784147" && claims.repository_owner_id === "294949349"
    && claims.ref === "refs/heads/main" && claims.workflow_ref === `${AUTHORITY}/${WORKFLOW}@refs/heads/main`
    && typeof claims.sha === "string" && sha.test(claims.sha) && claims.workflow_sha === claims.sha
    && typeof claims.run_id === "string" && /^[1-9][0-9]{0,15}$/.test(claims.run_id)
    && typeof claims.run_attempt === "string" && /^[1-9][0-9]{0,5}$/.test(claims.run_attempt), "WRONG_RUN_IDENTITY");
  const head = claims.sha;
  const ref = await get(`${api}git/ref/heads/main`, fetcher);
  requireThat(ref.ref === "refs/heads/main" && object(ref.object).type === "commit" && object(ref.object).sha === head, "MAIN_CHANGED", 409);
  const [commit, run, source] = await Promise.all([
    get(`${api}git/commits/${head}`, fetcher),
    get(`${api}actions/runs/${claims.run_id}`, fetcher),
    get(`${api}contents/${CONTRACT}?ref=${head}`, fetcher),
  ]);
  const tree = object(commit.tree).sha;
  requireThat(commit.sha === head && typeof tree === "string" && sha.test(tree), "INVALID_MAIN_SUBJECT", 503);
  requireThat(run.id === Number(claims.run_id) && run.run_attempt === Number(claims.run_attempt) && run.head_sha === head
    && run.path === WORKFLOW && run.head_branch === "main" && run.event === claims.event_name && run.status === "in_progress"
    && object(run.repository).full_name === AUTHORITY && object(run.repository).id === 1273784147
    && object(run.head_repository).full_name === AUTHORITY, "RUN_NOT_EXECUTING");
  requireThat(source.path === CONTRACT && source.type === "file" && source.encoding === "base64" && typeof source.content === "string", "SOURCE_CONTRACT_UNAVAILABLE", 503);
  let contract: ObjectValue, raw: string;
  try {
    raw = new TextDecoder("utf-8", { fatal: true }).decode(Uint8Array.from(atob(source.content.replace(/\s/g, "")), c => c.charCodeAt(0)));
    const encoded = new TextEncoder().encode(raw);
    const blobPrefix = new TextEncoder().encode(`blob ${encoded.length}\0`);
    const blobBytes = new Uint8Array(blobPrefix.length + encoded.length); blobBytes.set(blobPrefix); blobBytes.set(encoded, blobPrefix.length);
    const blob = [...new Uint8Array(await crypto.subtle.digest("SHA-1", blobBytes))].map(v => v.toString(16).padStart(2, "0")).join("");
    requireThat(source.sha === blob && source.size === encoded.length, "SOURCE_CONTRACT_BYTES_INVALID", 503);
    contract = object(JSON.parse(raw));
  } catch { throw new AuthorityError(503, "SOURCE_CONTRACT_BYTES_INVALID"); }
  const admission = object(contract.workspace_task_intake);
  const items = admission.work_items;
  requireThat(object(contract.authority).repository === AUTHORITY && admission.schema === "qikvrt-workspace-task-intake/v1"
    && admission.enabled === true && admission.origin === ORIGIN && admission.audience === AUDIENCE
    && admission.workflow === WORKFLOW && admission.scope === "VERSIONED_TASK_COORDINATION_ONLY"
    && admission.identity_header === WORKFLOW_IDENTITY_HEADER
    && admission.identity_cookie === WORKFLOW_IDENTITY_COOKIE
    && admission.productive_effect_authorized === false && admission.effect_ack_done === false
    && Array.isArray(admission.allowed_events) && admission.allowed_events.includes(run.event)
    && Array.isArray(items) && items.length > 0 && items.length <= 32
    && items.every(item => typeof item?.id === "string" && /^[a-f0-9-]{36}$/.test(item.id) && Number.isSafeInteger(item.min_version) && item.min_version > 0), "WORKSPACE_SOURCE_NOT_ADMITTED");
  const after = await get(`${api}git/ref/heads/main`, fetcher);
  requireThat(object(after.object).sha === head, "MAIN_CHANGED", 409);
  return { repository: AUTHORITY, run_id: Number(claims.run_id), run_attempt: Number(claims.run_attempt), head, tree,
    workflow: WORKFLOW, workflow_sha: head, event: String(run.event), contract_sha256: await digest(raw),
    scope: "VERSIONED_TASK_COORDINATION_ONLY", work_items: items };
}
