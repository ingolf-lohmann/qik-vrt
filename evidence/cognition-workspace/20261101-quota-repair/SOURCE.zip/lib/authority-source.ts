// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Copyright 2026 Ingolf Lohmann. Implementation: OpenAI Codex.
// Original receiver transport only. No credential, peer, writer or executor grant.
import { env } from "cloudflare:workers";

const api = "https://api.github.com/repos/ingolf-lohmann/qik-vrt/";
const keys = "https://token.actions.githubusercontent.com/.well-known/jwks";
const pending = new Map<string, Promise<Response>>();
const table = "cognition_authority_source_cache";
const cooldown = "GITHUB_PUBLIC_REST_NOT_BEFORE";
type Row = { value: string; until_at: number };

// D1 persists the public-source budget boundary across isolates/restarts.
// Only fixed public URLs/JSON are retained. No incoming headers or task bytes.
async function database() {
  if (!env.DB) throw new Error("AUTHORITY_SOURCE_STORE_UNAVAILABLE");
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS ${table} (key TEXT PRIMARY KEY, value TEXT NOT NULL, until_at INTEGER NOT NULL)`).run();
  return env.DB;
}
function ttl(url: string): number {
  if (url === keys) return 60_000;
  if (new RegExp(`^${api.replaceAll(".", "\\.")}git/commits/[a-f0-9]{40}$`).test(url)) return 600_000;
  if (new RegExp(`^${api.replaceAll(".", "\\.")}contents/state/autonomy/WORKFLOW_EXECUTOR_MESH_CONTRACT_V1\\.json\\?ref=[a-f0-9]{40}$`).test(url)) return 600_000;
  return 0; // Main ref and executing run are ALWAYS fresh, including the final ref fence.
}
function number(headers: Headers, name: string): number | null {
  const raw = headers.get(name);
  return raw && /^[0-9]{1,12}$/.test(raw) && Number.isSafeInteger(Number(raw)) ? Number(raw) : null;
}
function denial(row: Row) {
  const value = JSON.parse(row.value);
  return new Response(null, { status: value.status, headers: {
    ...(value.remaining === 0 ? { "x-ratelimit-remaining": "0" } : {}),
    "x-ratelimit-reset": String(Math.ceil(row.until_at / 1000)),
    "x-qikvrt-source-request": "SUPPRESSED_QUOTA_COOLDOWN",
  } });
}
async function read(url: string, init?: RequestInit): Promise<Response> {
  if (url !== keys && !(url.startsWith(api) &&
      (url === api + "git/ref/heads/main" || ttl(url) > 0 || new RegExp(`^${api.replaceAll(".", "\\.")}actions/runs/[1-9][0-9]{0,15}$`).test(url)))) {
    throw new Error("FIXED_AUTHORITY_PUBLIC_SOURCE_REQUIRED");
  }
  if (init?.method && init.method !== "GET") throw new Error("READ_ONLY_AUTHORITY_SOURCE_REQUIRED");
  const db = await database(), now = Date.now(), duration = ttl(url);
  if (duration) {
    const row = await db.prepare(`SELECT value, until_at FROM ${table} WHERE key = ?`).bind(url).first<Row>();
    if (row && row.until_at > now) return new Response(row.value, { headers: { "content-type": "application/json", "x-qikvrt-source-request": "REUSED_PUBLIC_SOURCE" } });
  }
  if (url.startsWith(api)) {
    const row = await db.prepare(`SELECT value, until_at FROM ${table} WHERE key = ?`).bind(cooldown).first<Row>();
    if (row && row.until_at > now) return denial(row);
  }
  // Server-owned headers only: never forward the workload cookie or Authorization.
  const response = await fetch(url, { method: "GET", redirect: "manual", cache: "no-store",
    signal: AbortSignal.timeout(15000), headers: { Accept: "application/json",
      "User-Agent": "QIKVRT-workspace-authority-intake", "X-GitHub-Api-Version": "2022-11-28" } });
  if (url.startsWith(api)) {
    const remaining = number(response.headers, "x-ratelimit-remaining"), reset = number(response.headers, "x-ratelimit-reset");
    const retry = number(response.headers, "retry-after");
    const retryDate = retry === null ? Date.parse(response.headers.get("retry-after") ?? "") : NaN;
    if (remaining === 0 || response.status === 429 || response.status === 403 && (retry !== null || Number.isFinite(retryDate))) {
      const until = Math.max(now + 60_000, reset === null ? 0 : reset * 1000 + 5000,
        retry === null ? Number.isFinite(retryDate) ? retryDate : 0 : now + retry * 1000);
      // Atomic max: an older concurrent denial cannot shorten an existing stop.
      await db.prepare(`INSERT INTO ${table} (key, value, until_at) VALUES (?, ?, ?) ON CONFLICT(key) DO UPDATE SET value = CASE WHEN excluded.until_at > until_at THEN excluded.value ELSE value END, until_at = MAX(until_at, excluded.until_at)`)
        .bind(cooldown, JSON.stringify({ status: response.status === 429 ? 429 : 403, remaining }), until).run();
    }
  }
  if (!duration || response.status !== 200 || response.redirected) return response;
  const reader = response.body?.getReader();
  if (!reader) throw new Error("AUTHORITY_SOURCE_BODY_REQUIRED");
  let size = 0; const chunks: Uint8Array[] = [];
  while (true) {
    const part = await reader.read(); if (part.done) break;
    size += part.value.length;
    if (size > 1_048_576) { await reader.cancel(); throw new Error("AUTHORITY_SOURCE_TOO_LARGE"); }
    chunks.push(part.value);
  }
  const bytes = new Uint8Array(size); let at = 0;
  for (const chunk of chunks) { bytes.set(chunk, at); at += chunk.length; }
  const value = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  const parsed = JSON.parse(value);
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("AUTHORITY_SOURCE_INVALID");
  // Bounded cache, independent of task/acceptance journals. Expiry never grants authority.
  await db.batch([
    db.prepare(`DELETE FROM ${table} WHERE key != ? AND until_at <= ?`).bind(cooldown, now),
    db.prepare(`DELETE FROM ${table} WHERE key IN (SELECT key FROM ${table} WHERE key != ? ORDER BY until_at ASC LIMIT MAX(0, (SELECT COUNT(*) FROM ${table} WHERE key != ?) - 30))`).bind(cooldown, cooldown),
    db.prepare(`INSERT INTO ${table} (key, value, until_at) VALUES (?, ?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value, until_at = excluded.until_at`).bind(url, value, now + duration),
  ]);
  return new Response(value, { status: 200, headers: { "content-type": "application/json", "x-qikvrt-source-request": "FETCHED_PUBLIC_SOURCE" } });
}
export const authoritySourceFetch: typeof fetch = async (input, init) => {
  if (typeof input !== "string") throw new Error("FIXED_AUTHORITY_PUBLIC_SOURCE_REQUIRED");
  if (!ttl(input)) return read(input, init);
  // Only immutable source/key fetches coalesce. Never coalesce the two Main fences.
  let task = pending.get(input);
  if (!task) { task = read(input, init); pending.set(input, task); }
  try { return (await task).clone(); }
  finally { if (pending.get(input) === task) pending.delete(input); }
};
