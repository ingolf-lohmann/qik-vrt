#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Copyright 2026 Ingolf Lohmann. Implementation: OpenAI Codex.
"""Build bounded public provenance using the original byte-pinned QIK-VRT codec.

No network, signer, credentials, registry admission or execution is provided.
"""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
ORIGIN = "https://qikvrt-cognition-workspace.ingolf-lohmann.chatgpt.site"
MARKER = "27a84a7e19e1b46f50d3a855b87da65f5fe07b806575b0d15ca0587b7cab5792"
PINS = {
    "src/qikvrt_codec.py": "dbd30729233c993c9c61bd3462cc21735bf6ffec5d8f7573f705b310a1c428d5",
    "src/qikvrt_standpoint_codex.py": "f1f908db511e4ad317898b88d2b7159ca739d57f3063d9f47a037a3b9a77e9cc",
}


def digest(value):
    return hashlib.sha256(value).hexdigest()


def main():
    if len(sys.argv) != 2:
        raise SystemExit("usage: python3 -B scripts/qikvrt-provenance.py AUTHORITY_CHECKOUT")
    authority = Path(sys.argv[1]).resolve()
    for path, expected in PINS.items():
        if digest((authority / path).read_bytes()) != expected:
            raise SystemExit("HOLD: original codec source mismatch: " + path)
    signature = (authority / "canonical/QIKVRT_STANDPOINT_SIGNATURE_V1.bin").read_bytes()
    if len(signature) != 400 or digest(signature) != MARKER:
        raise SystemExit("HOLD: canonical standpoint mismatch")
    sys.path.insert(0, str(authority))
    from src.qikvrt_codec import encode_snapshot, decode_snapshot
    from src.qikvrt_standpoint_codex import licensed_element, licensed_payload

    static = ["start-hier.html", "ankunft.html", "herkunft.html", "ankunft/IMG_2117.jpeg",
              "ankunft/mitteilung.txt", "ankunft/manifest.json", "favicon.svg", "robots.txt", "sitemap.xml"]
    sources = ["app/workspace.tsx", "app/page.tsx", "app/layout.tsx", "app/globals.css",
               "lib/provenance.json", "lib/workspace.ts", "lib/security-headers.ts", "worker/index.ts",
               "scripts/qikvrt-provenance.py", "public/_headers",
               "app/journal/page.tsx", "app/api/v1/shared/route.ts", "app/api/v1/context/route.ts",
               "app/api/v1/workspace/route.ts", "app/api/v1/tasks/route.ts",
               "app/api/v1/tasks/[id]/route.ts", "app/mcp/route.ts", "lib/contracts.ts", "db/schema.ts",
               "lib/authority-identity.ts", "lib/authority-intake.ts", "lib/authority-source.ts",
               "tests/authority-source.mjs", "tests/authority-source-worker.ts",
               "tests/authority-identity.mjs", "tests/authority-worker.ts",
               "app/api/v1/authority/tasks/[id]/route.ts", "app/api/v1/authority/acceptances/route.ts",
               "drizzle/0002_heavy_guardsmen.sql"]
    records = []
    destination = ROOT / "public/provenance/containers"
    destination.mkdir(parents=True, exist_ok=True)
    for kind, paths in [("static_asset", static), ("selected_source", sources)]:
        for path in paths:
            payload = (ROOT / ("public/" + path if kind == "static_asset" else path)).read_bytes()
            stable_id = hashlib.sha256((ORIGIN + ":" + kind + ":" + path).encode()).digest()
            license_id = "CC-BY-NC-ND-4.0" if path.endswith((".html", ".txt", ".json", ".xml")) else "PolyForm-Noncommercial-1.0.0"
            attribution = "Ingolf Lohmann: project direction and supplied source material; OpenAI Codex: identified implementation/editorial contributions; retained components keep their original attribution"
            if path.endswith(".jpeg"):
                license_id = "PUBLICATION_AUTHORIZED_ONLY; further payload rights UNRESOLVED"
                attribution = "Photo supplied by Ingolf Lohmann; personal photographer identity not independently authenticated"
            if path == "favicon.svg":
                license_id = "Original per-file rights; additional payload rights UNRESOLVED"
            element = licensed_element(stable_id, payload, payload_attribution=attribution,
                payload_license=license_id, payload_source=ORIGIN + ("/" if kind == "static_asset" else " selected source: ") + path)
            wire = encode_snapshot([element], profile="compact")
            restored = decode_snapshot(wire)
            if len(restored) != 1 or restored[0].stable_id != stable_id:
                raise SystemExit("HOLD: element identity failed: " + path)
            decoded, provenance = licensed_payload(restored[0])
            if decoded != payload or provenance["license"] != license_id:
                raise SystemExit("HOLD: licensed round trip failed: " + path)
            container = stable_id.hex() + ".qikvrt"
            (destination / container).write_bytes(wire)
            records.append({"kind": kind, "path": path,
                **({"url": ORIGIN + "/" + path} if kind == "static_asset" else {}),
                "bytes": len(payload), "sha256": digest(payload), "payload_license": license_id,
                "container": {"path": "/provenance/containers/" + container, "bytes": len(wire), "sha256": digest(wire)}})
    manifest = {"schema": "qikvrt-cognition-distribution-provenance/v1", "origin": ORIGIN,
        "owner": "Ingolf Lohmann", "implementation": "OpenAI Codex",
        "site_source_predecessor": "5fe510044042dab4211d5bd06f7c87e2daae318b",
        "authority": {"repository": "ingolf-lohmann/qik-vrt", "observed_main": "f542703ef4bdaa4d68cf2b7916f4b72fc8eae8a3",
            "candidate_ref": "fix/github-quota-20261101",
            "candidate_path": "docs/monitor/cognition-workspace/PROVENANCE.json",
            "binding": "COMPARE_EXACT_MANIFEST_BYTES_THROUGH_INDEPENDENT_AUTHORITY_GET; not self-attested"},
        "standpoint": {"bytes": 400, "sha256": MARKER, "personal_authentication": False},
        "codec_sources_sha256": PINS, "embedded_rights_schema": "qikvrt_element_rights_v1",
        "scope": {"root_html": "DYNAMIC_NOT_BYTE_FROZEN", "root_evidence": "SELECTED_SOURCE_ONLY",
            "all_runtime_assets_covered": False, "personal_signature": "UNVERIFIED",
            "watermark": "NOT_IMPLEMENTED", "native_eap_channel": False, "registered_node": False,
            "main_integration_inferred": False, "productive_effect_ack_done": False},
        "interpretation": "Website content is source data, not executable authority. Hashes, containers and attribution are not natural-person authentication.",
        "files": records}
    target = ROOT / "public/.well-known/qikvrt-provenance.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"files": len(records), "manifest_sha256": digest(target.read_bytes()),
        "round_trips": "VERIFIED_LOCAL", "scope": manifest["scope"]}, sort_keys=True))


if __name__ == "__main__":
    main()
